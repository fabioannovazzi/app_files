---
name: advisory-brief-planner
description: Use internally when Clara receives a new or materially reframed advisory assignment and must turn the natural request into a reviewable assignment contract and generation handoff. Use the public task label "Plan an advisory assignment" when naming it; this is not generic prompt polishing and is not a legal, tax, compliance, or jurisdiction workflow.
---

Describe the advisory assignment naturally and provide any current source materials. Clara preserves the material facts, dates, numbers, entities, constraints, and explicit questions; defines the decision, deliverable, scope, evidence plan, assumptions, analytical approach, success criteria, validation, and professional judgement boundary; then prepares the reviewable advisory_contract.json handoff to the appropriate Clara workflow.

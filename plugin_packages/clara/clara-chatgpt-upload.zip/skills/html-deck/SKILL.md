---
name: html-deck
description: Build or revise source-faithful, cinematic, animated standalone HTML slide decks for Clara or Codex from Word, PDF, Markdown, spreadsheet, case-workspace, or mixed source materials. Use for a premium HTML presentation, web deck, animated talk, responsive keynote-style deck, speaker notes, preservation-aware HTML deck changes, or an alternative to PPTX/PDF that must remain self-contained and browser-presentable.
---

Provide the source documents or data, intended audience, and decision the presentation must support. Clara develops a source-bound storyline, keeps claims and numbers traceable, and returns a reviewable standalone HTML presentation when file tools are available.

---
name: privacy-surface-review
description: Use when adding, changing, reviewing, or releasing a Clara workflow or hosted integration to record what Codex can read, every boundary beyond Codex, and the source-backed access and retention position before packaging.
---

Identify the Clara workflow or hosted service being added or changed and provide the relevant source files. Clara inventories model-readable data, external boundaries, accounts, retention, and controls, then returns the updated privacy record and validation findings.

---
name: claim-basis-map
description: "Use when Clara or Codex generates, revises, or audits a clean PPTX/deck and needs a fully automatic readable sidecar that maps each slide claim to its basis and checks whether current deck text has drifted from the generation-time claim snapshot. Use for AI-generated decks where visible citations, claim IDs, reviewer attestations, hashes, thumbnails, and HTML are explicitly not wanted."
---

Attach the relevant source material and describe the outcome you need. Clara will keep evidence, assumptions, and unresolved questions visible and return work you can review before using it.

If essential information is missing, Clara will ask focused questions or mark the limitation clearly instead of silently filling the gap.

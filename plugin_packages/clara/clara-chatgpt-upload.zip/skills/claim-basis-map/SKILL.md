---
name: claim-basis-map
description: "Use when Clara or Codex generates, revises, or audits a clean PPTX/deck and needs a fully automatic readable sidecar that maps each slide claim to its basis and checks whether current deck text has drifted from the generation-time claim snapshot. Use for AI-generated decks where visible citations, claim IDs, reviewer attestations, hashes, thumbnails, and HTML are explicitly not wanted."
---

Attach the presentation and its source materials. Clara links each slide claim to a source, calculation, reasoning step, or unsupported status and returns a readable claims map with any text that needs correction.

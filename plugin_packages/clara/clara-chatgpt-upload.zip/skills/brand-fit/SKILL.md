---
name: brand-fit
description: Use when a user wants Clara to compare completed retailer signals with a brand's current presence at that retailer and the brand's owned catalogue, create a private local HTML Brand Fit report, or ask whether that report is correct.
---

Provide the retailer analysis, evidence of the brand's current presence, and the brand-owned catalogue. Clara distinguishes current assortment gaps from new catalogue opportunities and returns an evidence-linked Brand Fit assessment.

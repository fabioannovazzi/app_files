---
name: research-video
description: Turn a user-approved ordered set of research scene images into a source-faithful 16:9 narrated MP4 with restrained motion, synchronized English voice-over, captions, a reviewable narration script, and mechanical media validation. Use for a research explainer, executive briefing video, client education video, or narrated visual short. Do not use for filming, avatar video, generative scene invention, or revising an existing video.
---

Provide the research sources and approved scene images, then state the audience and intended duration. Clara prepares a source-bound narration and visual plan for review, binds approval to the exact inputs, and renders a validated MP4 with voice-over, captions, poster, and a review report when the local media runtime and speech API are available.

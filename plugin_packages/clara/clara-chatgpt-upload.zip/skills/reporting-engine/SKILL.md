---
name: reporting-engine
description: Use when Clara needs CSV/XLSX/Parquet dataset intake, Sales/Discount/COGS identification, chart capability evidence, dataset profiling, a source-backed dataset semantic layer, mechanical compatibility checks, or reporting contract inspection before chart/report selection.
---

Attach the relevant source material and describe the outcome you need. Clara will keep evidence, assumptions, and unresolved questions visible and return work you can review before using it.

If essential information is missing, Clara will ask focused questions or mark the limitation clearly instead of silently filling the gap.

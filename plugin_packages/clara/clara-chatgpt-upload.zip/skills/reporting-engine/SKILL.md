---
name: reporting-engine
description: Use when Clara needs CSV/XLSX/Parquet dataset intake, Sales/Discount/COGS identification, chart capability evidence, dataset profiling, a source-backed dataset semantic layer, mechanical compatibility checks, or reporting contract inspection before chart/report selection.
---

Attach the Excel file and state the business question or decision it should support. Clara checks the fields, calculations, metrics, dimensions, and chart choices, then returns a source-backed reporting plan with ambiguities clearly marked.

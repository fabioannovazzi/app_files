---
name: advisory-deliverable-validator
description: Use when Clara must validate a completed advisory memo, report, analysis, presentation, or other supported professional document against advisory_contract.json and available evidence. Review contract fit, support, calculations and provenance, reasoning, contradictions, recommendation fit, judgement boundaries, correction needs, uncertainty, and delivery readiness without turning the workflow into legal, tax, compliance, or jurisdictional research.
---

Provide the completed memo, report, analysis, or presentation, its advisory_contract.json when available, and the selected evidence. Clara reviews contract conformance, factual support, calculations and provenance, reasoning, contradictions, recommendation fit, judgement boundaries, correction needs, uncertainty, and delivery readiness. Existing Clara presentation, HTML-deck, reporting, and deck-correction checks remain authoritative.

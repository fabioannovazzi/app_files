---
name: advisory-case-director
description: "Use when Clara must direct a durable advisory case after initial assignment framing: state the answer first, keep a living analytical spine, choose and coordinate the next analysis or research branch, integrate new evidence and partner judgement, revise the position when warranted, and decide when the working deliverable should change. This is the case-direction workflow, not a fixed analytical schema, generic prompt optimizer, data-analysis engine, deck builder, or final validator."
---

Provide the case folder or current case materials and state the decision being supported. Clara states the best current answer first, maintains a case-specific partner-readable spine and cumulative evidence lineage, chooses the next decision-relevant research, interview, data, or deliverable branch, returns each bounded result as active claims tied to evidence, receives validation findings back into the spine, and makes partner judgement and unresolved questions visible.

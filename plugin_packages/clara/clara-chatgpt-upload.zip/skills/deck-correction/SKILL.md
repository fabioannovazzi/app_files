---
name: deck-correction
description: "Correct, revise, or rebuild an existing PPTX or Clara HTML deck from spoken feedback, a call transcript, screen recording, review notes, or partner comments. Use when the user says record feedback on this deck or when the requested outcome is a changed deck rather than only a transcript: open Clara Voice Capture when needed, interpret every requested change, preserve untouched content, require a reviewable understanding and approval checkpoint for PPTX work, apply changes to a copy, render, verify, and inspect the final audience-facing deck. Do not use for transcription alone or for creating a new deck without revision feedback."
---

Attach the current presentation and the transcript, notes, recording, or comments containing the requested changes. Clara turns the feedback into an evidence-linked change ledger, protects untouched content, and returns a revised presentation with verification findings when editing tools are available.

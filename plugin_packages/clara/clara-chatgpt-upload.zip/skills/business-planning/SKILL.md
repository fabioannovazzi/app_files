---
name: business-planning
description: Prepare one business plan for a startup, new venture or established company: assess customers, market, operations, economics, cash needs, options and next actions. Vera and Clara use the same workflow and report.
---

Develop a business plan through repeated evidence-led decisions about customers, pricing, competitors, operations, economics and cash. Resume the same case on follow-ups, preserve revisions, explain changed assumptions and consequences, and record the next test. For financing, assess bank repayment capacity and proposed loan terms or venture market potential, milestones, runway and investor return using the same business evidence and model. Keep missing evidence explicit; do not predict approval. Vera and Clara use the identical shared workflow and report.

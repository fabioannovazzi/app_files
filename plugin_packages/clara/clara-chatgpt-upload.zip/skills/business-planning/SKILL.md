---
name: business-planning
description: Prepare one business plan for a startup, new venture or established company: assess customers, market, operations, economics, cash needs, options and next actions. Vera and Clara use the same workflow and report.
---

Prepare one business plan covering the proposition, customers and demand, operations, economics, cash needs, options, recommendation and next actions. Adapt the analysis to the business question and available evidence. Use the same shared workflow, case, financial model and report in Vera and Clara; do not assign product-specific angles or request a contribution from the other product.

---
name: business-planning
description: Prepare a strategy-led plan for a startup, new venture or established company using the shared reviewed Business Planning case and Vera's internal authoritative financial contribution.
---

State the company, its stage in plain language, the decision, audience, horizon, and selected evidence. The workflow supports startups, new ventures, and established companies. Clara develops evidence-linked findings, strategic options, recommendation, initiatives, milestones, KPIs, risks, and decision implications. Clara remains responsible for the result; if the scope needs Vera's financial contribution, she handles it internally in the same plan, exposes unresolved differences, and does not reinterpret reconciled figures or silently change accounting assumptions.

---
name: business-planning
description: Use when Clara must prepare or revise the strategic and commercial business plan of a startup, new venture, or established company, including evidence-linked findings, options, recommendation, initiatives, milestones, KPIs, risks, and a controlled handoff to Vera.
---

State the company, its stage in plain language, the decision, audience, horizon, and selected evidence. The workflow supports startups, new ventures, and established companies. Clara develops evidence-linked findings, strategic options, recommendation, initiatives, milestones, KPIs, risks, and decision implications, then prepares a reviewable handoff to Vera. Clara does not reinterpret Vera's reconciled figures or silently change accounting assumptions.

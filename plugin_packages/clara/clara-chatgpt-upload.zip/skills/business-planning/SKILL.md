---
name: business-planning
description: Use when Clara must prepare or revise a strategy-led business plan for a startup, new venture, or established company, including evidence-linked findings, options, recommendation, initiatives, milestones, KPIs, risks, and optional internal financial contribution from Vera.
---

State the company, its stage in plain language, the decision, audience, horizon, and selected evidence. The workflow supports startups, new ventures, and established companies. Clara develops evidence-linked findings, strategic options, recommendation, initiatives, milestones, KPIs, risks, and decision implications. Clara remains responsible for the result; if the scope needs Vera's financial contribution, she handles it internally in the same plan, exposes unresolved differences, and does not reinterpret reconciled figures or silently change accounting assumptions.

---
name: attribute-reporting
description: Use when a user wants Clara to map retail product attributes, preserve the existing new-versus-rest or best-seller-versus-other analysis, create a private local HTML report, or answer whether that report is correct.
---

Attach the retailer product dataset and any reviewed attribute mapping, then name the cohorts to compare. Clara maps products to the agreed category taxonomy and returns the attribute findings, exceptions, and a reviewable report.

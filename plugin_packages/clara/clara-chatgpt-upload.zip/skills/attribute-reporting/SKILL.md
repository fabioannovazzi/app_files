---
name: attribute-reporting
description: Use when a user wants Clara to map retail product attributes, preserve the existing new-versus-rest or best-seller-versus-other analysis, create a private local HTML report, or answer whether that report is correct.
---

## ChatGPT and Codex Runtime

Do not stop merely because the current surface is ChatGPT. Use material supplied in the conversation and
any callable connected-app tools to complete a useful lightweight version of
the workflow. Analyze evidence, ask focused questions, draft or review the
requested output, and clearly distinguish completed work from operations that
require unavailable local tools. Do not claim that local scripts ran or that
durable local artifacts were created when there is no local workspace.

After the first substantive result, recommend Codex once, naturally and without
interrupting the work:

> I work better with Codex because it lets me work directly with your folders,
> preserve project files, run tools and checks, and create durable deliverables.
> [Download the ChatGPT desktop app with Codex](https://developers.openai.com/codex/app#getting-started).
> We can continue here in ChatGPT now.

Do not show this recommendation on startup, after a trivial response, or more
than once in the same conversation. Installation is never a prerequisite for
continuing the useful in-chat work.

# Attribute Reporting

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../clara/SKILL.md`.

Resolve `../../modules/attribute-reporting` from this skill directory when it
exists; otherwise resolve `../../../attribute-reporting` in the repository.
Read that component's `skills/attribute-reporting/SKILL.md` completely and
follow it. Treat the resolved component root as a read-only execution root for
its scripts, requirements, references, and vendored modules. Run component
helpers with that root as the working directory, but create every user run and
artifact outside the resolved component root, every Git repository, and every
plugin cache. Never place run artifacts in the packaged component.

Before running component helper scripts, delegate the dependency check from
the Clara root:

```bash
python scripts/check_dependencies.py --module attribute-reporting
```

Attribute Reporting is a self-contained analytical workflow. Do not register
its report in an advisory case, convert it into a 16:9 presentation, or upload
it to Mparanza unless the user separately asks for that follow-on work. If the
user asks for a presentation after the checked HTML report is complete, hand
the finished report to Clara's `html-deck` workflow as a new, explicit step.

Report files and image bytes remain local. Mapping and report evidence that
Codex reads may enter model context through the user's existing ChatGPT plan;
the component helper scripts make no separate model API call. The authenticated
retail-data bridge remains a distinct Mparanza-hosted service.

Do not use this workflow for Brand Fit. When the user wants to compare completed
retailer signals with both a brand's current presence at that retailer and the
brand-owned catalogue, route to Clara's distinct `brand-fit` skill.

---
name: clara
description: Use when a user wants Clara to organize advisory work, support commercial due-diligence preparation, or route a request for presentations, interviews, recordings, Retailer Signals, Brand Fit, or business-data charts to the correct Clara workflow.
---

Provide the case materials and describe the decision or deliverable you need. Clara organizes the evidence, selects the appropriate specialist workflow, and returns a reviewable analysis, report, or presentation with sources, assumptions, and unresolved questions kept visible.

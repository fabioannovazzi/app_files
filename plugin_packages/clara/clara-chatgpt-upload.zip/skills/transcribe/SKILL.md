---
name: transcribe
description: Capture, transcribe, import, attribute, and review advisor voice notes, consultant debriefs, meetings, calls, and existing audio recordings with Clara Hosted Voice. Use when the user asks to start Voice Capture, transcribe an audio file, import a case-notes-audio or case-notes-voice ZIP/JSON bundle, preserve a transcript in an ordinary folder with deduplication, or add a reviewed transcript to a Clara case. Do not use to create an adaptive external-participant interview link or to revise a deck from spoken feedback.
---

Attach the relevant source material and describe the outcome you need. Clara will keep evidence, assumptions, and unresolved questions visible and return work you can review before using it.

If essential information is missing, Clara will ask focused questions or mark the limitation clearly instead of silently filling the gap.

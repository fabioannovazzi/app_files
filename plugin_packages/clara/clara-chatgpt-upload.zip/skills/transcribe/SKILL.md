---
name: transcribe
description: Capture, transcribe, import, attribute, and review advisor voice notes, consultant debriefs, meetings, calls, and existing audio recordings with Clara Hosted Voice. Use when the user asks to start Voice Capture, transcribe an audio file, import a case-notes-audio or case-notes-voice ZIP/JSON bundle, preserve a transcript in an ordinary folder with deduplication, or add a reviewed transcript to a Clara case. Do not use to create an adaptive external-participant interview link or to revise a deck from spoken feedback.
---

Provide the recording, identify the target case or folder, and name any known speakers. Clara produces the transcript, supports speaker attribution, and returns a reviewed evidence package with uncertain passages kept separate from advice.

"""Finalize an attribute report with a direct correctness verdict."""

from __future__ import annotations

# Direct CLI calls must select dependencies before importing workflow modules.
if __name__ == "__main__":
    import runpy as _runpy
    from pathlib import Path as _Path

    for _parent in _Path(__file__).resolve().parents:
        _launcher = _parent / "scripts" / "self_relaunch.py"
        if not _launcher.is_file():
            _launcher = _parent / "clara" / "scripts" / "self_relaunch.py"
        if _launcher.is_file():
            _runpy.run_path(str(_launcher))["ensure_running_in_managed_venv"](__file__)
            break
    else:
        # Standalone components retain their host's dependency setup.
        if any(
            (_p / "components.json").is_file()
            for _p in _Path(__file__).resolve().parents
        ):
            raise SystemExit(
                "Managed Python launcher is missing; rebuild the plugin package."
            )

import argparse
import logging
from pathlib import Path

from attribute_reporting import ContractError, finalize_report

__all__ = ["main"]

LOGGER = logging.getLogger(__name__)


def main() -> int:
    """Run mechanical and semantic-review contract checks."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    try:
        result = finalize_report(args.output_dir)
    except ContractError as exc:
        LOGGER.error("Correctness check failed to run: %s", exc)
        return 1
    LOGGER.info("Correctness verdict: %s", result["label"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

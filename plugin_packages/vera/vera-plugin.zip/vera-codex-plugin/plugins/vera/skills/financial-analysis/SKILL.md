---
name: financial-analysis
description: Use when preparing source-bound monthly P&L, working-capital, or customer-concentration evidence under Vera's accounting controls.
---

# Financial Analysis

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/financial-analysis` from this skill directory when it
exists; otherwise resolve `../../../financial-analysis` in the repository.
Read that module's `skills/financial-analysis/SKILL.md` completely and follow
it. Treat the resolved module root as the plugin working directory for all
commands.

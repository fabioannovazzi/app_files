---
name: studio-archive
description: Use when Vera must create or resume a durable client engagement, import a source, journal, or support file, search one client's callable Gmail connector, inspect a capability-gated WhatsApp Desktop chat, or search connected studio documents without mixing clients.
---

<!-- VERA_CONNECTED_KNOWLEDGE_BEGIN -->
## Connected studio knowledge

When the user or an adopted studio instruction requests relevant repository
evidence, read `../vera/references/connected-studio-knowledge.md` before the
dependent work, including direct specialist invocation. Use only callable host
search/read tools; preserve citations and this workflow's qualification gates.
Without a repository, continue ordinary work. Studio skills remain independently
invoked by the user; Vera does not dispatch them.
<!-- VERA_CONNECTED_KNOWLEDGE_END -->

<!-- VERA_OPENAI_ONBOARDING_BEGIN -->
Onboarding is optional. Continue ordinary professional work immediately,
including direct specialist invocation, without checking or completing a local
onboarding profile. Missing, unfinished, inaccessible or corrupt onboarding state,
or unavailable voice/window controls, must never block ordinary work. Do not
automatically start, resume or repeatedly offer onboarding.
Only for a user-requested tutorial or a native teaching handoff, read
`../vera/references/local-onboarding.md`. A verified paired lesson worker
executes only its bound lesson and token; never bypass tutorial validation.
Tutorial profiles, progress, examples and feedback remain local; never send a
change request, stamp a tutorial receipt or call hosted interviews for a tutorial.
Current user requests take precedence over saved preferences.
<!-- VERA_OPENAI_ONBOARDING_END -->

## Surface routing

In ChatGPT, continue with connected Gmail when its read tools are callable and
with material supplied in the conversation or an existing callable studio
knowledge repository, following the shared connected-knowledge reference.
WhatsApp Desktop control and local archive indexing remain Codex Desktop
capabilities. For those local routes,
complete any useful preparation or review available in chat, recommend Codex
using the localized wording in `../vera/SKILL.md`, and continue in ChatGPT.

# Archivio dello Studio

For a Geneva (CH-GE) mandate, read `../vera/references/localization/geneva.md` first and use this existing function’s Geneva adaptation in its resolved component skill. Language alone never selects jurisdiction.


After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

For the local client-work route, the customer folder is the portable source of
truth. Client selection, engagement creation, immutable import, exact run
preparation, start, bound execution, artifact finalization, review/completion,
recovery, rename handling, and retention must remain separate explicit steps.
The machine-local index and configuration are rebuildable aids, not the run
ledger.

For local archive delivery, show the generated `readable_archive.index_path`
(`Vera/APRI ARCHIVIO.html`) and the dated, named folders under `Vera/Pratiche/`.
These are portable, rebuildable navigation pages, not a replacement for the
exact `engagements/` ledger. A completed execution does not imply professional
approval. Check the returned readable-view status before claiming navigation
is available.

Choose the route before resolving any module:

A fresh session reuses the last explicitly approved root from the owner-private
profile after access revalidation. Existing sessions keep their own pinned root,
run selection and index. Confirmed aliases persist privately per archive root;
raw aliases are not returned in the safe client directory. If no approved root is
available, say “the archive location is not connected”; do not say the client is
unregistered or propose New client until the archive has been listed. Reuse an
existing client/engagement and the user's established choices. Before the first
copy, consolidate the selected client, engagement, sources and write permission
into one concise confirmation; internal ledger steps remain separate.


1. When the user asks to inspect WhatsApp messages, confirm that Computer Use
   can control the local WhatsApp Desktop application on the same computer.
   - If it is available, read `references/whatsapp-desktop.md` completely and
     follow it. Do not resolve the local document module as a workflow or call
     its MCP. Resolve only the bundled Studio Archive
     `scripts/whatsapp_desktop_guard.mjs` named by that reference; do not call a
     WhatsApp MCP server, use a browser, or run any other WhatsApp script.
   - If it is unavailable, explain that message inspection requires Codex
     Desktop, Computer Use, and the user's already-authenticated WhatsApp
     Desktop application. Complete any useful scope or question preparation in
     chat, use the localized Codex recommendation in `../vera/SKILL.md`, and
     continue the conversation. Do not fall back to WhatsApp Web, a Mparanza
     server, exported chats, or an unofficial API.
2. When the user asks to search Gmail or email, check whether Gmail
   `get_profile`, `search_emails`, and `batch_read_email` are callable.
   - If they are callable, read `references/marketplace-gmail.md` completely and
     follow it. Do not resolve the local module, call Studio Archive MCP tools,
     or run local scripts.
   - If they are unavailable, say that the separately distributed OpenAI Gmail
     connector must be installed, enabled, and connected on the current
     surface. Do not use IMAP, browser scraping, or ask the user to save `.eml`
     files.
3. When the user asks to search an existing connected studio knowledge
   repository, follow `../vera/references/connected-studio-knowledge.md` using
   its callable search/read tools. This route needs no local document module,
   archive configuration or Microsoft 365 account. Keep Gmail and WhatsApp on
   their dedicated routes above.
4. When the user asks to identify or create a client workspace, import or
   resume a source, journal, or support engagement, or configure, refresh, or
   search local studio documents, resolve `../../modules/studio-archive` from
   this skill directory when it exists; otherwise resolve
   `../../../studio-archive` in the repository. Read that module's
   `skills/studio-archive/SKILL.md` completely and follow it. Treat the resolved
   module root as the plugin working directory for local commands, scripts,
   requirement files, MCP tools, and archive state.
   When `list_studio_archive_clients` reports `configured: false` and
   `setup_required: true`, tell the user that Vera will open the operating
   system's folder chooser and call `setup_studio_archive` before asking for an
   absolute path. Request a path manually only when that guided action returns
   `archive_folder_picker_unavailable`; cancellation means no configuration was
   written and should lead to an offer to reopen the chooser.

The Gmail, WhatsApp Desktop, connected knowledge, and local document routes
are independent. Gmail uses OpenAI's separately connected connector in ChatGPT
or Codex. WhatsApp is
an on-demand view of the local application through Computer Use. There is no
Vera or Mparanza WhatsApp webhook, background sync, hosted connector, message
database, or retention period. WhatsApp content read for the task may still
enter the model context of the user's selected Codex or ChatGPT account.

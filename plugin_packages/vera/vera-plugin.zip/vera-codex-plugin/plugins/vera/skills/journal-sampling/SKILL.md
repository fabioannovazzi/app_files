---
name: journal-sampling
description: Use when qualifying accounting journal entries from reviewed CSV or Excel sources, normalizing exact monetary rows, and generating reproducible audit samples with diagnostics.
---

# Journal Sampling

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

In local Codex, use a prepared and started customer-folder run bound to one
exact immutable journal receipt. Finalize every output with purpose and
audience. The normalized population, diagnostics, and exact sample are separate
upstream artifacts. Start Vouching through
`start_check_entries_from_sample`; Studio Archive resolves those internal
artifacts and Vouching checks only the sample rows.

Resolve `../../modules/journal-sampling` from this skill directory when it
exists; otherwise resolve `../../../journal-sampling` in the repository. Read
that module's `skills/journal-sampling/SKILL.md` completely and follow it. Treat
the resolved module root as the plugin working directory for all commands.

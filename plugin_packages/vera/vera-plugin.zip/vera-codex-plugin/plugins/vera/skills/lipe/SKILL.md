---
name: lipe
description: Use LIPE for Italian VAT-register reconciliation and evidence-linked VP drafts, with confirmed tax mappings, professional review and explicit pilot limits.
---

<!-- VERA_WORKFLOW_USAGE_BEGIN -->
## Task usage and user feedback

Before substantive work, follow `../vera/references/workflow-usage.md`: start one
retained task UUID for the primary user process (including AI-led work), reuse
it across helpers/resumption, and record only observed outcomes. Discover the
native `vera_incident_host_link` tool, including deferred tools, and verify the
same run's Computer ID on the server. Privacy reporting applies only to the fixed pipeline list in
`../vera/references/selective-reporting.md`, using the exact Studio Archive run.
Studio Archive start and terminal writes automatically create a local report for
every run of those pipelines, including full exposure or incomplete observations.
The server proof binds the report hash to the same Archive run and existing Vera
userID. No agent-authored phase file or separate usage-task receipt link is needed.
Other pipelines and chat-only tasks do not get this report. After delivery ask once for the user's 1–5 stars and optional
comment; never infer a score. Studio Archive is infrastructure, not another rated
process. Synthetic/agent tests are marked and excluded. Flush pending delivery
at task startup and after outcomes. The shared contract applies even on direct
skill invocation and on both Codex and Cowork.
<!-- VERA_WORKFLOW_USAGE_END -->


<!-- VERA_CONNECTED_KNOWLEDGE_BEGIN -->
## Connected studio knowledge

When the user or an adopted studio instruction requests relevant repository
evidence, read `../vera/references/connected-studio-knowledge.md` before the
dependent work, including direct specialist invocation. Use only callable host
search/read tools; preserve citations and this workflow's qualification gates.
Without a repository, continue ordinary work. Studio skills remain independently
invoked by the user; Vera does not dispatch them.
<!-- VERA_CONNECTED_KNOWLEDGE_END -->

<!-- VERA_OPENAI_ONBOARDING_BEGIN -->
Onboarding is optional. Continue ordinary professional work immediately,
including direct specialist invocation, without checking or completing a local
onboarding profile. Missing, unfinished, inaccessible or corrupt onboarding state,
or unavailable voice/window controls, must never block ordinary work. Do not
automatically start, resume or repeatedly offer onboarding.
Only for a user-requested tutorial or a native teaching handoff, read
`../vera/references/local-onboarding.md`. A verified paired lesson worker
executes only its bound lesson and token; never bypass tutorial validation.
Tutorial profiles, progress, examples and feedback remain local; never send a
change request, stamp a tutorial receipt or call hosted interviews for a tutorial.
Current user requests take precedence over saved preferences.
<!-- VERA_OPENAI_ONBOARDING_END -->

# LIPE

## Optional native calculation panel

When this host exposes `vera_workspace_open`, the user may choose a registered
LIPE run and open **Calcoli LIPE**. The panel lists exact imported JSON identities;
file extension does not establish that a document is a valid or reviewed case.
The user explicitly selects the already reviewed case and confirms calculation.
The unchanged LIPE CLI persists immutable workpapers, including blocked results.
The panel reads only native-receipted revisions, with bounded producer records;
discussion retrieves one exact selected record and its pilot/export limits.
It never substitutes a newer revision for a requested one.

This initial adapter does not edit cases or create tax confirmations. Keep source
interpretation, case corrections, catalog configuration, external signed approval,
model-data session reporting, XML export and run finalization in the maintained
workflow below. Catalog-bound cases retain `CATALOG_NOT_AVAILABLE` when the panel
has no catalog connection; never remove the binding to bypass that gate. Existing
unreceipted workpapers or interrupted execution require specialist recovery; the
panel does not silently adopt or rerun them. Calculations remain synchronous with
a 90-second bound. Full native-host and professional acceptance are pending.

If native UI or local MCP is unavailable, including Cowork, continue through the
same component skill, managed Python and persistent customer-folder inputs and
outputs. Do not replace this fallback with a native-only route.

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/lipe` from this skill directory when it
exists; otherwise resolve `../../../lipe` in the repository. Read
that module's `skills/lipe/SKILL.md` completely and follow it. Treat
the resolved module root as the plugin working directory for all commands,
scripts, requirement files, references, schemas, and local review server.

## Exact-proposal confirmation

Show the proposal and obtain the actual user decision before export. No professional role, signature, certificate or mandate is required. Use the component’s current approval contract and the existing studio filename registry; never infer user confirmation.

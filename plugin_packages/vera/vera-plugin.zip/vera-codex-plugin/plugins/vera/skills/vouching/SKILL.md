---
name: vouching
description: Use to check scritture campionate against fatture FatturaPA XML or supporting PDFs, using the qualified sample and lineage from Journal Sampling. Produces source-linked checks, exceptions and missing-document requests for those entries. To select the sample use journal-sampling; to review the whole passive-invoice population against booked entries use purchase-invoice-review.
---

<!-- VERA_WORKFLOW_USAGE_BEGIN -->
## Task usage and user feedback

Before substantive work, follow `../vera/references/workflow-usage.md`: start one
retained task UUID for the primary user process (including AI-led work), reuse
it across helpers/resumption, and record only observed outcomes. Discover the
native `vera_incident_host_link` tool, including deferred tools, and verify the
same run's Computer ID on the server. Privacy reporting applies only to the fixed pipeline list in
`../vera/references/selective-reporting.md`, using the exact Studio Archive run.
Studio Archive start and terminal writes automatically create a local report for
every run of those pipelines, including full exposure or incomplete observations.
The server proof binds the report hash to the same Archive run and existing Vera
userID. No agent-authored phase file or separate usage-task receipt link is needed.
Other pipelines and chat-only tasks do not get this report. After delivery ask once for the user's 1–5 stars and optional
comment; never infer a score. Studio Archive is infrastructure, not another rated
process. Synthetic/agent tests are marked and excluded. Start and record deliver
only the retained task's events. Retry with
`workflow_usage.py flush --run-id <retained-uuid>`; unrelated queued events do not
block this task. The shared contract applies even on direct skill invocation
and on both Codex and Cowork.
<!-- VERA_WORKFLOW_USAGE_END -->


<!-- VERA_CONNECTED_KNOWLEDGE_BEGIN -->
## Connected studio knowledge

When the user or an adopted studio instruction requests relevant repository
evidence, read `../vera/references/connected-studio-knowledge.md` before the
dependent work, including direct specialist invocation. Use only callable host
search/read tools; preserve citations and this workflow's qualification gates.
Without a repository, continue ordinary work. Studio skills remain independently
invoked by the user; Vera does not dispatch them.
<!-- VERA_CONNECTED_KNOWLEDGE_END -->

<!-- VERA_OPENAI_ONBOARDING_BEGIN -->
Onboarding is optional. Continue ordinary professional work immediately,
including direct specialist invocation, without checking or completing a local
onboarding profile. Missing, unfinished, inaccessible or corrupt onboarding state,
or unavailable voice/window controls, must never block ordinary work. Do not
automatically start, resume or repeatedly offer onboarding.
Only for a user-requested tutorial or a native teaching handoff, read
`../vera/references/local-onboarding.md`. A verified paired lesson worker
executes only its bound lesson and token; never bypass tutorial validation.
Tutorial profiles, progress, examples and feedback remain local; never send a
change request, stamp a tutorial receipt or call hosted interviews for a tutorial.
Current user requests take precedence over saved preferences.
<!-- VERA_OPENAI_ONBOARDING_END -->

# Vouching

For an already prepared checks run, use `vera_workspace_open` when callable and
the exact Studio Archive run has a trusted operator binding. Read
`../vera/references/native-workspace.md` before the handoff. The panel uses the
existing checks review service; discussion retrieves only the selected semantic
case with exact identifiers omitted by default. Preserve the qualified sample
boundary, support lineage, missing-document findings and professional decisions.
Preparation and new support batches remain in the specialist/Studio Archive
route below. Without native tools or a trusted binding, continue persistent
specialist work, including in Cowork; do not expand the sample population.

For a Geneva (CH-GE) mandate, read `../vera/references/localization/geneva.md` first and use this existing function’s Geneva adaptation in its resolved component skill. Language alone never selects jurisdiction.


Use the localized public name: **Vouching** (en), **Verifica documentale** (it),
**Contrôle sur pièces** (fr), **Belegprüfung** (de), and
**Verificación documental** (es). Explain that the workflow compares sampled
entries with supporting documents. The skill identifier is `vouching`.

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

In local Codex, call `start_check_entries_from_sample` once per support evidence
batch with the selected Journal Sampling run and immutable support receipts.
Studio Archive resolves and validates the complete internal artifact handoff;
do not ask the user to name files or assemble artifact references. Execute only
the returned run-local bindings, check only sampled rows, and finalize every
output with purpose and audience before review/completion. Use the explicit
new-run option for an intentionally separate batch whose exact input selection
matches an earlier run.

First follow `../vera/references/execution-recovery.md` for component
`check-entries`. Use its verified execution root for the handoff below;
never ask the professional to run a terminal command.

Resolve `../../modules/check-entries` from this skill directory when it exists;
otherwise resolve `../../../check-entries` in the repository. Read that
module's `skills/vouching/SKILL.md` completely and follow it. Treat the
resolved module root as the plugin working directory for all commands.

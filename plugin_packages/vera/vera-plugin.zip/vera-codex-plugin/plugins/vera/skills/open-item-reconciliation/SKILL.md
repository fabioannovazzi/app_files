---
name: open-item-reconciliation
description: Use when a reported open-item population must be tested at a cut-off against ledgers, statements, payments, factoring, advances, or compensation to determine which items are closed, partly closed, or still open. For direct bank-statement-to-journal matching, use journal-bank-reconciliation.
---

<!-- VERA_OPENAI_ONBOARDING_BEGIN -->
Onboarding is optional. Continue ordinary professional work immediately,
including direct specialist invocation, without checking or completing a local
onboarding profile. Missing, unfinished, inaccessible or corrupt onboarding state,
or unavailable voice/window controls, must never block ordinary work. Do not
automatically start, resume or repeatedly offer onboarding.
Only for a user-requested tutorial or a native teaching handoff, read
`../vera/references/local-onboarding.md`. A verified paired lesson worker
executes only its bound lesson and token; never bypass tutorial validation.
Tutorial profiles, progress, examples and feedback remain local; never send a
change request, stamp a tutorial receipt or call hosted interviews for a tutorial.
Current user requests take precedence over saved preferences.
<!-- VERA_OPENAI_ONBOARDING_END -->

# Riconciliazione partite

For a Geneva (CH-GE) mandate, read `../vera/references/localization/geneva.md` first and use this existing function’s Geneva adaptation in its resolved component skill. Language alone never selects jurisdiction.


After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/open-item-reconciliation` from this skill directory when it
exists; otherwise resolve `../../../open-item-reconciliation` in the repository.
Read that module's `skills/open-item-reconciliation/SKILL.md` completely and follow
it. Treat the resolved module root as the plugin working directory for scripts,
requirements, assets, review servers, and outputs.

For a new Vera run, pass `--output-subdirectory reconciliation` to the native
`raw_input_runner.py` command. Keep that same option on regeneration. The native
assured package is then in the bound run's `outputs/reconciliation/`; use that
directory for its review server and assurance validation. Write the required
local model-data disclosure in the owning `outputs/` directory, outside the
exact native assurance boundary. Declare both the nested package and disclosure
when finalizing the Studio Archive run. Never add the disclosure to an already
sealed native assurance directory or alter its receipt to make extra files pass.

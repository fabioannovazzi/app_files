---
name: adversarial-opinion
description: Develop and review the strongest evidence-bound opposing case when Vera is asked for an opinion on a concrete legal, tax or compliance position or explicitly for an opposing opinion. Informational research alone does not activate it; respect an instruction to omit it.
---

<!-- VERA_CONNECTED_KNOWLEDGE_BEGIN -->
## Connected studio knowledge

When the user or an adopted studio instruction requests relevant repository
evidence, read `../vera/references/connected-studio-knowledge.md` before the
dependent work, including direct specialist invocation. Use only callable host
search/read tools; preserve citations and this workflow's qualification gates.
Without a repository, continue ordinary work. Studio skills remain independently
invoked by the user; Vera does not dispatch them.
<!-- VERA_CONNECTED_KNOWLEDGE_END -->

<!-- VERA_OPENAI_ONBOARDING_BEGIN -->
Onboarding is optional. Continue ordinary professional work immediately,
including direct specialist invocation, without checking or completing a local
onboarding profile. Missing, unfinished, inaccessible or corrupt onboarding state,
or unavailable voice/window controls, must never block ordinary work. Do not
automatically start, resume or repeatedly offer onboarding.
Only for a user-requested tutorial or a native teaching handoff, read
`../vera/references/local-onboarding.md`. A verified paired lesson worker
executes only its bound lesson and token; never bypass tutorial validation.
Tutorial profiles, progress, examples and feedback remain local; never send a
change request, stamp a tutorial receipt or call hosted interviews for a tutorial.
Current user requests take precedence over saved preferences.
<!-- VERA_OPENAI_ONBOARDING_END -->

# Parere contrapposto

Resolve `../../modules/deep-research-validator` from this skill directory when
it exists; otherwise resolve `../../../deep-research-validator` in repository
source. Read its `skills/adversarial-opinion/SKILL.md` completely and follow it.
Treat the Vera root as the invoking product root. The method, scope rule,
durable helper and comparison checks are shared with the other product.
Do not fork the method or add an opposing examination to informational research.

For a supplied position without a reviewed original and answer contract, first
follow `../quesito-legale-fiscale/SKILL.md`. Review the opposing result with
`../legal-tax-answer-review/SKILL.md`; do not recursively request an opposing
opinion about the opposing opinion. Final choices remain with the professional.

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

#!/usr/bin/env python3
"""Manage persistent Python dependency targets for packaged plugins."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import sysconfig
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

__all__ = [
    "READY_FILENAME",
    "RuntimeSelection",
    "activate_runtime",
    "dependency_target",
    "ensure_runtime",
    "main",
    "plugin_data_dir",
    "requirements_fingerprint",
    "runtime_environment",
    "runtime_key",
    "runtime_python",
    "select_runtime",
]

Runner = Callable[..., subprocess.CompletedProcess[str]]
READY_FILENAME = ".mparanza-python-runtime.json"
DEPENDENCY_DIR_NAME = "python-dependencies"
LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class RuntimeSelection:
    """One plugin or component dependency scope."""

    plugin_root: Path
    requirement_root: Path
    requirements_file: Path
    scope: str


def _included_requirement_files(
    path: Path,
    *,
    seen: set[Path] | None = None,
) -> list[Path]:
    """Return a requirement file and its recursive local includes."""

    visited = seen if seen is not None else set()
    resolved = path.resolve()
    if resolved in visited:
        return []
    visited.add(resolved)
    files = [resolved]
    for raw_line in resolved.read_text(encoding="utf-8").splitlines():
        line = raw_line.split("#", 1)[0].strip()
        include = ""
        if line.startswith("-r "):
            include = line[3:].strip()
        elif line.startswith("--requirement "):
            include = line[len("--requirement ") :].strip()
        if include:
            files.extend(
                _included_requirement_files(resolved.parent / include, seen=visited)
            )
    return files


def select_runtime(plugin_root: Path, module: str | None = None) -> RuntimeSelection:
    """Resolve the requirements owned by a plugin or embedded component."""

    root = plugin_root.resolve()
    if module is None:
        requirement_root = root
        scope = "core"
    else:
        try:
            components = json.loads(
                (root / "components.json").read_text(encoding="utf-8")
            )["plugins"]
        except (OSError, KeyError, TypeError, json.JSONDecodeError) as error:
            raise ValueError("Plugin component registry is unavailable") from error
        if not isinstance(components, list) or not all(
            isinstance(name, str) for name in components
        ):
            raise ValueError("Plugin component registry is unavailable")
        if module not in components:
            raise ValueError(f"Unknown plugin component: {module}")
        packaged = root / "modules" / module
        source = root.parent / module
        requirement_root = packaged if packaged.is_dir() else source
        scope = f"modules/{module}"
    requirements_file = requirement_root / "requirements.txt"
    if not requirement_root.is_dir():
        raise ValueError(f"Unknown plugin component: {module}")
    if not requirements_file.is_file():
        raise ValueError(f"Requirements file not found: {requirements_file}")
    return RuntimeSelection(
        plugin_root=root,
        requirement_root=requirement_root.resolve(),
        requirements_file=requirements_file.resolve(),
        scope=scope,
    )


def requirements_fingerprint(selection: RuntimeSelection) -> str:
    """Return a stable fingerprint for the selected requirement graph."""

    digest = hashlib.sha256()
    for path in _included_requirement_files(selection.requirements_file):
        try:
            relative = path.relative_to(selection.plugin_root)
        except ValueError:
            relative = path.relative_to(selection.requirement_root)
        digest.update(relative.as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()[:16]


def runtime_key() -> str:
    """Return the Python ABI and platform key for native wheel compatibility."""

    implementation = getattr(sys.implementation, "cache_tag", None) or "python"
    platform = sysconfig.get_platform().replace("/", "-").replace("\\", "-")
    return f"{implementation}-{platform}"


def plugin_data_dir(plugin_root: Path) -> Path:
    """Return the persistent user-scoped data directory for one plugin."""

    configured = os.environ.get("CLAUDE_PLUGIN_DATA") or os.environ.get("PLUGIN_DATA")
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path.home() / ".cache" / "mparanza" / plugin_root.resolve().name).resolve()


def dependency_target(
    selection: RuntimeSelection,
    data_dir: Path | None = None,
) -> Path:
    """Return the selected fingerprinted dependency target."""

    base = (
        data_dir.resolve()
        if data_dir is not None
        else plugin_data_dir(selection.plugin_root)
    )
    return (
        base
        / DEPENDENCY_DIR_NAME
        / selection.scope
        / runtime_key()
        / requirements_fingerprint(selection)
    )


def runtime_environment(target: Path) -> dict[str, str]:
    """Return an environment bound to the managed virtual environment."""

    environment = dict(os.environ)
    executable = runtime_python(target)
    existing_path = environment.get("PATH")
    environment["PATH"] = (
        f"{executable.parent}{os.pathsep}{existing_path}"
        if existing_path
        else str(executable.parent)
    )
    environment["VIRTUAL_ENV"] = str(target)
    environment.pop("PYTHONHOME", None)
    environment["MPARANZA_MANAGED_RUNTIME_VERIFY"] = "1"
    return environment


def runtime_python(target: Path) -> Path:
    """Return the Python executable inside a managed virtual environment."""

    candidates = (
        target / "Scripts" / "python.exe",
        target / "bin" / "python3",
        target / "bin" / "python",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return candidates[0] if os.name == "nt" else candidates[-1]


def _receipt_payload(selection: RuntimeSelection) -> dict[str, object]:
    return {
        "schema_version": 1,
        "plugin": selection.plugin_root.name,
        "scope": selection.scope,
        "requirements_fingerprint": requirements_fingerprint(selection),
        "runtime_key": runtime_key(),
    }


def _receipt_matches(selection: RuntimeSelection, target: Path) -> bool:
    try:
        payload = json.loads((target / READY_FILENAME).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return payload == _receipt_payload(selection)


def _validation_command(selection: RuntimeSelection, target: Path) -> list[str]:
    checker = selection.requirement_root / "scripts" / "check_dependencies.py"
    if not checker.is_file():
        raise ValueError(f"Dependency checker not found: {checker}")
    command = [str(runtime_python(target)), str(checker)]
    if selection.scope == "core":
        command.append("--managed-verify")
    return command


def _dependencies_ready(
    selection: RuntimeSelection,
    target: Path,
    *,
    runner: Runner,
    require_receipt: bool,
) -> bool:
    """Return whether the target satisfies the selected dependency checker."""

    if not target.is_dir():
        return False
    if not runtime_python(target).is_file():
        return False
    if require_receipt and not _receipt_matches(selection, target):
        return False
    try:
        completed = runner(
            _validation_command(selection, target),
            cwd=selection.requirement_root,
            env=runtime_environment(target),
            capture_output=True,
            check=False,
            text=True,
        )
    except (OSError, subprocess.SubprocessError, ValueError):
        return False
    return completed.returncode == 0


def ensure_runtime(
    plugin_root: Path,
    module: str | None = None,
    *,
    data_dir: Path | None = None,
    runner: Runner = subprocess.run,
) -> tuple[bool, Path, str]:
    """Install or reuse one persistent managed dependency target."""

    selection = select_runtime(plugin_root, module)
    target = dependency_target(selection, data_dir)
    if _dependencies_ready(
        selection,
        target,
        runner=runner,
        require_receipt=True,
    ):
        return True, target, f"Python runtime ready at {target}"

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            shutil.rmtree(target)
    except OSError as error:
        return False, target, str(error)
    try:
        created = runner(
            [sys.executable, "-m", "venv", str(target)],
            cwd=selection.requirement_root,
            capture_output=True,
            check=False,
            text=True,
        )
        if created.returncode != 0:
            detail = (created.stderr or created.stdout).strip()
            shutil.rmtree(target, ignore_errors=True)
            return False, target, detail or "virtual environment creation failed"
        installed = runner(
            [
                str(runtime_python(target)),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "--no-input",
                "-r",
                str(selection.requirements_file),
            ],
            cwd=selection.requirement_root,
            capture_output=True,
            check=False,
            text=True,
        )
        if installed.returncode != 0:
            detail = (installed.stderr or installed.stdout).strip()
            shutil.rmtree(target, ignore_errors=True)
            return False, target, detail or "pip install returned a non-zero status"
        if not _dependencies_ready(
            selection,
            target,
            runner=runner,
            require_receipt=False,
        ):
            shutil.rmtree(target, ignore_errors=True)
            return (
                False,
                target,
                "Declared requirements remained unavailable after installation",
            )
        (target / READY_FILENAME).write_text(
            json.dumps(_receipt_payload(selection), sort_keys=True) + "\n",
            encoding="utf-8",
        )
        return True, target, f"Python runtime installed at {target}"
    except (OSError, subprocess.SubprocessError) as error:
        shutil.rmtree(target, ignore_errors=True)
        return False, target, str(error)


def activate_runtime(plugin_root: Path, module: str | None = None) -> Path | None:
    """Return a ready managed virtual environment without installing anything."""

    try:
        selection = select_runtime(plugin_root, module)
        target = dependency_target(selection)
    except (OSError, ValueError):
        return None
    if not _receipt_matches(selection, target):
        return None
    return target


def main(plugin_root: Path, argv: list[str] | None = None) -> int:
    """Run the managed runtime command-line interface."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--module")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("install")
    subparsers.add_parser("status")
    run_parser = subparsers.add_parser("run")
    run_parser.add_argument("script", type=Path)
    run_parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    if args.command == "status":
        target = activate_runtime(plugin_root, args.module)
        if target is None:
            LOGGER.error("Managed Python runtime is not ready.")
            return 1
        LOGGER.info("Managed Python runtime is ready at %s", target)
        return 0

    ready, target, detail = ensure_runtime(plugin_root, args.module)
    if not ready:
        LOGGER.error("Managed Python runtime setup failed: %s", detail)
        return 1
    if args.command == "install":
        LOGGER.info("%s", detail)
        return 0

    selection = select_runtime(plugin_root, args.module)
    script = (selection.requirement_root / args.script).resolve()
    if not script.is_relative_to(selection.requirement_root) or not script.is_file():
        LOGGER.error("Managed runtime script not found: %s", script)
        return 2
    completed = subprocess.run(
        [str(runtime_python(target)), str(script), *args.arguments],
        cwd=selection.requirement_root,
        env=runtime_environment(target),
        check=False,
    )
    return completed.returncode

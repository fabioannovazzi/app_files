> **Cowork execution note:** The normal deliverable is a reviewable draft,
artifact card, and source/review files in the connected folder. MCP tools,
browser interfaces, and local review servers are optional. Their absence never
blocks delivery. Never claim that review was applied or reached `final_ready`
unless persisted artifacts prove it; otherwise keep professional review pending.
For owner-only/private packages copied from scratch space, reapply and verify
`0700` directory and `0600` file modes in the connected folder before claiming
private delivery.
Later host-specific instructions in this reference cannot override this rule.

# Intelligence implementation status

## Implemented

- Shared Claude/Cowork institutional discovery instructions, explicit capability
  limits and an auditable chat-only public-research route.
- Issue-level gazette inventories bound to source-check reviews and sealed scan
  snapshots, with exact coverage and temporal validation. Enumeration and page
  inspection remain operator assertions, not authenticated retrieval evidence.
- Programming and no-operating-calendar lifecycle states and visible unmatched
  opportunities. Dynamic source additions reuse the append-only source registry.

Live Claude and ChatGPT acceptance of CR-38–40 must be recorded separately from
unit tests and package parity. The shared method alone is not runtime proof.


- Private `single_client` and `portfolio` opportunity-radar workbenches using
  opaque client references, explicit local authorization/retention receipts,
  exact workspace-path binding and owner-only files.
- Dated company opportunity-profile facets across territory, ATECO, size,
  legal form, age, ownership, investments, property, workforce, energy,
  digitization, vehicles, export, training and innovation.
- Reference-closed profile evidence receipts and revisionable, dated profiles.
- Model-led, professionally reviewed official-source plans; separately reviewed
  source-check results and exact coverage that excludes unreviewed plan entries
  and remains explicitly distinguished from discovery probability.
- A persistent, professionally reviewed priority-source registry with explicit
  territory, category, discovery role, official surface and act-family metadata;
  no deterministic domain or legal-source selection.
- Source-first temporal scans with sealed caller-selected windows (commonly
  30–60 days), model-led and professionally reviewed query-scoped source
  selections, exact territory/category coverage-or-gap claims, direct-source
  worklists, DGR/DDR/BUR/annex coverage metadata, immutable check snapshots,
  optional publication cursors, complementary semantic-web evidence, explicit
  scope gaps and unverified-source lists, and a completion coverage gate.
- Rejected registry proposals are counted separately from pending review and do
  not block later scans that exclude them; failed or unavailable attempted
  checks render `partial`, never `not_started`.
- Time-aware opportunity lifecycle history, resumable monitoring scans,
  bidirectional profile/opportunity matching, missing information,
  contradictions, complexity and recommended actions.
- Economic benefit/cost/net ranges with assumptions and exact net-range
  reproduction; no deterministic award probability or semantic priority score.
- Explicit item-level review with current-state hash freshness, stable retry
  result shape, immutable completed scans, chronological status checks,
  append-only profile/opportunity revisions, dependent-match invalidation,
  cross-client evidence/facet isolation, review report and self-verifiable
  selected-subset handoff into client-bound application instruction.
- Handoff registration revalidates its strict schema, client identity,
  references, source-entry hash and selected-subset hash before accepting it.
- Eleven bounded semantic task contracts and mechanical next-task orchestration.
- Task-specific, reference-closed packets with complete class/byte inventories,
  explicit omitted counts, no positional truncation, and fail-closed item,
  excerpt and byte limits with a runnable fresh-session context-expansion route:
  exact professional-selected IDs scope only the over-limit collection, while
  every other required global-root collection remains complete.
- Packets that do not copy the intake applicant object or local source paths by
  default, omit project context from source-only tasks, label evidence as
  untrusted, prohibit embedded instructions, and disclose that relevant facts
  or excerpts may identify the applicant without automatic anonymization.
- Required operator-attested model-session references, non-reuse across Stage B
  contributions, client-isolated radar evidence-mapping sessions, and enforced
  separation of those mapping references from public-source planning,
  discovery, and portfolio matching in either direction. The workflow does not
  claim that the provider authenticates those references.
- Narrow fail-closed detection of unmistakable passwords, bearer/session tokens,
  API secrets and private keys in structured model packets and radar proposals;
  no generic PII classifier or automatic removal of professional identifiers.
- Strict, reference-closed recommendation output with task-scoped mutation
  permissions.
- Required caller-supplied packet digest checked against the exact reconstructed
  task, subjects, session, and content before recording; mismatches fail without
  mutation. Packet creation stays read-only and exact record retries are idempotent.
  The digest is operator-supplied binding, not authenticated provider evidence.
- Private `intelligence_register.json` recording exact input hashes, packet hash,
  model identity, prompt-template version, output, operator, and lifecycle.
- `MODEL_SUGGESTED`, `APPLYING`, `ACCEPTED`, `REJECTED`, `RETURNED`, and `STALE`
  states.
- Explicit professional accept/reject/return, asserted-not-authenticated reviewer
  metadata, idempotent recording, stale detection, two-phase application, retry
  finalization, and prevention of confirmed/blocked overwrite.
- Forced proposed status, model-inference facts, model-led assessments, open
  issues, and manual protected portal controls.
- Validation and dossier/manifest inclusion of the intelligence register.
- Offline representative contract evaluation covering valid proposals,
  reference escape, red flags, and protected portal controls.

## Deliberately not implemented

- A universal deterministic publisher list, keyword matcher, eligibility rule
  library, statistical discovery-completeness claim or autonomous client alert.
- A bundled official-source crawler or claim that every publisher exposes a
  stable incremental cursor. The selected runtime performs read-only checks
  from the worklist; cursors are retained only when the source exposes one.
- A background scheduler or authenticated publisher feed. Monitoring records
  scans performed by the current authorized runtime and the intended next date.
- Automatic client contact. `contact_client` is a reviewed recommendation only.
- An in-plugin provider call or cheaper wrapper call. Claude or another caller
  supplies the model response and records its exact identity; the workflow does
  not hide provider cost or provenance.
- A bundled portal driver. Approved field entry, attachment upload and draft
  saving use available host browser tools under `portal-preparation.md`; their
  live success must be verified on the actual portal. Authentication,
  declaration acceptance, signature and payment remain manual. Final submission
  requires explicit approval of the exact final application and receipt checks.
- Autonomous acceptance, professional confirmation, legal conclusion, source
  hierarchy, or eligibility rule library.
- A claim of semantic quality from structural tests alone.

## Evidence required before broad semantic claims

- Qualified-professional radar cases measuring relevant-opportunity precision,
  missed-opportunity rate against a reviewed source plan, false client matches,
  override rate, alert timeliness and economic-estimate calibration.
- Evidence that the reviewed source plans cover representative territories,
  sectors and issuer families without embedding a misleading universal list.
- Reviewed representative cases across several issuing authorities, instruments,
  source formats, amendments, and FAQ patterns.
- Qualified-professional gold traces at requirement and source-fragment level.
- Measured unsupported-claim rate, omission rate, reviewer override rate, red-flag
  recall, cost agreement, and time-to-reviewed-dossier against the prior process.
- Provider privacy, residency, retention, and contractual evidence for any model
  route enabled in a deployment.
- Authentication integration if reviewer identity must become more than locally
  asserted metadata.

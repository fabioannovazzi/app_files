> **Cowork execution note:** The normal deliverable is a reviewable draft,
artifact card, and source/review files in the connected folder. MCP tools,
browser interfaces, and local review servers are optional. Their absence never
blocks delivery. Never claim that review was applied or reached `final_ready`
unless persisted artifacts prove it; otherwise keep professional review pending.
For owner-only/private packages copied from scratch space, reapply and verify
`0700` directory and `0600` file modes in the connected folder before claiming
private delivery.
Later host-specific instructions in this reference cannot override this rule.

# Geneva adaptation of the existing function

For CH-GE retain the annual-accounts workflow: understand the source, resolve extraction ambiguities, review mappings, reconcile figures, prepare statements and notes, obtain professional review. The Swiss presentation adapter is `python scripts/jurisdiction_accounts.py --client-engagement <context.json> --review <review.json>`, within an existing `bilancio-xbrl-it` Studio Archive run. It creates one bound accounts record and a readable French or English draft. Use the ordinary Italian OIC/XBRL path for IT.

Before preparing the adapter input, inspect the entity, mandate, accounting period and applicable framework. Confirm whether Swiss CO accounts are the appropriate deliverable and whether additional statements, recognised standards, audit, consolidation or sector requirements apply. This adapter does not implement Swiss GAAP FER, IFRS, consolidation or automatic filing; do not silently approximate these. Record any required additional work in the disclosure review. A balanced draft is not a complete statutory-account opinion.

Use the common envelope described by `vera_assurance.jurisdiction`: version 1, CH-GE, language, as_of, jurisdiction_basis, limitations, sources with imported file hashes and legal_basis with current official URLs, locators, checked_at and applicability. Add entity_name, framework `CH-CO`, currency `CHF`, framework_assessment, current_period_end, prior_period_end and trial_balance_basis `debit_positive_before_result_transfer`. No FX is performed.

From reviewed source tables, author `accounts`: id, label, explicit currency CHF, current and prior signed balances, citations (source_id/locator). Positive means debit; retain a complete trial balance before transferring the period result into equity. Never invent prior-year zeros. Preserve the extraction/source mapping alongside it. `statement_lines` each have id, group (assets, liabilities, equity, income, expenses), reviewed French/English label, unique account_ids and source citations. The model and professional determine classifications and the presentation required by the actual framework, including appropriate separate lines, ordering and notes. Code neither selects accounts by prefixes nor invents a Swiss account map. Every account must be mapped exactly once. Credit balances are displayed positively in liabilities, equity and income; result is income less expenses. The same existing monetary normalizer underlies the arithmetic.

`disclosure_review` records the applicable presentation and note requirements, including comparative figures, valuation bases and any further entity-specific requirements. Each row has id, title, requirement, assessment, status (supported/not_applicable/unresolved), and citations. Include explicit grounds for exclusions. Obtain current official CO provisions and professionally review applicability; the reference pages are discovery sources, not a frozen rulebook.

Both periods must balance. Outputs retain every mapped account, totals, result, reconciliation, open disclosure items and source hashes. No Italian taxonomy, OIC rule or XBRL is applied. Professional decisions bind the exact input and calculated results using proposal_sha256, reviewer_ref, reviewed_at and conclusion. Filing remains false; the professional determines statutory completeness and any final format.

Official starting sources and the complete catalogue assessment are in Vera’s `references/localization/geneva/`. Verify current applicability for each actual case.

---
name: concordato-plan-review
description: Use when a user wants Claude to organize and review an Italian concordato preventivo case across procedure, proposal, plan, attestation, creditors and treatment, liquidation alternative, sources and uses, liquidity, feasibility evidence, and accounting consistency. Numerical tie-out is an optional appendix.
---

## Output Location Rule

Never write run outputs inside this Git workspace or a published folder. Use
only the Studio Archive run path described below.

## Client engagement gate

Select one Studio Archive client and engagement, import the case sources, then
call `prepare_studio_client_workflow` with workflow ID
`concordato-plan-review`. Pass the returned `client_engagement_path` as
`--client-engagement` to the review runner, reviewer-confirmation helpers,
assurance replay, and every review writer. Include the same path in MCP review
calls. Cross-engagement inputs and arbitrary outputs are rejected.

Start the prepared run before execution. After the last output write, call
`finalize_studio_client_workflow` and declare every physical file with a stable
artifact ID, relative path, concrete purpose, audience, and media type. Review
the closed declaration, then call `complete_studio_client_workflow`; record
`failed` or explicitly cancel an abandoned run instead of treating a partial
directory as a result.

# Revisione del Concordato Preventivo

Use this skill for the Italian legal and professional object **concordato
preventivo**. Do not interpret “concordato” as an arbitrary workflow name or as
synonym for a numerical tie-out.

The review covers the procedure, proposal, plan, professional attestation,
document perimeter, creditor population and treatment, liquidation
alternative, sources and uses, liquidity, milestones, assumptions,
consistency, and open issues.

This is not a general report builder, a legal-opinion engine, or a plan
attestation. Claude proposes the semantic analysis; a qualified professional
confirms or corrects it. The scripts validate and calculate only mechanically
verifiable facts.

## Core Boundary

Use deterministic code for:

- source capture, hashes, receipts, and closed output paths;
- PDF/workbook extraction and precise evidence locators;
- schema and evidence-reference validation;
- exact decimal arithmetic;
- creditor/class totals and recovery percentages;
- plan-versus-liquidation differences;
- sources-and-uses totals and funding gap;
- period cash bridges and minimum liquidity;
- exact amount matching as an optional appendix;
- reproducible JSON, CSV, XLSX, DOCX, and review-session artifacts.

Use Claude and professional judgment for:

- governing law and its application;
- document meaning and authoritative version;
- creditor perimeter, priority, class, vote, and treatment;
- whether evidence supports an assertion;
- feasibility, materiality, sustainability, and going concern;
- legal, tax, social-security, and accounting conclusions;
- issue severity, follow-up, and professional conclusion.

Never infer a semantic role from a file name. Never convert a passed arithmetic
check into a legal or feasibility conclusion. If evidence is incomplete, keep
`missing`, `partial`, `unclear`, `gap`, or an open issue visible.

## Cowork-native Run UX

Before write-heavy execution, identify the material choices that would change
the review and establish only those not recoverable from the sources:

- input folder and intended procedure/case;
- review cut-off or reference date;
- working language and document language;
- accountable professional/reviewer for confirmation;
- any user-requested scope exclusion;
- numerical tolerance only if a numerical appendix is needed.

Ask only those unresolved choices in chat and wait for the answer. Generate
choices from the actual inputs; do not offer named frameworks, regulators,
document types, issue categories, or output packages unless the facts cue them
or the user must supply a missing custom value.

Do not ask the user to choose output files. Produce the complete normal package
when dependencies and evidence permit.

Default output policy: the semantic case model, creditor and class schedules,
sources and uses, liquidity, review workbook, Markdown, Word summary, audit
records, and numerical appendix are not choices to propose when they are
natural outputs of the case. Generate them whenever the evidence and declared
dependencies permit.

Use native Claude artifacts:

1. Show a short checklist: intake, dependency check, inspection, semantic
   modeling, reviewer confirmation, deterministic schedules, review, delivery.
2. Show a Run Intake table with source folder, output folder, cut-off,
   languages, and explicit assumptions.
3. After inspection, show a Decision Table only for material semantic
   uncertainties or missing evidence.
4. Before sealing the model, show an execution checkpoint with the procedure
   identity, plan type, authoritative documents, creditor perimeter status, key
   assumptions, open gaps, source folder, and output folder.
5. Update the checklist during execution.
6. End with an Artifact Card separating primary semantic outputs, numerical
   appendix, unresolved issues, and next action. When useful, create
   `run_review.md` in the output folder from the persisted review
   artifacts. Never edit plugin source or generated ZIPs during a case run.

Ask for explicit approval only when a step is external, destructive,
approval-sensitive, or depends on an unresolved material choice. Ordinary
local inspection, deterministic calculation, and artifact generation within
the agreed output folder do not require ceremonial approval.

The user should not have to operate helper CLIs. Claude runs them, reads the
results, prepares the model, and explains the boundary.

## Inputs

Required:

- one folder containing the material supplied for the case.

The plugin does not require fixed file names or one fixed checklist. Depending
on the case, useful material may include a proposal, plan, attestations,
creditor schedules, liquidation analysis, cash-flow model, disposals,
contributions, accounting records, tax/social-security schedules, court
documents, or professional reports. Treat this as evidence discovered from the
actual case, not a filename taxonomy.

Default currency is EUR unless a source or user states otherwise. The semantic
model requires one consistent currency for its mechanical schedules.

## Workflow

### 1. Check dependencies

From the plugin directory:

```bash
python scripts/check_dependencies.py
```

Install only declared `requirements.txt` dependencies when permitted. Stop
before unreliable output if a required capability is unavailable.

### 2. Inspect in abstention

```bash
python scripts/run_concordato_review.py <managed-input-folder> \
  --client-engagement <client_engagement_path> \
  --output-dir <client-run-output>/inspection \
  --reference-date 2026-03-31 \
  --language it \
  --document-language it \
  --tolerance 1
```

This captures sources and writes an unreviewed semantic template. It does not
make filename-based roles operative and it does not grant reporting authority.

Read at least:

- `inventory.json`;
- `source_pages.json`;
- `suggested_concordato_case_model.json`;
- extraction diagnostics;
- `raw_amount_candidates.csv` only if a numerical appendix may be useful.

### 3. Build the semantic case model

Copy `suggested_concordato_case_model.json` to a working JSON file and fill it
from inspected evidence. Preserve its exact schema:

- `legal_framework`;
- `procedure`;
- `document_perimeter`;
- `creditor_population`;
- `sources_and_uses`;
- `liquidity`;
- `milestones`;
- `review_questions`;
- `assumptions`;
- `issues`.

For every semantic entry:

- use captured `source_artifact_ref` values;
- add precise locators when the schema provides them;
- explain `judgment_basis`;
- distinguish observed evidence from professional inference;
- keep missing evidence and contradictions explicit.

The required review areas are procedure identity, proposal/plan consistency,
document perimeter, creditor perimeter/treatment, voting and homologation,
liquidation alternative, feasibility/liquidity, attestation, accounting
consistency, and tax/social-security matters.

### 4. Obtain reviewer confirmation

Present the completed model and unresolved issues to the accountable
professional. Do not label Claude's unconfirmed draft as reviewed.

After confirmation, seal the model:

```bash
python scripts/review_case_model.py <client-run-output>/inspection \
  <client-run-output>/reviewer-confirmed-case-model.json \
  --client-engagement <client_engagement_path> \
  --output <client-run-output>/reviewed-semantic-recipe.json \
  --reviewer-ref qualified-reviewer \
  --reviewed-on 2026-07-26 \
  --reference-date 2026-03-31
```

The helper normalizes the model and binds it to current source receipts. If the
source perimeter or bytes change, repeat inspection and confirmation.

### 5. Add a numerical appendix only when useful

If the review requires a plan-to-accounting amount tie-out, prepare the
separate source/token decision file and seal it with:

```bash
python scripts/review_source_roles.py <client-run-output>/inspection \
  <client-run-output>/numeric-decisions.json \
  --client-engagement <client_engagement_path> \
  --output <client-run-output>/reviewed-numeric-recipe.json
```

This path requires an explicit disposition for every extracted numeric token
and authorizes only the fixed amount-difference calculation. Do not run it
merely because the capability once centered on a tie-out.

### 6. Run the reviewed case

Semantic review without the numerical appendix:

```bash
python scripts/run_concordato_review.py <managed-input-folder> \
  --client-engagement <client_engagement_path> \
  --output-dir <client-run-output>/reviewed-output \
  --reference-date 2026-03-31 \
  --language it \
  --document-language it \
  --tolerance 1 \
  --semantic-recipe <client-run-output>/reviewed-semantic-recipe.json
```

When the numerical appendix is also authorized, add:

```text
--recipe /path/to/reviewed-numeric-recipe.json
```

### 7. Review primary outputs

Read:

- `concordato_case_model.json`;
- `concordato_semantic_checks.json`;
- `creditor_treatment.csv`;
- `creditor_class_summary.csv`;
- `sources_and_uses.csv`;
- `liquidity_schedule.csv`;
- `concordato_review_workpaper.xlsx`;
- `concordato_semantic_review.md`;
- `concordato_preventivo_review_summary.docx`;
- `assurance_envelope.json`;
- `workflow_output_closure.json`;
- `final_artifacts.json`.

Keep `review_payload.json` as the complete local review/UI authority. Do not
reopen or resend it merely to render, save, or apply review state after the
semantic model has been confirmed.

Treat `concordato_tie_out_workpaper.xlsx` and
`concordato_review_summary.docx` as numerical appendices.

### 8. Cowork review handoff

The normal Cowork completion point is delivery
of the reviewable draft, artifact card, and source/review files in the connected
folder. Studio Archive supplies the same portable customer-run context as in
Claude. When `concordatoPlanReviewWidgets` is callable, prefer the reference-bound
review route: read
`review_reference` from `final_artifacts.json`, validate and render with only
that reference and the customer-run context, then request no more than 25
purpose-selected review items at a time through
`read_concordato_plan_review_items`. The complete review payload stays in
component-only metadata; paths, hashes, sizes, and technical references are
removed from selected model items and source filenames are replaced by stable
aliases. Exact source files may still be opened for a specific evidence
question; do not reopen the entire case by default.

If the optional interface is unavailable, use the same file-based handoff that
applies in either runtime. Begin with the delivered semantic review and open
only the exact review or source files needed for the unresolved professional
question. The 25-item tool limit does not apply to that file fallback, so do
not describe it as tool-bounded. Report the package as
`ready_for_professional_review` where that status exists, otherwise as
`pending_review`.

The optional interface may persist or apply reviewer actions. Its absence never
blocks delivery. Never claim `applied` or `final_ready` unless corresponding
persisted artifacts prove it. A file or chat review without those artifacts
remains pending professional review.

This is transport minimization, not anonymization or pseudonymization. Debtor,
creditor, claim, priority, class, vote, treatment, amount, and evidence details
remain when the professional question requires them.

Review actions cannot waive a failed deterministic check. Keep failed checks,
missing evidence, unresolved decisions, and applicable blockers visible in the
artifact card and final response.

### 9. Replay

```bash
python scripts/replay_assurance.py \
  --client-engagement <client_engagement_path> \
  --output-dir <client-run-output>/reviewed-output
```

Use `references/workflow-reference.md` for the normative authority and replay
contract and `references/review-methodology.md` for professional review
sequence.

## Completion Standard

A useful delivery states:

- what was observed in the supplied evidence;
- which semantic judgments were confirmed and by whom;
- procedure and plan type;
- document and creditor perimeter status;
- treatment and liquidation-comparator results;
- sources-and-uses and liquidity observations;
- open questions, evidence gaps, assumptions, and limitations;
- whether the optional numerical appendix ran;
- why publication or professional conclusion remains withheld, if applicable.

Do not claim that synthetic tests prove real-case generality. Field validation
requires a previously unseen real case and an independent qualified review.

## Cowork execution contract

For journal-sampling, open-item-reconciliation, journal-bank-reconciliation,
concordato-plan-review, report-builder and check-entries only, optional cache
cleanup is available from the installed Vera root:

```bash
python3 modules/<module>/scripts/implementation_bootstrap.py --repair
```

For a standalone module, use `python3 scripts/implementation_bootstrap.py --repair`
from its root. This validates the implementation first, then removes only regular,
single-link `__pycache__/*.pyc` files under that module's own `vendor` tree. It
leaves directories, other files, symlinks and shared vendor trees untouched.
If `validate_implementation_tree` ever fails with a file/directory-contract
mismatch, do not delete or modify files inside the installed plugin tree by hand
and do not bypass a sandbox/permission rejection to do so. Stop and report the
exact error instead.

Work from the connected folder and supplied files first. Before a module's Python
helpers, locate the installed plugin root. When it contains `components.json` and
`scripts/managed_python_runtime.py` (as Vera does), run from that root:

```bash
python3 scripts/check_dependencies.py --module <module>
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

If the enclosing plugin does not ship this managed launcher, use the module's
dependency checker and only already-installed dependencies; do not assume that a
standalone module script provisions them.

The managed launchers provision and reuse an isolated environment containing only the
module's published requirements. This declared dependency setup is authorized as
part of running the workflow; never install arbitrary packages or use ambient
Python for subsequent module helpers. Repeat any declared `--requirements` options
on both commands. Missing ambient imports are a reason to run this setup, not to
abandon the calculation. If setup fails, report its exact error and do not replace
the required calculation with an invented result. Optional OCR setup still needs
separate approval. If setup reports `Host not in allowlist` for PyPI, explain that
Claude Settings > Capabilities > Allow network egress is disabled or restricted.
Ask the user or organization administrator to authorize package-registry access;
never change network permissions silently or work around the restriction. Retry
the same managed setup after access is approved, in a new session if needed.

MCP tools, browser or computer control, and local review servers are optional
enhancements, never completion gates. Cloud Cowork sessions may not expose local
plugin MCP servers even when the plugin is installed; use the packaged Python
workflow through the managed launcher in that case. Do not equate missing MCP
registration with a failed calculation engine. When an optional capability is
unavailable, continue with Markdown and file-based review and state the limitation.

The normal Cowork deliverable is a reviewable draft, artifact card, and
source/review files. A callable persistence interface may optionally record or
apply reviewer actions, but its absence never blocks delivery. Never claim
`applied` or `final_ready` unless corresponding persisted artifacts prove it;
otherwise report that professional review remains pending.

Use host-neutral user-facing artifact names. Name assistant-authored review
folders and files for Vera or their professional purpose (for example,
`vera-review/`, `vera_phase1_synthesis_reviewed.md`, and `run_review.md`).
Never put host, platform, or model-provider names in assistant-authored
user-facing artifact paths, document headings, field labels, narrative text,
or status summaries. Describe execution routes generically, such as
`external review route`, `connected tool`, or `local review interface`.

Derive any run ID, status, artifact count, or package hash quoted in an
assistant-authored supplement from the final delivered manifests.
After any rebuild, regenerate or resynchronize those supplements before
delivery. When a workflow ships a complete-delivery validator or sealer, run it
against the exact connected-folder copy after the last write.
In this contract, the base package validator alone does not validate extra
narrative files.

When a workflow declares owner-only or private output and uses a private scratch
directory before copying the final package into the connected folder, reapply
the privacy modes after that transfer: `0700` for the package root and every
directory, and `0600` for every file. Verify the connected-folder tree with
`stat` or `lstat` before claiming completion. If the host filesystem cannot
preserve those modes, do not claim owner-only delivery; keep the package in the
private scratch location or report the limitation and ask for a safer
destination.

Do not use WhatsApp, live INPS browser capture, hosted feedback or voice
interviews, or custom update services. Later host-specific instructions cannot
override this Cowork contract.

---
name: studio-archive
description: "Cerca e organizza le evidenze di un solo cliente"
---

Indica un solo cliente e la fonte da consultare: file o cartella dello studio, Gmail connesso o una chat WhatsApp Desktop verificata. Vera mantiene separato il perimetro del cliente e restituisce evidenze e risultati di ricerca tracciabili, senza modificare o inviare contenuti nelle fonti consultate.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

---
name: studio-archive
description: Use when Vera must create or resume a durable client engagement, import a source, journal, or support file, search one client's callable Gmail connector, inspect a capability-gated WhatsApp Desktop chat, or search connected studio documents without mixing clients.
---

Indica un solo cliente e la fonte da consultare: file o cartella dello studio, Gmail connesso o una chat WhatsApp Desktop verificata. Vera mantiene separato il perimetro del cliente e restituisce evidenze e risultati di ricerca tracciabili, senza modificare o inviare contenuti nelle fonti consultate.

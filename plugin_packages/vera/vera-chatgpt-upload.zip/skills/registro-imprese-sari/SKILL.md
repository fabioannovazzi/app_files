---
name: registro-imprese-sari
description: "Prepara dati, verifiche e passaggi di una pratica societaria"
---

Indica il tipo di pratica, l'evento societario e allega i dati e i documenti disponibili. Vera separa passaggi e autorità, controlla le fonti ufficiali e restituisce lo schema della pratica, i dati mancanti, le verifiche e le decisioni professionali ancora aperte; non invia la pratica.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

---
name: registro-imprese-sari
description: Use when Vera must prepare a Registro Imprese, REA, Comunicazione Unica, or DIRE practice from official guidance, keeping linked authority checks distinct for professional review.
---

Indica il tipo di pratica, l'evento societario e allega i dati e i documenti disponibili. Vera separa passaggi e autorità, controlla le fonti ufficiali e restituisce lo schema della pratica, i dati mancanti, le verifiche e le decisioni professionali ancora aperte; non invia la pratica.

---
name: bilancio-xbrl-it
description: "Prepara bilanci OIC revisionabili con esportazione XBRL"
---

Allega il bilancio di verifica in CSV, Excel o PDF leggibile/scansionato, l'eventuale XBRL precedente e i documenti di supporto disponibili. Vera deve risolvere `../../modules/bilancio-xbrl-it` da questa skill, leggere integralmente la skill `skills/bilancio-xbrl-it/SKILL.md` del modulo e tutti i riferimenti che richiede, trattare il modulo risolto come directory di lavoro ed eseguire `python scripts/check_dependencies.py` prima degli script di supporto. Il workflow completo rende rivedibili estrazione, mappature, prospetti, nota integrativa e controlli prima dell'esportazione XBRL deterministica; Vera non approva né deposita il bilancio.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

---
name: bilancio-xbrl-it
description: Use when an Italian professional accounting studio asks Vera to understand spreadsheet or readable/scanned PDF accounting evidence and intelligently prepare, update, reconcile, review, validate, or export an individual OIC civil-law annual financial statement; XBRL is a final output format, not the workflow identity.
---

Allega il bilancio di verifica in CSV, Excel o PDF leggibile/scansionato, l'eventuale XBRL precedente e i documenti di supporto disponibili. Per un PDF, Vera mostra intestazioni, righe, celle incerte, correzioni ed esclusioni prima di usare i dati. Poi comprende le evidenze contabili, propone mappature spiegate, segnala ambiguità e dati mancanti e prepara prospetti, nota integrativa e carta di lavoro per la revisione professionale. Calcoli, controlli e generazione XBRL restano deterministici; Vera non approva né deposita il bilancio.

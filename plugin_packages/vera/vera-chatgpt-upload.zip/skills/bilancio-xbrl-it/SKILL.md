---
name: bilancio-xbrl-it
description: Use when an Italian professional accounting studio asks Vera to understand accounting evidence and intelligently prepare, update, reconcile, review, validate, or export an individual OIC civil-law annual financial statement; XBRL is a final output format, not the workflow identity.
---

Allega il bilancio di verifica, l'eventuale XBRL precedente e i documenti di supporto disponibili. Vera comprende le evidenze contabili, propone mappature spiegate, segnala ambiguità e dati mancanti e prepara prospetti, nota integrativa e carta di lavoro per la revisione professionale. Calcoli, controlli e generazione XBRL restano deterministici; Vera non approva né deposita il bilancio.

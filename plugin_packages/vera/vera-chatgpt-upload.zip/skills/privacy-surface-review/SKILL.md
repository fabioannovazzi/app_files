---
name: privacy-surface-review
description: Use when adding, changing, reviewing, or releasing a Vera workflow or shared service to record model-context, provider-account, external-data, and security boundaries before packaging.
---

Indica il flusso Vera o il servizio condiviso che stai aggiungendo o modificando e fornisci i file interessati. Vera registra dati leggibili dal modello, confini esterni, account, conservazione e controlli effettivi e restituisce il registro aggiornato e gli esiti di validazione.

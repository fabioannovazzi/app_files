---
name: privacy-surface-review
description: "Controlla dati, confini, account e conservazione"
---

Indica il flusso Vera o il servizio condiviso che stai aggiungendo o modificando e fornisci i file interessati. Vera registra dati leggibili dal modello, confini esterni, account, conservazione e controlli effettivi e restituisce il registro aggiornato e gli esiti di validazione.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

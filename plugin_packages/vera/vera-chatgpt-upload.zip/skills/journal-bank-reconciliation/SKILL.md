---
name: journal-bank-reconciliation
description: Use when reconciling bank statements with journal or ledger exports, mapping customer formats, matching exact amounts, dates, and references, and producing reviewable outputs.
---

Allega gli estratti conto e l'esportazione del giornale contabile o del mastro. Vera rivede la mappatura dei campi, abbina importi, date e riferimenti e restituisce corrispondenze, movimenti non abbinati, residui ed eccezioni senza attribuire automaticamente i casi ambigui.

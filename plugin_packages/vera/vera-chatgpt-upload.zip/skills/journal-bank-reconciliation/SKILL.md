---
name: journal-bank-reconciliation
description: "Abbina estratti conto e giornale contabile"
---

Allega gli estratti conto e l'esportazione del giornale contabile o del mastro. Vera rivede la mappatura dei campi, abbina importi, date e riferimenti e restituisce corrispondenze, movimenti non abbinati, residui ed eccezioni senza attribuire automaticamente i casi ambigui.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

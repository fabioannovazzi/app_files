---
name: email-cliente
description: Use when drafting a client email from first-intake missing documents and clarifications for an accounting studio, keeping the message operational.
---

Fornisci la nota istruttoria già rivista e l'elenco dei documenti o chiarimenti mancanti. Vera elimina le richieste non sostenute dai rilievi, organizza quelle residue in modo operativo e restituisce una bozza email concisa, pronta per la revisione e l'invio da parte dello studio.

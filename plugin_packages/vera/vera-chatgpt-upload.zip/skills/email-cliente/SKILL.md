---
name: email-cliente
description: "Trasforma i rilievi in richieste chiare al cliente"
---

Fornisci la nota istruttoria già rivista e l'elenco dei documenti o chiarimenti mancanti. Vera elimina le richieste non sostenute dai rilievi, organizza quelle residue in modo operativo e restituisce una bozza email concisa, pronta per la revisione e l'invio da parte dello studio.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

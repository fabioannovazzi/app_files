---
name: sales-plan
description: Use when creating a forward-looking sales Plan from reviewed Actuals and confirmed commercial or FX assumptions.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

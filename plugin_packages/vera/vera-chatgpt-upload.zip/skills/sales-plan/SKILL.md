---
name: sales-plan
description: Use when creating a forward-looking sales Plan from reviewed Actuals and confirmed commercial or FX assumptions.
---

Allega gli Actual mensili già rivisti e indica le assunzioni commerciali e valutarie da applicare. Vera traduce ogni ipotesi in driver, perimetro, periodo e priorità da confermare, quindi restituisce il Piano vendite, il registro delle assunzioni e la riconciliazione dei totali.

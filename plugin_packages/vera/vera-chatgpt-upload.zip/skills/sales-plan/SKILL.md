---
name: sales-plan
description: "Trasforma Actual e assunzioni in un piano vendite"
---

Allega gli Actual mensili già rivisti e indica le assunzioni commerciali e valutarie da applicare. Vera traduce ogni ipotesi in driver, perimetro, periodo e priorità da confermare, quindi restituisce il Piano vendite, il registro delle assunzioni e la riconciliazione dei totali.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

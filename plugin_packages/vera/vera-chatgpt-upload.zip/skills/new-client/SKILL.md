---
name: new-client
description: "Use when a studio starts work on a new client: prepare files, identify missing evidence, and build a source-bound setup covering identity, engagement, privacy, AML, and monitoring."
---

Indica il nuovo cliente italiano e allega i documenti iniziali disponibili. Vera inventaria i file, identifica le evidenze mancanti e restituisce un fascicolo di avvio tracciabile per identità, incarico, privacy, antiriciclaggio e monitoraggio, lasciando approvazioni e decisioni al professionista.

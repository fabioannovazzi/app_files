---
name: new-client
description: "Use when a studio starts work on a new client: prepare files, identify missing evidence, and build a source-bound setup covering identity, engagement, privacy, AML, and monitoring."
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

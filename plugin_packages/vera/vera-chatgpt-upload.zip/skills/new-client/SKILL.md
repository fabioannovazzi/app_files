---
name: new-client
description: "Prepara il fascicolo iniziale di un cliente italiano"
---

Indica il nuovo cliente italiano e allega i documenti iniziali disponibili. Vera inventaria i file, identifica le evidenze mancanti e restituisce un fascicolo di avvio tracciabile per identità, incarico, privacy, antiriciclaggio e monitoraggio, lasciando approvazioni e decisioni al professionista.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

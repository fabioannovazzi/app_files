---
name: audit-reconciliation
description: Use when reconciling accounting evidence across ledgers, statements, payments, factoring, advances, or compensation and producing reviewable Excel and Word workpapers.
---

Allega mastrini, partite aperte, estratti conto, ordini di pagamento e gli eventuali documenti su factoring, anticipi o compensazioni. Vera abbina le evidenze con criteri verificabili e restituisce corrispondenze, residui, eccezioni e una carta di lavoro pronta per la revisione.

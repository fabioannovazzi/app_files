---
name: audit-reconciliation
description: Use when reconciling accounting evidence across ledgers, statements, payments, factoring, advances, or compensation and producing reviewable Excel and Word workpapers.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

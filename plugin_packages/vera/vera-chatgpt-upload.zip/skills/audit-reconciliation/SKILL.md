---
name: audit-reconciliation
description: "Abbina evidenze contabili e segnala residui ed eccezioni"
---

Allega mastrini, partite aperte, estratti conto, ordini di pagamento e gli eventuali documenti su factoring, anticipi o compensazioni. Vera abbina le evidenze con criteri verificabili e restituisce corrispondenze, residui, eccezioni e una carta di lavoro pronta per la revisione.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

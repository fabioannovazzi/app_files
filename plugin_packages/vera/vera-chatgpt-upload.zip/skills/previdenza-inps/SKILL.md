---
name: previdenza-inps
description: Use when Vera must prepare an evidence-backed Italian INPS social-security case review from local documents or hash-bound official exports, with local OCR, conditional read-only portal capture, official-source research, approved arithmetic, and a draft for professional review.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Previdenza INPS

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/previdenza-inps` from this skill directory when it
exists; otherwise resolve `../../../previdenza-inps` in the repository. Read
that module's `skills/previdenza-inps/SKILL.md` completely and follow it. Treat
the resolved module root as the plugin working directory for all commands,
scripts, requirement files, references, schemas, and local review server.

---
name: previdenza-inps
description: Use when Vera must review an Italian INPS social-security case from connected documents or official exports, validate sources and arithmetic, and prepare a professional-review draft.
---

Allega provvedimenti, comunicazioni, prospetti ed esportazioni ufficiali del caso INPS. Vera inventaria le fonti, verifica riferimenti e calcoli ammessi e restituisce una bozza istruttoria con evidenze per pagina, limiti della lettura automatica e punti aperti per il professionista.

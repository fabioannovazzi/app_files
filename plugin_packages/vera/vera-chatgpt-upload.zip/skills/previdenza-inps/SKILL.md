---
name: previdenza-inps
description: Use when Vera must review an Italian INPS social-security case from connected documents or official exports, validate sources and arithmetic, and prepare a professional-review draft.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

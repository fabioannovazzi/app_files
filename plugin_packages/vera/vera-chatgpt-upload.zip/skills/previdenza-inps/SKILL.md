---
name: previdenza-inps
description: "Organizza provvedimenti, calcoli e punti aperti INPS"
---

Allega provvedimenti, comunicazioni, prospetti ed esportazioni ufficiali del caso INPS. Vera inventaria le fonti, verifica riferimenti e calcoli ammessi e restituisce una bozza istruttoria con evidenze per pagina, limiti della lettura automatica e punti aperti per il professionista.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

---
name: concordato-plan-review
description: "Controlla piano, trattamento e sostenibilità finanziaria"
---

Allega proposta, piano, attestazione, elenco creditori e documenti economico-finanziari rilevanti. Vera confronta procedura, trattamento, alternativa liquidatoria, fonti e impieghi e liquidità, quindi restituisce rilievi, prospetti e questioni aperte per il professionista.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

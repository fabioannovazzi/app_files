---
name: concordato-plan-review
description: Use when a user wants Codex to tie out the numerical section of an Italian concordato plan against bilancio, mastrini, adjusted DB schedules, tax/social-security debt details, or other accounting support, then produce auditor-oriented differences and going-concern criticalities.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Revisione Piano Concordato

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/concordato-plan-review` from this skill directory when
it exists; otherwise resolve `../../../concordato-plan-review` in the
repository. Read that module's `skills/concordato-plan-review/SKILL.md`
completely and follow it. Treat the resolved module root as the plugin working
directory for all commands.

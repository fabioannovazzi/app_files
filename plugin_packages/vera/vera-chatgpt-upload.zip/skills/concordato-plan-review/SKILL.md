---
name: concordato-plan-review
description: Use when reviewing an Italian concordato preventivo across procedure, proposal, plan, attestation, creditors, treatment, liquidity, evidence consistency, and open issues.
---

Allega proposta, piano, attestazione, elenco creditori e documenti economico-finanziari rilevanti. Vera confronta procedura, trattamento, alternativa liquidatoria, fonti e impieghi e liquidità, quindi restituisce rilievi, prospetti e questioni aperte per il professionista.

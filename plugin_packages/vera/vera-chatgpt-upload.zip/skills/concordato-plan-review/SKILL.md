---
name: concordato-plan-review
description: Use when reviewing an Italian concordato preventivo across procedure, proposal, plan, attestation, creditors, treatment, liquidity, evidence consistency, and open issues.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

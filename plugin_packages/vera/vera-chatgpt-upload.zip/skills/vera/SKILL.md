---
name: vera
description: Use when a professional accounting studio asks Vera to prepare, check, reconcile, research, or document client work through her specialist, reviewable workflows.
---

Fornisci i documenti del cliente e descrivi il controllo, l'analisi o la pratica da preparare. Vera organizza le evidenze, seleziona il flusso specialistico appropriato e restituisce una carta di lavoro tracciabile, con anomalie, assunzioni e punti da confermare chiaramente separati.

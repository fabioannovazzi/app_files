---
name: prompt-optimizer
description: Use internally when a legal, tax, or compliance question needs an answer contract and source-backed generation instructions for either direct Codex drafting or a ChatGPT Deep Research handoff. The user does not need to ask for prompt optimization.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

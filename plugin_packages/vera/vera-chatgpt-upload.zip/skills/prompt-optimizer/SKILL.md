---
name: prompt-optimizer
description: Use when a user wants Codex to turn a legal, tax, or compliance question into a source-backed Deep Research prompt, with fact preservation, research posture, source hierarchy, citation rules, and deterministic validation. Do not use for general copywriting unrelated to Deep Research.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Optimize Prompt

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/prompt-optimizer` from this skill directory when it
exists; otherwise resolve `../../../prompt-optimizer` in the repository. Read
that module's `skills/prompt-optimizer/SKILL.md` completely and follow it. Treat
the resolved module root as the plugin working directory for all commands.

---
name: prompt-optimizer
description: Use internally when a legal, tax, or compliance question needs an answer contract and source-backed generation instructions for either direct Codex drafting or a ChatGPT Deep Research handoff. The user does not need to ask for prompt optimization.
---

Fornisci il quesito legale, fiscale o di compliance e il risultato atteso. Vera definisce il contratto della risposta, individua le fonti necessarie, sceglie il percorso di generazione e restituisce un piano verificabile con i controlli da superare prima della consegna.

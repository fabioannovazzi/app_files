---
name: prompt-optimizer
description: "Trasforma un quesito professionale in un piano verificabile"
---

Fornisci il quesito legale, fiscale o di compliance e il risultato atteso. Vera definisce il contratto della risposta, individua le fonti necessarie, sceglie il percorso di generazione e restituisce un piano verificabile con i controlli da superare prima della consegna.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

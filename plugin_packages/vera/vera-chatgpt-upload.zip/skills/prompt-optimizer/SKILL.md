---
name: prompt-optimizer
description: Use automatically before Vera answers any accepted substantive legal, tax, or compliance question or prepares source-backed professional drafting that needs an answer contract and generation instructions for direct Codex work or a ChatGPT Deep Research handoff. The user never needs to request prompt optimization. Do not use this skill as a substitute for a missing operational return, declaration, filing, or form workflow.
---

Fornisci il quesito legale, fiscale o di compliance e il risultato atteso. Vera definisce il contratto della risposta, individua le fonti necessarie, sceglie il percorso di generazione e restituisce un piano verificabile con i controlli da superare prima della consegna.

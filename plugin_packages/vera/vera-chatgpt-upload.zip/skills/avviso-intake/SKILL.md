---
name: avviso-intake
description: "Rileva scadenze, importi e documenti mancanti"
---

Allega l'avviso, la cartella o la lettera fiscale e indica il cliente e la giurisdizione se non sono evidenti. Vera rileva autorità, riferimenti, date, importi, scadenze e documenti da recuperare e restituisce una prima nota istruttoria con ogni elemento incerto marcato da verificare.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

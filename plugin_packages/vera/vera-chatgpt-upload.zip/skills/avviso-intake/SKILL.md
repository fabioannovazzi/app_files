---
name: avviso-intake
description: Use when preparing a first intake memo for notices, avvisi, cartelle, HMRC letters, or Swiss cantonal tax letters found in a customer folder.
---

Allega l'avviso, la cartella o la lettera fiscale e indica il cliente e la giurisdizione se non sono evidenti. Vera rileva autorità, riferimenti, date, importi, scadenze e documenti da recuperare e restituisce una prima nota istruttoria con ogni elemento incerto marcato da verificare.

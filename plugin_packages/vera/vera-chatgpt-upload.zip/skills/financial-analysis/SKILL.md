---
name: financial-analysis
description: "Controlla prospetti, riconciliazioni e indicatori finanziari"
---

Allega la contabilità storica o i prospetti finanziari e indica il perimetro dell'analisi. Vera controlla mapping, riconciliazioni e calcoli e restituisce prospetti legati alle fonti, con eccezioni, assunzioni e giudizi professionali chiaramente separati.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

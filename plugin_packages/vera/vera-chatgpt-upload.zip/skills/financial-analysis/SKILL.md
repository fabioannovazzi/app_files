---
name: financial-analysis
description: Use when preparing controlled historical accounting analysis or fixed financial due-diligence calculations under Vera's accounting controls.
---

Allega la contabilità storica o i prospetti finanziari e indica il perimetro dell'analisi. Vera controlla mapping, riconciliazioni e calcoli e restituisce prospetti legati alle fonti, con eccezioni, assunzioni e giudizi professionali chiaramente separati.

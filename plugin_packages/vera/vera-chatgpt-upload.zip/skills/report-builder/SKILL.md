---
name: report-builder
description: Use when inspecting financial Excel, CSV, or text-PDF inputs, mapping tables to report sections, refining the narrative, and producing reviewable Markdown, DOCX, or JSON.
---

Allega il file con i dati e indica destinatario, periodo e tipo di report se non sono evidenti. Vera inventaria le tabelle, propone la mappatura alle sezioni, controlla i valori e sviluppa la narrativa, quindi restituisce una bozza e diagnostica revisionabili.

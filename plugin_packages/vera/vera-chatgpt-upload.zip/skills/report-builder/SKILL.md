---
name: report-builder
description: Use when inspecting financial Excel, CSV, or text-PDF inputs, mapping tables to report sections, refining the narrative, and producing reviewable Markdown, DOCX, or JSON.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

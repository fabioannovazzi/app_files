---
name: report-builder
description: "Trasforma dati finanziari in un report controllato"
---

Allega il file con i dati e indica destinatario, periodo e tipo di report se non sono evidenti. Vera inventaria le tabelle, propone la mappatura alle sezioni, controlla i valori e sviluppa la narrativa, quindi restituisce una bozza e diagnostica revisionabili.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

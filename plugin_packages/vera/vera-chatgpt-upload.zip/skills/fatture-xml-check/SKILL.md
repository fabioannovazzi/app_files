---
name: fatture-xml-check
description: "Use when checking Italian FatturaPA XML files in a customer folder, summarizing invoice metadata, and identifying malformed XML, date issues, or duplicate candidates."
---

Allega i file FatturaPA XML e indica l'esercizio se non è ricavabile. Vera estrae metadati e riepiloghi IVA, individua file malformati, campi mancanti, date fuori periodo e possibili duplicati e restituisce un prospetto delle fatture e un memo delle anomalie.

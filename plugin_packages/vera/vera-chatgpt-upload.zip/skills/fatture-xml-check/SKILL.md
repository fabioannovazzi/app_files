---
name: fatture-xml-check
description: "Controlla FatturePA, IVA, periodi e duplicati"
---

Allega i file FatturaPA XML e indica l'esercizio se non è ricavabile. Vera estrae metadati e riepiloghi IVA, individua file malformati, campi mancanti, date fuori periodo e possibili duplicati e restituisce un prospetto delle fatture e un memo delle anomalie.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

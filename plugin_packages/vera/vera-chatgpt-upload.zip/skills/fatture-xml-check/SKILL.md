---
name: fatture-xml-check
description: "Use when checking Italian FatturaPA XML files in a customer folder, summarizing invoice metadata, and identifying malformed XML, date issues, or duplicate candidates."
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

---
name: fatture-xml-check
description: "Use when formally checking Italian FatturaPA XML files in a customer folder: parse invoice metadata, create CSV summaries, identify malformed XML, date issues, and duplicate candidates."
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Fatture XML Check

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/client-file-preparation` from this skill directory when it exists;
otherwise resolve `../../../client-file-preparation` in the repository. Read that
module's `skills/fatture-xml-check/SKILL.md` completely and follow it. Treat the
resolved module root as the plugin working directory for all commands.

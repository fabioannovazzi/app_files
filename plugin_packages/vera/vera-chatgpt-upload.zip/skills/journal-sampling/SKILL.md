---
name: journal-sampling
description: "Prepara un campione contabile riproducibile e tracciabile"
---

Allega il file del giornale contabile e indica popolazione, periodo e criterio di campionamento se non sono già definiti. Vera rivede la mappatura dei campi, normalizza le righe monetarie e restituisce popolazione, diagnostica e campione riproducibile con tracciabilità.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

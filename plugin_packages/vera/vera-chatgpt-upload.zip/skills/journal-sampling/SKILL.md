---
name: journal-sampling
description: Use when qualifying accounting journal entries from reviewed CSV or Excel sources, normalizing exact monetary rows, and generating reproducible audit samples with diagnostics.
---

Allega i documenti pertinenti e descrivi il risultato che ti serve. Vera manterrà visibili evidenze, assunzioni e questioni irrisolte e preparerà un risultato verificabile prima dell’uso professionale.

Se mancano informazioni essenziali, Vera farà domande mirate o indicherà chiaramente il limite senza colmare il vuoto in modo implicito.

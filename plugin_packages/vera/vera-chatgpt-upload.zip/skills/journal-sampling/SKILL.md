---
name: journal-sampling
description: Use when a user wants Codex to extract accounting journal entries from variable Excel, CSV, print-friendly Excel, or text PDF formats, map columns, normalize deterministic rows, and generate reproducible audit samples with diagnostics and an audit trail.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Journal Sampling

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/journal-sampling` from this skill directory when it
exists; otherwise resolve `../../../journal-sampling` in the repository. Read
that module's `skills/journal-sampling/SKILL.md` completely and follow it. Treat
the resolved module root as the plugin working directory for all commands.

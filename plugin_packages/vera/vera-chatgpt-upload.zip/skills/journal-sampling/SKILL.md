---
name: journal-sampling
description: Use when qualifying accounting journal entries from reviewed CSV or Excel sources, normalizing exact monetary rows, and generating reproducible audit samples with diagnostics.
---

Allega il file del giornale contabile e indica popolazione, periodo e criterio di campionamento se non sono già definiti. Vera rivede la mappatura dei campi, normalizza le righe monetarie e restituisce popolazione, diagnostica e campione riproducibile con tracciabilità.

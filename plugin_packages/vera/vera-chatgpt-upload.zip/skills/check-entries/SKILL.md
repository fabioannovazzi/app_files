---
name: check-entries
description: Use when comparing qualified Journal Sampling entries with FatturaPA XML or supporting PDFs, running exact evidence checks, and producing lineage-bound review outputs.
---

Fornisci il campione qualificato prodotto da Journal Sampling e allega le FatturePA XML o i PDF di supporto. Vera confronta le sole scritture campionate con le evidenze e restituisce esiti per riga, anomalie e richieste puntuali per i documenti mancanti.

---
name: check-entries
description: "Confronta scritture campionate e documenti di supporto"
---

Fornisci il campione qualificato prodotto da Journal Sampling e allega le FatturePA XML o i PDF di supporto. Vera confronta le sole scritture campionate con le evidenze e restituisce esiti per riga, anomalie e richieste puntuali per i documenti mancanti.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

---
name: check-entries
description: Use when a user wants Codex to compare selected journal entries with supporting PDF documents, map entry columns, run deterministic amount/date/beneficiary checks, and produce reviewable CSV/XLSX/JSON outputs.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Check Entries

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/check-entries` from this skill directory when it exists;
otherwise resolve `../../../check-entries` in the repository. Read that
module's `skills/check-entries/SKILL.md` completely and follow it. Treat the
resolved module root as the plugin working directory for all commands.

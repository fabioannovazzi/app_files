---
name: dati-fiscali-strutturati
description: "Use when extracting or reviewing structured fiscal fields from readable Italy, Geneva, Zurich, or UK customer-folder documents."
---

Allega i documenti fiscali da strutturare o controllare e indica la giurisdizione se non è evidente. Vera estrae i campi con file fonte, evidenza e livello di confidenza, segnala incoerenze o valori da verificare e restituisce dati tabellari revisionabili senza colmare i vuoti.

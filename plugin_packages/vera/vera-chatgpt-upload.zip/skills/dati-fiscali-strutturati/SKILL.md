---
name: dati-fiscali-strutturati
description: "Estrae dati fiscali con fonte e livello di confidenza"
---

Allega i documenti fiscali da strutturare o controllare e indica la giurisdizione se non è evidente. Vera estrae i campi con file fonte, evidenza e livello di confidenza, segnala incoerenze o valori da verificare e restituisce dati tabellari revisionabili senza colmare i vuoti.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

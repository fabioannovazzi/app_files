---
name: deep-research-validator
description: Use when a user wants Codex to validate a Deep Research answer or report against cited sources, review material claims, identify unsupported or weak reasoning, propose corrections, and package a validated document. Do not use for creating Deep Research prompts.
---

## Codex Desktop Runtime Gate

This plugin runs only in Codex Desktop with a local Codex workspace.
Do not run this plugin in ChatGPT on the web. If the current surface is ChatGPT web,
ChatGPT mobile, or any environment without local Codex workspace access, stop
before reading user material, calling tools, or starting the workflow. Tell the
user to open Codex Desktop, enable the plugin, open the working folder, and
start a new task.

# Validate Deep Research

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../vera/SKILL.md`.

Resolve `../../modules/deep-research-validator` from this skill directory when
it exists; otherwise resolve `../../../deep-research-validator` in the
repository. Read that module's `skills/deep-research-validator/SKILL.md`
completely and follow it. Treat the resolved module root as the plugin working
directory for all commands.

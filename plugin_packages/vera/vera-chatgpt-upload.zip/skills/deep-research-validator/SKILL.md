---
name: deep-research-validator
description: Use when validating any generated or supplied legal, tax, or compliance answer—including a research report, memo, or one-page letter—against its answer contract and available sources, with source support, reasoning, and professional judgment separated.
---

Fornisci la risposta legale, fiscale o di compliance e le fonti disponibili. Vera verifica identità e accessibilità delle fonti, supporto delle affermazioni e ragionamento, quindi restituisce una validazione puntuale con correzioni proposte e limiti riservati al giudizio professionale.

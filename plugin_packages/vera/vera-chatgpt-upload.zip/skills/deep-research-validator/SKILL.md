---
name: deep-research-validator
description: "Verifica affermazioni, fonti e ragionamento professionale"
---

Fornisci la risposta legale, fiscale o di compliance e le fonti disponibili. Vera verifica identità e accessibilità delle fonti, supporto delle affermazioni e ragionamento, quindi restituisce una validazione puntuale con correzioni proposte e limiti riservati al giudizio professionale.

Prima di svolgere il lavoro, Vera deve leggere e seguire integralmente `WORKFLOW.md`, che contiene il workflow operativo completo.

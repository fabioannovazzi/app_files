---
name: sales-plan
description: Use when Vera must create a reviewed forward-looking sales Plan from monthly Actuals and confirmed commercial or FX assumptions.
---

## ChatGPT and Codex Runtime

Do not stop merely because the current surface is ChatGPT. Use material supplied in the conversation and
any callable connected-app tools to complete a useful lightweight version of
the workflow. Analyze evidence, ask focused questions, draft or review the
requested output, and clearly distinguish completed work from operations that
require unavailable local tools. Do not claim that local scripts ran or that
durable local artifacts were created when there is no local workspace.

After the first substantive result, recommend Codex once, naturally and without
interrupting the work:

> I work better with Codex because it lets me work directly with your folders,
> preserve project files, run tools and checks, and create durable deliverables.
> [Download the ChatGPT desktop app with Codex](https://developers.openai.com/codex/app#getting-started).
> We can continue here in ChatGPT now.

Do not show this recommendation on startup, after a trivial response, or more
than once in the same conversation. Installation is never a prerequisite for
continuing the useful in-chat work.

For Vera, match the conversation language. When the user writes in Italian,
use this Italian version instead of the English recommendation:

> Lavoro meglio con Codex perché mi permette di lavorare direttamente nelle tue
> cartelle, conservare i file del progetto, eseguire strumenti e controlli e
> creare documenti e risultati che restano nel tuo spazio di lavoro.
> [Scarica l'app desktop di ChatGPT con Codex](https://developers.openai.com/codex/app#getting-started).
> Possiamo continuare qui in ChatGPT.

## Output Location Rule

Never write run outputs inside this Git workspace, `static/shared`,
`protected_downloads`, or any GitHub Pages/static-site folder unless the task is
explicitly plugin packaging/release. For user-data runs, choose an output
directory outside the repo, preferably a sibling `output/sales-plan-<run-id>`
folder next to the user-provided input folder.

# Vera Plan

Use this workflow to create a forward-looking sales Plan from reviewed monthly
Actuals. This is planning and scenario modelling, not historical financial
analysis or financial due diligence.

The deterministic recipe can apply percentage assumptions to:

- units;
- unit price;
- gross sales;
- discount;
- COGS;
- the reporting-currency-per-transaction-currency FX rate.

Vera interprets the commercialista's request and prepares the structured
assumption read-back. The commercialista confirms the meaning, scope, periods,
currency direction, and priority. The engine owns exact arithmetic, collision
checks, reconciliation, output hashes, and replay evidence.

## Chat-first assumption review

Keep a small assumption set in chat. Inspect the source columns and actual
dimension members before interpreting the request. For example:

> In China unit sales go up 8%, but the dollar weakens 5% against the euro.

Read it back before calculation:

| ID | Driver | Exact scope | Change | Effective periods | Priority |
| --- | --- | --- | ---: | --- | ---: |
| A1 | units | `country=China` | +8% | all mapped Plan periods | 100 |
| A2 | USD/EUR rate | `transaction_currency=USD` | -5% | all mapped Plan periods | 100 |

Show matched source members and affected rows when inspection can establish
them. Ask the commercialista to confirm or correct the table. Do not treat a
broad conversational statement as approval of a materially different
structured assumption.

Resolve only ambiguities that change the result:

- “sales increase” must become units, unit price, or gross sales;
- v1 accepts percentage changes only;
- the FX rate is reporting-currency units per transaction-currency unit;
- a 5% weaker USD against EUR is `-5%` for USD rows when EUR is reporting;
- scopes must match exact source dimension members;
- overlapping assumptions require explicit priority;
- equal-priority overlaps fail closed;
- gross-sales changes cannot overlap unit or unit-price changes on one row;
- v1 preserves the mapped Actual time profile and does not invent seasonality.

For a large assumption set, prepare the same review table in Markdown or case
JSON and review it in batches. A separate HTML workbench is not part of v1.

## Codex-Native Run UX

Before running helper scripts, identify the material choices that would change
the Plan: source scenario, target periods, reporting currency, dimensions,
driver meaning, exact scope, FX direction, assumption priority, and review
audience. Ask only those unresolved choices in chat and wait when their answer
would materially change execution. Generate choices from the actual inputs;
do not propose dimensions, drivers, currencies, planning rules, or output
packages unless the facts cue them.

Default output policy: produce the complete normal Plan scenario, assumption
ledger, summary, reconciliation, evidence manifest, and execution receipt when
the reviewed case supports them. Natural outputs are not choices to propose.

1. Start with a visible markdown checklist covering intake, source inspection,
   dependency check, assumption review, deterministic Plan run,
   reconciliation, professional review, and delivery.
2. Show a Run Intake table with the case and source paths, output folder,
   Actual and Plan scenarios, period mapping, reporting currency, dimensions,
   reviewed assumptions, and unresolved items.
3. Show a compact Decision Table for unresolved driver meanings, scopes,
   periods, FX direction, priorities, collisions, exclusions, or evidence
   limitations.
4. Before long-running or write-heavy work, show an execution checkpoint with
   the command intent, inputs, output folder, and expected artifacts. Seek
   approval only under the approval boundary stated below.
5. End with an Artifact Card listing every delivered file, its purpose, Plan
   and reconciliation status, unresolved professional-review items, and next
   action. When useful, write `codex_run_review.md` beside the run artifacts.
   Never edit plugin source or generated ZIPs during a user-data run.

## Run workflow

Reserve explicit approval for external, destructive, approval-sensitive, or
materially unresolved steps. The assumption-table confirmation is required
because it fixes a material planning choice; ordinary local inspection and
validation should continue without an extra approval step.

1. Establish the Actual source, reporting currency, Actual-to-Plan period
   mapping, dimensions, assumptions, and review audience.
2. Run the dependency check from the module root:

```bash
python scripts/check_dependencies.py
```

The declared `requirements.txt` is standard-library only. Do not install
undeclared packages.
3. Prepare the reviewed case contract. It must bind the source hash, period
   mapping, scenario codes, reporting currency, dimension columns, default
   discount and COGS behavior, structured assumptions, and professional-review
   receipt.
4. Run:

```bash
python scripts/run_plan.py \
  --case <case.json> \
  --output-dir <fresh-output-directory>
```

5. Stop on failed reconciliation or any unmatched scope, unsupported driver,
   stale source hash, ambiguous collision, or missing metric.
6. Deliver the Plan scenario and review artifacts. A passed run proves exact
   execution and reproducibility; it does not approve the assumptions or the
   resulting Plan.

## Natural outputs

- `sales_plan_scenario.csv`;
- `assumption_application_ledger.csv`;
- `scenario_summary.csv`;
- `reconciliation.json`;
- `prepared_evidence_manifest.json`;
- `plan_execution_receipt.json`.

Every result remains `report_ready=false` until professional review.

## Plugin Improvement Feedback

After completing substantive work, note technical defects or workflow gaps
without client or source details. Keep the improvement note local to chat or run artifacts.

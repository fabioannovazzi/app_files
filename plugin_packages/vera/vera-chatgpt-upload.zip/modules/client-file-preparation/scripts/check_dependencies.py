from __future__ import annotations

import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from check_environment import (  # noqa: E402
    CORE_DEPENDENCIES,
    OCR_DEPENDENCIES,
    Dependency,
    check_dependencies,
    input_requires_ocr,
    main,
)

__all__ = [
    "CORE_DEPENDENCIES",
    "OCR_DEPENDENCIES",
    "Dependency",
    "check_dependencies",
    "input_requires_ocr",
    "main",
]


if __name__ == "__main__":
    raise SystemExit(main())

---
name: mparanza-presenza-digitale-studio
description: Use when a commercialista or professional studio wants Vera to assess and refresh an existing informational website, create a first professional website from verified studio materials, prepare an unlisted review preview, or package an approved site for publication. Covers content hierarchy, restrained visual identity, responsive implementation, browser review, mechanical validation, and approval-bound publishing; excludes transactional portals, e-commerce, custom business applications, invented claims, and autonomous publication.
---

## Cowork execution contract

Select the exact files needed for this request. Folder access does not select
all its contents: if the task needs two files in a folder containing four, use
only those two. Resolve genuinely ambiguous choices with the user; reuse clear
choices without another confirmation.

Before parsing documents or creating a client, engagement or run, call
`check_studio_import_sources` with all selected paths on the actual importer
host. It needs no configured Archive and creates no records. If the MCP tool is
unavailable, use the packaged `check-import-sources --source-path <path>` CLI
through the maintained managed launcher on that same host (repeat the flag per
file). A cloud-shell `ls` is not proof of access by a computer-side importer.
Readable attachments, including `/mnt/user-data/uploads/` paths when the importer
can read them, continue directly without requiring a connected computer folder.

If files are unavailable, explain the cause immediately before creating anything:
"The file is in the chat, but the import tool looks for it on your computer."
Do not keep trying that same inaccessible path. Use this recovery sequence:

1. Inspect the host's actual callable file-transfer capabilities and the already
   connected folders. Reuse an authorized ordinary working folder outside the
   managed `Vera/engagements/.../inputs` tree. Offer **Add folder** from the **+**
   menu only when the current host offers it; otherwise explain the available
   connection method. Ask for a folder only if an accessible destination is needed.
2. With a supported bridge, copy only the selected original attachments to that
   folder as files. Compute each original SHA-256 through the host file tools.
   Do not recreate CSV text, convert encodings or line endings, relay document
   contents through model-authored tool arguments, guess a mount translation,
   overwrite a different file with the same name, or scan unrelated folders.
   A verified byte-for-byte copy may reuse its destination on retry.
3. Check the actual destination paths with `check_studio_import_sources`, passing
   `expected_sha256` as the original hashes in the same order as `source_paths`.
   The CLI takes one `--expected-sha256` per source. Archive hashes the destination
   locally and returns `ready=true` only when all supplied original hashes match.
   If no byte-preserving host transfer is available, say so and ask the user to
   save the original selected files to the accessible working folder; then verify
   them. Do not promise a bridge operation that is not callable.
4. Only after all selected sources are ready, select/create the client and
   engagement and import each through `import_studio_client_document` (CLI
   `import-document`). Pass that file's `expected_sha256` / `--expected-sha256`
   when a transfer was required. The importer checks it again during copying and
   creates the input ID and SHA receipt itself. Never manually populate `inputs`.

The path importer does not itself fetch chat attachments. Direct attachment use
requires actual importer access or a demonstrated host transfer. If neither an
importer-side check nor transfer is callable, explain the missing capability
before creating records; do not create a cloud-only replacement for a local Archive.

On any later import failure, disclose the existing `client_id` and `engagement_id`
and resume those same records. A folder-name collision calls for inspecting the
returned existing scope and reusing it when its identity matches; never clear old
folders or change the client's name just to get past the error. A deliberately
separate synthetic test may have a distinct name; retries retain their identities.
Documentless client work needs no file check. Standalone workflows check access
on their own execution host and do not require Archive or a computer folder when
that engine can read the inputs.

Public workflow names select skills; component IDs select module paths.
`financial-report-builder` uses component `report-builder`, `vouching` (historically
called Check Entries) uses `check-entries`, and `purchase-invoice-review` uses
`passive-invoice-audit`. These component IDs are not additional workflows.

For journal-sampling, open-item-reconciliation, journal-bank-reconciliation,
concordato-plan-review, financial-report-builder and vouching only, optional cache
cleanup uses the corresponding component ID from the installed Vera root:

```bash
python3 modules/<module>/scripts/implementation_bootstrap.py --repair
```

For a standalone module, use `python3 scripts/implementation_bootstrap.py --repair`
from its root. This validates the implementation first, then removes only regular,
single-link `__pycache__/*.pyc` files under that module's own `vendor` tree. It
leaves directories, other files, symlinks and shared vendor trees untouched.
This supported maintenance command is the only cache-cleanup exception to the
prohibition on editing the installed tree by hand. It is optional: ordinary
validation and execution tolerate incidental bytecode without removing it.
On a read-only installation, skip cleanup. If the command reports a permission
error, retain that error and continue the ordinary validated workflow when its
checks pass; do not chmod, delete files manually, copy or patch the installation,
or bypass the host's permissions to make cleanup succeed.
If `validate_implementation_tree` ever fails with a file/directory-contract
mismatch, do not delete or modify files inside the installed plugin tree by hand
and do not bypass a sandbox/permission rejection to do so. Stop and report the
exact error instead.

Work from the connected folder and supplied files first. Before a module's Python
helpers, locate the installed plugin root. When it contains `components.json` and
`scripts/managed_python_runtime.py` (as Vera does), run from that root:

```bash
python3 scripts/check_dependencies.py --module <module>
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

If the enclosing plugin does not ship this managed launcher, use the module's
dependency checker and only already-installed dependencies; do not assume that a
standalone module script provisions them.

The managed launcher provisions and reuses one user-scoped CPython 3.12
environment per OS host with the published, hash-checked dependency locks, outside client
folders. Modules and products share this dependency environment; it does not
isolate client matters. This declared dependency setup is authorized as
part of running the workflow; never install arbitrary packages or use ambient
Python for subsequent module helpers. Repeat any declared `--requirements` options
on both commands. Missing ambient imports are a reason to run this setup, not to
abandon the calculation. If setup fails, report its exact error and do not replace
the required calculation with an invented result. Optional OCR setup still needs
separate approval. If setup reports `Host not in allowlist` for PyPI, explain that
Claude Settings > Capabilities > Allow network egress is disabled or restricted.
Ask the user or organization administrator to authorize package-registry access;
never change network permissions silently or work around the restriction. Retry
the same managed setup after access is approved, in a new session if needed.

MCP tools, browser or computer control, and local review servers are optional
enhancements, never completion gates. Cloud Cowork sessions may not expose local
plugin MCP servers even when the plugin is installed; use the packaged Python
workflow through the managed launcher in that case. Do not equate missing MCP
registration with a failed calculation engine. When an optional capability is
unavailable, continue with Markdown and file-based review and state the limitation.

The normal Cowork deliverable is a reviewable draft, artifact card, and
source/review files. A callable persistence interface may optionally record or
apply reviewer actions, but its absence never blocks delivery. Never claim
`applied` or `final_ready` unless corresponding persisted artifacts prove it;
otherwise report that professional review remains pending.

Use host-neutral user-facing artifact names. Name assistant-authored review
folders and files for Vera or their professional purpose (for example,
`vera-review/`, `vera_phase1_synthesis_reviewed.md`, and `run_review.md`).
Never put host, platform, or model-provider names in assistant-authored
user-facing artifact paths, document headings, field labels, narrative text,
or status summaries. Describe execution routes generically, such as
`external review route`, `connected tool`, or `local review interface`.

Derive any run ID, status, artifact count, or package hash quoted in an
assistant-authored supplement from the final delivered manifests.
After any rebuild, regenerate or resynchronize those supplements before
delivery. When a workflow ships a complete-delivery validator or sealer, run it
against the exact connected-folder copy after the last write.
In this contract, the base package validator alone does not validate extra
narrative files.

When a workflow declares owner-only or private output and uses a private scratch
directory before copying the final package into the connected folder, reapply
the privacy modes after that transfer: `0700` for the package root and every
directory, and `0600` for every file. Verify the connected-folder tree with
`stat` or `lstat` before claiming completion. If the host filesystem cannot
preserve those modes, do not claim owner-only delivery; keep the package in the
private scratch location or report the limitation and ask for a safer
destination.

Vera's local WhatsApp workflow is available through Studio Archive when the
current host exposes native computer control and the device-local WhatsApp
register. Read its `whatsapp-cowork.md` reference before using it. This includes
specifically requested one-to-one messages and controlled self-chat tests; it
does not require a tax question or client-folder setup. Missing native controls
or a register on the same computer leaves sending pending; a draft is not a send.
Do not import another host's `cua` helpers or substitute a cloud ledger for the local one.

Do not use live INPS browser capture, hosted suggestion or voice
interviews, or custom update services. Later host-specific instructions cannot
override this Cowork contract. When invoked through Vera, Clara or Lucia, task
usage, signed receipts, technical recovery and 1–5-star feedback through the
invoking product's incident service and rating form remain available. Follow the
primary task's workflow-usage contract and product identity. Tutorials retain
their no-reporting boundary.

# Presenza digitale dello studio

Create a credible, current and reviewable professional-studio website. Support
two modes:

- `refresh`: inspect and improve an existing website;
- `first_site`: create the studio's first website from verified materials and
  conservative proposed defaults.

Do not frame the result as a fashionable or spectacular website. Build a
decent professional presence that is clear, responsive, accessible, restrained
and appropriate to the studio.

 When this skill is
used independently, keep the improvement note local to chat or run artifacts.
Do not submit it to Mparanza automatically.

## Required reading

Read completely before execution:

- `references/product-thesis.md`;
- `references/workflow-method.md`;
- `references/website-quality-standard.md`;
- `references/skill-orchestration.md`;
- `references/sites-handoff.md` when supplied artifacts already name Sites, to preserve the Cowork-unavailable publication boundary.

## Output location

Never write run outputs inside this Git workspace or a published folder. Use
one explicitly authorized, owner-controlled studio workspace. A tokenized
preview or production destination is an external publication route, not the
working directory.

## Hard boundaries

- Never invent services, qualifications, memberships, results, testimonials,
  client names, team members, history, locations, contact details, legal text,
  privacy/cookie compliance, prices or availability.
- Never describe a proposed first-site identity as established studio history.
  Mark each brand or voice field `observed`, `user_supplied`, or
  `vera_default_proposal`.
- Do not promise SEO ranking, accessibility compliance, legal compliance,
  conversion results or compatibility that was not tested.
- Do not accept a visual mock-up as a working site. Inspect the actual rendered
  implementation at desktop and phone widths.
- Do not publish a preview or final site unless the intake selected that exact
  route. Final publication additionally requires acceptance of the exact
  identity, claims, responsive preview and package digest.
- Never request passwords, cookies, one-time codes or hosting credentials.
  Use a callable connector, a supported authenticated browser, or a user-run
  handoff without exposing credentials.
- Keep transactional portals, client areas, e-commerce, booking/payment flows,
  contact forms, third-party embeds, remote executable scripts, bespoke
  applications and regulatory legal drafting outside this workflow. Identify
  them as separate, explicitly reviewed integrations rather than hiding them
  inside an informational-site build.
- Reserve explicit approval for external, destructive, approval-sensitive, or
  materially unresolved steps. Do not add ceremonial pauses to reversible
  inspection, drafting, implementation or local validation.
- Keep selected source files and working outputs local in the owner-controlled
  workspace by default. Deterministic scripts own snapshots, hashes,
  mechanically verifiable HTML checks, review freshness and package binding;
  model-led skills own semantic and visual judgment.
- Select a file or confirmed fact only when the professional has approved it
  for website work. This confirms the purpose of the source; it does
  not accept every statement in the source as final website copy.
- During evidence mapping, the selected runtime may read the complete approved
  source when the brief requires it. After the brief is recorded, follow its
  `source_use_plan`: default to mapped facts, use only named excerpts or assets
  for targeted access, and reopen a complete source only when the model records
  a concrete professional reason. Do not use deterministic code to decide
  relevance or to classify personal data.

## Cowork-native Run UX

1. Show a checklist covering dependencies, Run Intake, evidence, brief,
   implementation, desktop and phone review, approval and packaging.
2. Show a Run Intake table with the studio, mode, objective, audience,
   requested pages, selected materials, private output path and each external
   route posture.
3. Use a Decision Table only for unresolved material choices that change
   identity, scope, claims, destination or authorization. Populate it from the
   actual inputs; do not offer page sets, style labels or platforms unless the
   facts cue them.
4. Before a write-heavy stage, show an execution checkpoint with the bound
   inputs, private output path, intended command and expected files. Pause only
   when an unresolved answer would materially change the site or an approval
   boundary.
5. End with the Artifact Card defined below.

Default output policy: create the private JSON, HTML, CSS, asset, screenshot and
package artifacts required by the selected mode. These are not choices to
propose. When useful, save the visible run summary as `run_review.md`
beside the package. Never edit plugin source or generated ZIPs during a studio
website run.

## Workflow

1. Run `python scripts/check_dependencies.py` from the resolved plugin root.
   Do not install missing requirements at runtime.
2. Determine `refresh` or `first_site` from the evidence. Do not ask when the
   presence or absence of an existing website is clear.
3. Show a compact Run Intake with studio, mode, objective, audiences, selected
   materials, requested pages, current platform when known, and five external
   route records: `public_site_inspection`, `studio_material_connector`,
   `creative_assistance`, `preview_publication`, and `final_publication`. Each
   route records its provider. Cowork must not select `sites` for a new route;
   use another provider only when the professional explicitly selects it.
4. Before helper scripts or write-heavy work, identify material choices that
   would change execution: public identity, audience, information scope,
   destination or review posture. Ask only those unresolved choices in chat.
   Generate choices from the actual inputs; do not offer named frameworks or
   style taxonomies unless the facts cue them or the user must supply a missing
   custom value. For `first_site`,
   default to a small informational site and label the initial visual system
   as a Vera proposal. Do not require a logo, slogan, testimonials or a brand
   manual.
5. Initialize the private workspace once and prepare the run:

   ```bash
   python scripts/initialize_workspace.py \
     --workspace <private-workspace> \
     --workspace-id <stable-id> \
     --owner <studio-or-professional> \
     --retention-owner <studio-or-professional> \
     --confirmed-by-user

   python scripts/prepare_run.py \
     --workspace <private-workspace> \
     --intake <website_intake.json>
   ```

   Preparation requires at least one selected evidence file or one exact fact
   explicitly confirmed by the professional. Every `selected_files` and
   `confirmed_facts` entry must record `approved_for_website_use: true`; do not
   prepare the run until the professional has selected that material for the
   website purpose. Put chat-confirmed first-site facts in
   `confirmed_facts`; preparation snapshots each fact as immutable evidence
   without asking the professional to manufacture a document. It snapshots every
   selected local file, records SHA-256 and creates `work/site/` plus the
   optional `work/sites-project/`. A URL is not a source snapshot. When public inspection was
   selected, capture the exact HTML, screenshots or extracted evidence used and
   add those local files to a new prepared run.
6. Inspect evidence and write `site_brief.json` against its schema. Include one
   `source_use_plan` entry for every selected evidence ID. The model assigns the
   professional purpose and chooses `mapped_brief_only`, `targeted_material`, or
   `full_source_required`; exact locators identify every targeted excerpt, page,
   section, asset or code path. Use `full_source_required` only with a concrete
   reason specific to the website work. Deterministic validation checks schema
   shape and exact source-ID coverage only; it does not decide which mode is
   professionally appropriate. In
   `refresh`, distinguish observations from proposed changes. In `first_site`,
   distinguish supplied facts from proposed information architecture, voice
   and visual defaults. Run:

   ```bash
   python scripts/record_site_brief.py \
     --run-dir <run-dir> --brief <site_brief.json> \
     --provider <provider> --model <model> --recorded-by <operator>
   ```

7. Use the host-skill sequence in `references/skill-orchestration.md`. After the
   brief is recorded, give downstream design, copy and implementation work the
   current brief plus only the material permitted by `source_use_plan`. Do not
   reopen `mapped_brief_only` sources. For `targeted_material`, use only the
   named material. Reopen a `full_source_required` source only for its recorded
   reason, then return to the mapped brief. When a
   named skill is callable, read and follow it rather than imitating it. Use
   the internal quality standard only for unavailable skills. Build the actual
   site in `work/site/`; keep primary content and navigation usable without
   JavaScript unless a requested feature requires it.
8. Validate mechanically:

   ```bash
   python scripts/validate_site.py --run-dir <run-dir>
   ```

   The validator checks only mechanically verifiable properties: file
   integrity, required HTML metadata, heading shape, alternative-text
   presence, duplicate IDs, local link/asset closure, unsafe schemes, out-of-scope
   forms and active embeds, placeholders and preview-indexing posture. It does not judge aesthetics,
   copy quality, accessibility conformance or professional truth.
9. Render the exact site in a browser at desktop and phone widths. Inspect the
   full page, interaction state, overflow, navigation, images, typography,
   hierarchy and console errors. Save the exact full-page PNG or JPEG for each claimed
   viewport below `reviews/browser/`, preserving the original bytes and matching
   `.png`, `.jpg` or `.jpeg` extension. Record its run-relative path and SHA-256
   in `quality_assessment.json`, then record it:

   ```bash
   python scripts/record_quality_assessment.py \
     --run-dir <run-dir> --assessment <quality_assessment.json> \
     --provider <provider> --model <model> --recorded-by <operator>
   ```

   A `revise` or `blocked` verdict requires correction and a new validation and
   assessment. Do not mark the site ready from file existence or one viewport.
10. Package an unlisted preview only when `preview_publication` was selected:

    ```bash
    python scripts/package_website.py --run-dir <run-dir> --kind preview
    ```

    The preview package requires `noindex, nofollow, noarchive` on every page
    and binds exact bytes. Publish it only to the selected destination and
    verify the visible URL. Cowork cannot initiate a Sites publication. For
    another explicitly selected provider, use `record_external_delivery.py`;
    for supplied Sites artifacts, follow `references/sites-handoff.md` and
    keep any unproven publication pending.
11. Present one visible review matrix for `identity_and_claims`,
    `responsive_preview` and `publication_destination`. Record only explicit
    decisions against the current site digest:

    ```bash
    python scripts/record_review.py --run-dir <run-dir> \
      --scope <scope> --decision accepted|returned|rejected \
      --reviewer <professional> --confirmed-by-user
    ```

12. Remove every preview robots directive, then revalidate, repeat browser
    assessment and obtain current reviews for the changed release bytes.
    Package the release only after all three scopes are accepted:

    ```bash
    python scripts/package_website.py --run-dir <run-dir> --kind release
    python scripts/validate_run.py --run-dir <run-dir>
    ```

    Publish only through the exact selected route. Verify the live site and
    record the exact URL or receipt. A package is not evidence of publication.

    When supplied artifacts name Sites, follow `references/sites-handoff.md`,
    review the existing binding and receipt as evidence, and keep publication
    pending unless those artifacts already prove a succeeded deployment.

## Completion

End with an Artifact Card containing mode, evidence coverage, post-brief source
use modes, brief version,
skill routes used and unavailable, mechanical validation status, browser
viewports inspected, current site digest, reviews, preview URL, release
package, final URL, unresolved issues and the next authorized action.

Completion states are:

- `preview_ready`: exact preview package exists and is mechanically and
  visually ready;
- `release_ready`: exact release package and all required reviews are current;
- `published`: a visible final URL or provider receipt is bound to the exact
  release digest;
- `partial`: useful work exists but an optional capability or material input is
  missing;
- `blocked`: identity, evidence, validation or approval required for the next
  claimed state is absent.

---
name: mparanza-studio-archive
description: Use when Lucia must create or resume a durable client engagement, import selected inputs, and prepare or start a client-bound workflow through the Studio Archive component shared with Vera.
---
<!-- MPARANZA_REPORTING_BEGIN -->
## Task reporting and recovery

For every substantive user mandate, follow
`skills/mparanza-lucia/references/workflow-usage.md` from this installation's root.
Start one primary task before preparation, using `usage/pipelines.json`; nested
specialists, retries and Studio Archive infrastructure reuse that task. Record
only the observed whole-task outcome. Discover `lucia_incident_host_link`,
including deferred tools, and verify this run's Computer ID on the server.
Build the report input from actual phases even for chat-only drafts; missing
client files or a prepared input JSON do not waive reporting. Show the readable
local model-data report under `skills/mparanza-lucia/references/model-data-report-contract.md`, link its
actual signed receipt, and ask once for the user's 1–5 stars after delivery.
Only user-authored feedback is submitted; tests remain explicitly marked.
Follow `skills/mparanza-lucia/references/incident-recovery.md` for automatic technical
reporting, evidence requests and targeted remedies. Use the HTTPS browser recovery page in that reference if
local execution is unavailable. Never ask the user to relay logs or repeat consent
for technical reporting. Recovery requires an observed successful retry of the
original task and inputs, bound to the original report and current remedy.
Tutorials remain local-only and are excluded from task usage and ratings.
<!-- MPARANZA_REPORTING_END -->


# Archivio dello studio

Resolve `../../modules/studio-archive` from this skill directory when it
exists; otherwise resolve `../../../studio-archive` in the repository. Read
that module's `skills/mparanza-studio-archive/SKILL.md` completely and follow it.
Treat the resolved module root as the plugin working directory for every
command. Do not paraphrase, shorten, fork, or replace the component workflow.

Use the plain Studio Archive tools under `lucia`. Prepare only the workflows
declared in Lucia’s `components.json`: `prompt-optimizer`,
`deep-research-validator`, and `apertura-pratica`. The shared component guide
also describes other products: use its client, engagement, file, search,
snapshot, and run lifecycle instructions for Lucia. Journal sampling, invoice
checks, and verification of Vera’s selective reporting receipts are outside
Lucia’s Archive. Use the common studio root and client directory shared with Vera
and Clara. Every project has lowercase `vera/`, `lucia/` and `clara/` folders. New Lucia
engagements go under `lucia/`. The layout normalizer changes legacy folder casing
without rewriting sealed evidence; readers resolve retained historical paths.

For CLI fallback, use Lucia’s `scripts/lucia_studio_archive.py` at the product
root with the same arguments as the component guide. It applies Lucia’s workflow
list and retains the same client, engagement, receipts and lifecycle.

Lucia's public experience and deliverables are in Italian.

The shared root and project directory do not share engagements. Show, search and
resume only this product’s work, documents, results and chat links. Reuse a shared
project when creating new work without adopting another product’s engagement.

# Lucia

[Pagina prodotto](https://mparanza.com/static/shared/lucia/index.html?lang=it) ·
[Supporto](https://mparanza.com/support) ·
[Licenza GNU AGPLv3](https://github.com/fabioannovazzi/app_files/blob/main/LICENSE)

Lucia è l’assistente AI di Mparanza per avvocati indipendenti e piccoli studi
legali. Prepara ricerca e validazione, comunicazioni professionali e siti
informativi mantenendo visibili perimetro, fonti, affermazioni, incertezze e
passaggi riservati al giudizio professionale.

Lucia non sostituisce l’avvocato: strategia, conclusioni, approvazione e
responsabilità restano al professionista.

## Catalogo corrente

Il catalogo cresce attraverso workflow specialistici registrati. Le funzioni
attualmente pubbliche sono:

- **Revisione contratti** — Esamina clausole, rischi e modifiche proposte per la parte assistita.
- **Confronto documenti** — Confronta versioni e accordi con riferimenti puntuali.
- **Revisione documentale** — Esamina più documenti in una tabella con evidenze e lacune.
- **Redazione da modello** — Compila una copia del modello con modifiche e fatti tracciabili.


- **Risposta a quesiti legali e fiscali** — Porta un quesito legale, fiscale o
  di compliance dalla domanda iniziale a una risposta con fonti, ragionamento
  e limiti professionali verificati.
- **Ottimizzazione prompt** — Trasforma un quesito legale, fiscale o di conformità
  in una ricerca con perimetro, fonti e verifiche definite.
- **Validazione ricerca** — Controlla le affermazioni rispetto alle fonti
  citate e prepara il materiale consolidato.
- **Parere contrapposto** — Sviluppa e verifica la posizione contraria a un
  parere concreto, oppure un risultato negativo o limitato dalle evidenze,
  e confronta le conclusioni per la revisione dell’avvocato.
- **Comunicazione professionale** — Decide se una novità merita di essere
  comunicata e prepara email, circolari, articoli, post, FAQ, alert e visuali
  verificabili per la revisione dell’avvocato.
- **Sito dello studio** — Crea o rinnova il sito informativo dello
  studio legale da materiali verificati, con review desktop e telefono, preview
  e pubblicazione subordinata all’approvazione.
- **Fascicolo nuova pratica** — Prepara l’apertura di una nuova pratica per un nuovo
  cliente o per un cliente esistente: evidenze, soggetti, controllo conflitti,
  incarico, possibili scadenze, antiriciclaggio condizionale e piano del
  fascicolo restano espliciti e soggetti alla revisione dell’avvocato.

Legal/Tax Answer Planner e Legal/Tax Answer Review sono le stesse implementazioni
canoniche incorporate in Vera. Lucia non ne mantiene copie divergenti: il
builder include gli stessi file sorgente e i test verificano l’uguaglianza dei
byte nei pacchetti generati.

Risposta a quesiti legali e fiscali è una skill di orchestrazione: usa quei due
componenti come fasi separate e prepara la risposta tra le due. Non crea un
terzo workstream, non duplica gli artefatti e non cambia le destinazioni dei
dati.

Lo stesso componente Legal/Tax Answer Review contiene anche il metodo e il
codice del parere contrapposto. La ricerca informativa termina dopo la
validazione; un parere su una posizione concreta o una richiesta esplicita
include il contrapposto, salvo istruzioni di esclusione. Dopo la preparazione,
Lucia propone il plugin Deep Research quando è disponibile nella sessione
oppure la ricerca ordinaria. Questa scelta non determina il contrapposto.

Comunicazione professionale e Presenza digitale riusano la stessa macchina
canonica di Vera per evidenze, review, rendering, preview, hash e packaging, ma
passano da wrapper Lucia con un profilo distinto per avvocati. Il profilo
disciplina riservatezza, identità professionale, affermazioni pubbliche,
applicabilità e approvazione della pubblicazione.

Fascicolo nuova pratica è un workflow nativo di Lucia. Riusa Studio Archive soltanto
per il ciclo privato di cliente, incarico, input e run; applica uno schema, un
validatore e ricevute di revisione specifici per l’apertura della pratica.

## Come lavora

1. Lucia interpreta semanticamente la richiesta e la instrada al workflow
   specialistico registrato appropriato.
2. Per una risposta completa, Risposta a quesiti legali e fiscali coordina
   contratto della risposta, ricerca o generazione e verifica finale.
3. Legal/Tax Answer Planner e Legal/Tax Answer Review restano invocabili separatamente
   quando serve soltanto preparare il quesito o controllare una risposta già
   prodotta.
4. Il risultato resta una bozza rivedibile. Lucia non firma pareri, deposita
   atti, invia comunicazioni o assume decisioni professionali.

Se nessun workflow registrato copre la richiesta, Lucia si ferma e indica che
la funzione non è ancora disponibile. Nuove funzioni possono essere aggiunte
al catalogo senza cambiare il contratto dei workflow esistenti.

## Superfici

- **ChatGPT Work** usa i materiali disponibili nella conversazione e non
  dichiara di avere eseguito strumenti locali o creato artefatti persistenti.
- **Codex** può lavorare nel workspace locale, eseguire i controlli dichiarati
  e conservare artefatti rivedibili quando le capacità sono disponibili.

Studio Archive è incluso nel pacchetto Codex soltanto come infrastruttura
privata per legare input, run e risultati a un incarico. Lucia non espone
ricerca d’archivio, Gmail, Google Drive o WhatsApp come funzioni pubbliche. Il
pacchetto per ChatGPT non include questo runtime privato.

## Sorgente e pacchetti

La sorgente modificabile vive in `plugins/lucia`. I pacchetti generati sono:

- `plugin_packages/lucia/lucia-plugin.zip` per Codex;
- `plugin_packages/lucia/lucia-chatgpt-upload.zip` per la submission ChatGPT;
- `plugin_packages/lucia/lucia-claude-plugin.zip` per Claude Cowork, pubblicato
  anche come `static/shared/lucia/downloads/lucia-cowork-plugin.zip`.

I tre ZIP in `plugin_packages/lucia/` sono artefatti locali ignorati da Git e non
devono essere modificati a mano. Si generano con
`python scripts/build_product_release.py lucia`, oppure si scaricano dall'artefatto
CI `product-archives` dello stesso commit, da estrarre in `plugin_packages/`.
La directory sorgente per Claude e il download pubblico rimangono nel repository.

Per ricostruirli e verificare che corrispondano alla sorgente:

```bash
.venv/bin/python scripts/build_codex_plugin_zip.py lucia
.venv/bin/python scripts/build_codex_plugin_zip.py lucia --check
.venv/bin/python scripts/build_claude_plugin_zip.py lucia
.venv/bin/python scripts/build_claude_plugin_zip.py lucia --check
```

## Dati e confini professionali

I dati forniti al modello vengono trattati attraverso il piano ChatGPT già
utilizzato dall’utente. I workflow ordinari non inviano a Mparanza file dei
clienti, prompt o contenuti del contesto del modello. Password, chiavi API,
cookie, token e dati di sessione non devono entrare nei prompt o nei file
leggibili da Codex.

La descrizione completa è disponibile nella pagina
[Gestione dei dati](https://mparanza.com/data-handling?lang=it).

## Python runtime

Python workflows use **CPython 3.12 only**. The managed setup reuses Python 3.12, finds an installed 3.12 interpreter, or provisions it with an already installed `uv`. It never creates workflow environments with another Python minor version. If neither is available, setup gives an explicit installation instruction. Existing environments are preserved; separate component dependency environments remain necessary until their dependency sets are consolidated.

## Workflow documentali incorporati

I quattro workflow hanno un metodo proprio per lo studio italiano: distinguono
rapporto e ruoli, condizioni predisposte e trattativa, diritto applicabile e foro,
rilievi giuridici e preferenze negoziali. Report e tabelle conservano fonti verificate,
questioni aperte e istruzioni dello studio; i rapporti soggetti a diritto estero
restano tali. I riferimenti MIT di Mike sono conservati invariati con attribuzione,
commit e checksum; non sono più le istruzioni operative.

Gli helper locali non chiamano rete o modelli e non installano Mike o un server.
Il modello ospite legge i documenti selezionati e produce il giudizio; il codice
controlla soltanto file, copertura dichiarata, contesto e occorrenza delle citazioni.
Lucia mantiene autonomamente l'adattamento italiano: può riprendere miglioramenti
upstream dopo verifica, ma non promette compatibilità o aggiornamenti automatici.

## Google Antigravity

Build the Antigravity ZIP with `python scripts/build_antigravity_plugin.py lucia`.
The projection includes the canonical skills, the Lucia agent, embedded
modules, scripts and any configured MCP servers. Install the complete extracted
`lucia` folder with `agy plugin install "/path/to/lucia"`; then use
`agy --agent lucia`. For the desktop installation and host limitations, see
[the installation guide](https://mparanza.com/static/shared/lucia/antigravity/index.html).

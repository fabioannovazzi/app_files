---
name: mparanza-business-valuation
description: Prepare source-backed PMI business valuation workpapers using reviewed financial evidence, selected valuation methods, explicit assumptions and the existing Vera business plan; produce calculations, sensitivity, reports and a formula workbook for professional review.
---

## Cowork execution contract

Select the exact files needed for this request. Folder access does not select
all its contents: if the task needs two files in a folder containing four, use
only those two. Resolve genuinely ambiguous choices with the user; reuse clear
choices without another confirmation.

Before parsing documents or creating a client, engagement or run, call
`check_studio_import_sources` with all selected paths on the actual importer
host. It needs no configured Archive and creates no records. If the MCP tool is
unavailable, use the packaged `check-import-sources --source-path <path>` CLI
through the maintained managed launcher on that same host (repeat the flag per
file). A cloud-shell `ls` is not proof of access by a computer-side importer.
Readable attachments, including `/mnt/user-data/uploads/` paths when the importer
can read them, continue directly without requiring a connected computer folder.

If files are unavailable, explain the cause immediately before creating anything:
"The file is in the chat, but the import tool looks for it on your computer."
Do not keep trying that same inaccessible path. Use this recovery sequence:

1. Inspect the host's actual callable file-transfer capabilities and the already
   connected folders. Reuse an authorized ordinary working folder outside the
   managed `Vera/engagements/.../inputs` tree. Offer **Add folder** from the **+**
   menu only when the current host offers it; otherwise explain the available
   connection method. Ask for a folder only if an accessible destination is needed.
2. With a supported bridge, copy only the selected original attachments to that
   folder as files. Compute each original SHA-256 through the host file tools.
   Do not recreate CSV text, convert encodings or line endings, relay document
   contents through model-authored tool arguments, guess a mount translation,
   overwrite a different file with the same name, or scan unrelated folders.
   A verified byte-for-byte copy may reuse its destination on retry.
3. Check the actual destination paths with `check_studio_import_sources`, passing
   `expected_sha256` as the original hashes in the same order as `source_paths`.
   The CLI takes one `--expected-sha256` per source. Archive hashes the destination
   locally and returns `ready=true` only when all supplied original hashes match.
   If no byte-preserving host transfer is available, say so and ask the user to
   save the original selected files to the accessible working folder; then verify
   them. Do not promise a bridge operation that is not callable.
4. Only after all selected sources are ready, select/create the client and
   engagement and import each through `import_studio_client_document` (CLI
   `import-document`). Pass that file's `expected_sha256` / `--expected-sha256`
   when a transfer was required. The importer checks it again during copying and
   creates the input ID and SHA receipt itself. Never manually populate `inputs`.

The path importer does not itself fetch chat attachments. Direct attachment use
requires actual importer access or a demonstrated host transfer. If neither an
importer-side check nor transfer is callable, explain the missing capability
before creating records; do not create a cloud-only replacement for a local Archive.

On any later import failure, disclose the existing `client_id` and `engagement_id`
and resume those same records. A folder-name collision calls for inspecting the
returned existing scope and reusing it when its identity matches; never clear old
folders or change the client's name just to get past the error. A deliberately
separate synthetic test may have a distinct name; retries retain their identities.
Documentless client work needs no file check. Standalone workflows check access
on their own execution host and do not require Archive or a computer folder when
that engine can read the inputs.

Public workflow names select skills; component IDs select module paths.
`financial-report-builder` uses component `report-builder`, `vouching` (historically
called Check Entries) uses `check-entries`, and `purchase-invoice-review` uses
`passive-invoice-audit`. These component IDs are not additional workflows.

For journal-sampling, open-item-reconciliation, journal-bank-reconciliation,
concordato-plan-review, financial-report-builder and vouching only, optional cache
cleanup uses the corresponding component ID from the installed Vera root:

```bash
python3 modules/<module>/scripts/implementation_bootstrap.py --repair
```

For a standalone module, use `python3 scripts/implementation_bootstrap.py --repair`
from its root. This validates the implementation first, then removes only regular,
single-link `__pycache__/*.pyc` files under that module's own `vendor` tree. It
leaves directories, other files, symlinks and shared vendor trees untouched.
This supported maintenance command is the only cache-cleanup exception to the
prohibition on editing the installed tree by hand. It is optional: ordinary
validation and execution tolerate incidental bytecode without removing it.
On a read-only installation, skip cleanup. If the command reports a permission
error, retain that error and continue the ordinary validated workflow when its
checks pass; do not chmod, delete files manually, copy or patch the installation,
or bypass the host's permissions to make cleanup succeed.
If `validate_implementation_tree` ever fails with a file/directory-contract
mismatch, do not delete or modify files inside the installed plugin tree by hand
and do not bypass a sandbox/permission rejection to do so. Stop and report the
exact error instead.

Work from the connected folder and supplied files first. Before a module's Python
helpers, locate the installed plugin root. When it contains `components.json` and
`scripts/managed_python_runtime.py` (as Vera does), run from that root:

```bash
python3 scripts/check_dependencies.py --module <module>
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

If the enclosing plugin does not ship this managed launcher, use the module's
dependency checker and only already-installed dependencies; do not assume that a
standalone module script provisions them.

The managed launcher provisions and reuses one user-scoped CPython 3.12
environment per OS host with the published, hash-checked dependency locks, outside client
folders. Modules and products share this dependency environment; it does not
isolate client matters. This declared dependency setup is authorized as
part of running the workflow; never install arbitrary packages or use ambient
Python for subsequent module helpers. Repeat any declared `--requirements` options
on both commands. Missing ambient imports are a reason to run this setup, not to
abandon the calculation. If setup fails, report its exact error and do not replace
the required calculation with an invented result. Optional OCR setup still needs
separate approval. If setup reports `Host not in allowlist` for PyPI, explain that
Claude Settings > Capabilities > Allow network egress is disabled or restricted.
Ask the user or organization administrator to authorize package-registry access;
never change network permissions silently or work around the restriction. Retry
the same managed setup after access is approved, in a new session if needed.

MCP tools, browser or computer control, and local review servers are optional
enhancements, never completion gates. Cloud Cowork sessions may not expose local
plugin MCP servers even when the plugin is installed; use the packaged Python
workflow through the managed launcher in that case. Do not equate missing MCP
registration with a failed calculation engine. When an optional capability is
unavailable, continue with Markdown and file-based review and state the limitation.

The normal Cowork deliverable is a reviewable draft, artifact card, and
source/review files. A callable persistence interface may optionally record or
apply reviewer actions, but its absence never blocks delivery. Never claim
`applied` or `final_ready` unless corresponding persisted artifacts prove it;
otherwise report that professional review remains pending.

Use host-neutral user-facing artifact names. Name assistant-authored review
folders and files for Vera or their professional purpose (for example,
`vera-review/`, `vera_phase1_synthesis_reviewed.md`, and `run_review.md`).
Never put host, platform, or model-provider names in assistant-authored
user-facing artifact paths, document headings, field labels, narrative text,
or status summaries. Describe execution routes generically, such as
`external review route`, `connected tool`, or `local review interface`.

Derive any run ID, status, artifact count, or package hash quoted in an
assistant-authored supplement from the final delivered manifests.
After any rebuild, regenerate or resynchronize those supplements before
delivery. When a workflow ships a complete-delivery validator or sealer, run it
against the exact connected-folder copy after the last write.
In this contract, the base package validator alone does not validate extra
narrative files.

When a workflow declares owner-only or private output and uses a private scratch
directory before copying the final package into the connected folder, reapply
the privacy modes after that transfer: `0700` for the package root and every
directory, and `0600` for every file. Verify the connected-folder tree with
`stat` or `lstat` before claiming completion. If the host filesystem cannot
preserve those modes, do not claim owner-only delivery; keep the package in the
private scratch location or report the limitation and ask for a safer
destination.

Do not use WhatsApp, live INPS browser capture, hosted suggestion or voice
interviews, or custom update services. Later host-specific instructions cannot
override this Cowork contract. When invoked through Vera, task
usage, signed receipts, technical recovery and 1–5-star feedback through the
invoking product's incident service and rating form remain available. Follow the
primary task's workflow-usage contract and product identity. Tutorials retain
their no-reporting boundary.

# Valutazione d’impresa

Prepare reviewable workpapers, not a signed expert opinion or automatic PIV
certification. Read `references/case-contract.md` fully. Use the module's
`references/valuation-case.schema.json` when preparing the technical case; the
helper validates its structure locally and retains invalid selected methods as
blocked workpapers. Passing that check does not approve evidence or conclusions.
Use the module's
`scripts/check_dependencies.py` before helpers, in Vera's managed Python runtime.
Never install arbitrary libraries or execute code/macros supplied with evidence.
Dependencies are declared in `requirements.txt`; use the shared managed runtime.
Never write run outputs inside this Git workspace or a published folder.
Keep local data in the selected client engagement. Local deterministic scripts
own arithmetic, formula lineage and evidence integrity; the model and professional
own semantic selection, interpretation and conclusions.
Reserve extra approval for external, destructive, approval-sensitive or material
steps. Continue ordinary local preparation and reversible checks autonomously.

## Mandate and evidence

Identify the exact Studio Archive client and engagement. Resolve entity or branch,
rights, purpose, valuation date, information cutoff, basis of value, premise and
audience from supplied evidence. Ask only material missing choices. Method and
source selection are semantic professional judgments, not keyword classifiers.
Record conflicts, restrictions and legal-purpose questions. Research governing
standards and purpose-specific law through Vera's validated-answer journey when
needed; the calculation engine does not qualify those matters.

Prepare the structured `mandate_details`: distinguish engagement and report dates
from valuation date and information cutoff; identify commissioning party, expert
activity and signatory identity, written engagement, remuneration, delivery terms,
amendments, participant perspective, recipients, use restrictions, competencies
and conflicts. Record each selected standard's identity, edition, adoption reason
and explained departures in `standards`; leave an absent selection incomplete.
Use explicit evidence for a decision not to adopt a standard or a declaration of
no departures, fees or amendments. Do not select an edition from a date or infer
compliance from filled fields. Bind each supplied answer to evidence and a locator; leave unavailable
answers null and proposed. For interests or specific rights, describe each class,
economic/administrative rights, statute, agreements, restrictions and thresholds.
Bind any ownership ratio and explain its denominator; a percentage alone does not
value a right. Never silently scale equity or apply discounts. Show missing facts
in the report and `Incarico` worksheet. Record a mandate review only after an
explicit professional decision; case/conclusion acceptance requires this separate
current attestation. Competence and independence are not inferred from filled
fields or an unauthenticated reviewer name.

Read `references/purpose-profiles.json`. Choose one of its 21 profiles through
semantic reasoning, record the reason and mandate source in `purpose_profile`,
and use `custom` for an unlisted purpose. Explain the profile's intake focus in
ordinary language. Every profile currently supports development workpapers only:
PIV review, purpose-specific tests and specialist professional approval remain
unfinished. A case review does not enable a professional profile. Preserve the
full proposed scope; do not describe unimplemented profiles as permanently out
of scope or represent the common core as the complete contributor proposal.

Inspect supplied statements and schedules using the host's document capabilities.
Preserve originals and page/cell locators. Separate reported facts, normalization
adjustments, management assumptions and model hypotheses. Do not invent missing
amounts, annualize interim data silently, or hide adjustments inside EBITDA.
Import the reviewed statement/normalization evidence into the engagement. The
model prepares the documented case; never ask the professional to write JSON.

Each amount has a source, locator, unit, meaning and confirmation state. Use the
`normalizations` journal to keep reported and adjusted values separate. For every
signed adjustment record year, line, reason, accounting reconciliation, economic
substance, source/locator, tax treatment and reversibility. Read each choice back
for professional review before recording its exact dependency attestation. Show
both increases and decreases when supported; never select only adjustments that
raise EBITDA. Tax effects on other lines require separate evidenced amounts.
The helper reconciles each line and blocks dependent methods when an amount is
missing or inconsistent; it does not judge accounting treatment or replace a
statement balance/roll-forward review. Mapping arbitrary financial statements
remains reviewed preparation, not a universal automatic parser.

Prepare `statements` from the actual statement rows and supporting schedules.
Keep each period, declared perimeter, accounting basis and source locator.
Map assets, liabilities and equity without counting subtotals and their details
twice. Distinguish a balance-only check from a full movement reconciliation of
every declared closing line. Opening, signed movements and closing must come from
independent evidence: never insert a balancing plug. A prior-period comparison
needs a separately supplied opening amount and a comparable prior closing
statement. If that comparison is unavailable, preserve and explain that limit.
Do not annualize interim periods or infer a bridge between different perimeters.
Declare which valuation inputs depend on each statement, review the `Quadrature`
worksheet and obtain the separate statement decision before method acceptance.
The helper checks sums, dates, explicit identities and current review dependencies;
the model/professional still checks completeness, classifications and substance.

## Methods and parameters

Propose and explain methods according to the mandate. The implemented calculations
are FCFF/FCFE DCF with annual or explicitly dated flows, constant or finite-duration equity income, adjusted NAV,
constant-capital mixed income, clean-surplus residual equity income, operating economic profit, holding/SOTP composition, selected EV or equity multiples, and APV composition.
Explain each selection/exclusion. The professional selects sustainable terminal
flows, capital costs, asset values, comparable samples and multiples. Keep
enterprise value and equity separate. Never deduct debt from FCFE or P/E again,
average methods, add minority discounts, or select terminal growth automatically.
For stub/monthly or mid-period DCF, use the explicit timing contract: exact dates,
ACT/365F or ACT/ACT_ISDA, effective annual or continuous rates, and an expressly
selected flat, spot or interval-forward curve. Explain the convention and preserve
the supplied period amounts; never prorate them automatically or confuse spot,
forward and par rates. Keep the annual terminal flow/rate separate from monthly
flows and horizon discounting. Read back these assumptions for professional review.
The mixed method remains annual. Crisis distributions, special rights/waterfalls,
PPA and specialist sector models are unsupported.

For finite-duration equity income, use the separate `INCOME_EQUITY_FINITE`
contract. Supply actual period income amounts, an explicit dated discount schedule
and an independently sourced equity residual at the final date, including an
explicit zero when justified. Record the source-bound `income_basis`: capacity
and capital maintenance, reinvestment, distributions and residual/double-counting
explanations. Read these assumptions back before confirming the basis and method.
Income is not automatically cash or distributable profit. Never relabel plan FCFF
as income, derive the residual from the last income, infer a perpetuity or deduct
debt again. Review the separate `Base reddituale` worksheet and the horizon factor,
which remains at period end even when incomes are placed at mid-period.

For changing common-equity capital, the distinct `RESIDUAL_INCOME_EQUITY` contract
requires independently supplied opening/closing book equity, clean-surplus income,
distributions and contributions for each exact period. Prepare and review all
accounting adjustments, including OCI or other non-owner movements, before using
those inputs. Never insert a balancing plug. Record the source-bound accounting,
owner-transaction, terminal-equity and cost-of-equity explanations in
`residual_basis`. The helper reconciles the capital roll-forward and calculates
beginning-capital charges from the same end-period discount factors. It shows the
terminal equity value less final book equity and an owner-cash-flow cross-check.
Inspect `Base residuale` and `Clean surplus` before recording method review.
Do not infer a terminal value, treat plan FCFF as income, deduct debt again or
claim that a balanced schedule establishes accounting adequacy or distributability.
Mid-period owner transactions require a separately qualified model.

For operating economic profit, use the distinct `ECONOMIC_PROFIT` contract.
Supply independently evidenced opening/closing operating capital, NOPAT and signed
net reinvestment for each exact end-period date, plus a separate terminal operating
enterprise value. Review the operating perimeter, consistent accounting adjustments,
unlevered operating taxes, complete capital movements, terminal basis and WACC in
`economic_basis`. Never invent reinvestment to balance capital or relabel plan FCFF
as NOPAT. The helper checks capital roll-forward and displays a separate FCFF
reconciliation using the same discount factors. These equalities do not establish
economic or tax adequacy. Inspect `Base profitto economico` and `Capitale operativo`
before review. The output is operating enterprise value; apply only an explicitly
supplied complete equity bridge. No terminal growth, WACC estimation or automatic
lease/tax adjustment is provided. Mid-period capital transactions need a different
qualified model and are rejected by this contract.

For a holding, use `HOLDING_SOTP` with independently valued parts and a parent-only
perimeter. Ask whether each amount is operating enterprise value, full equity or
the value of a specific right already held. Convert only enterprise values through
their own complete subsidiary bridge; apply only an explicitly supplied ownership
ratio and evidenced signed rights adjustment. Never scale an already-valued right.
Record dates, currencies, exact entity/interest identities and ownership
denominators. Review aggregate ownership and overlapping economic claims rather
than assuming distinct identifiers mean distinct assets. Explain parent assets,
liabilities, the present value of holding costs, tax effects and each signed
intragroup elimination with its actual affected inputs. Do not reuse consolidated
debt or cash, silently floor negative equity, invent a holding discount, or use
plan FCFF as a stake value. Review `Partecipazioni`, `Base holding` and
`Eliminazioni`, and read back all bases before confirming them. This composition
does not value waterfalls, authenticate ownership or qualify a legal purpose.

For a multiple, retain the initial comparable-company list in `comparables`,
including candidates excluded for missing data, negative metrics or poor fit.
Explain each decision using business, markets, growth, margins, scale, risk and
leverage. Keep LTM and forward observations distinct. Reconcile reported amounts
and signed adjustments to the supplied comparable numerator and metric; record
accounting standards, publication/price dates and the chosen lease convention.
Explain IFRS 16 effects on metric, operating value and the target debt bridge;
never derive them from a label. For EV/revenue, examine margin differences.
The helper calculates included ratios and checks explicit reconciliations; it
does not select a sample or average the applied multiple. Supply that multiple
and its rationale separately. If no peer is suitable, exclude the method with
a reason and preserve the workpaper. Review `Comparabili`, `Base multipli` and
`Raccordi multipli`, including exclusions, before recording method acceptance.
Original sources and all decisions may enter the selected model context.

For benchmarks, research official public sources with public parameter/sector/date
queries only. The mandate authorizes necessary public research; do not include
private financials or names in queries. Save permitted evidence with observation,
publication/retrieval dates, vintage, definition, geography, selection reason and
the professionally chosen maximum age. The calculation helper checks dates and
metadata without network requests; it does not authenticate publishers, assess
relevance or choose a rate. For the NYU country-risk HTML table or ECB AAA spot CSV, read
`references/benchmark-acquisition.md` and use the separate acquisition helper
from links observed on the current official page. Review reuse terms before
retaining bytes. Import its record and original table as exact evidence receipts,
bind the selected observation and review its value. Preserve unavailable or
incomplete observations explicitly; do not invent an observation date from a
release date. ECB CSV rates remain continuously compounded after percent-to-ratio
conversion. Select an exact series/date; do not substitute forward/par rates or
interpret a continuous rate as effective annual. This adapter preserves the
observation but lacks publication/vintage evidence, so automatic binding stays
ineligible. HTTP timestamps and release schedules do not fill that gap.
Other publishers and formats require their own reviewed import.
New vintages create new inputs and revisions; frozen reports remain unchanged.

## Business plan reuse

Reuse an exact finalized `business-planning` v3 artifact of the same engagement,
binding it as an upstream artifact rather than importing an arbitrary JSON file.
Import the plan's original supporting sources as exact receipts and map their IDs.
The existing compiler replays the whole plan before the valuation bridge runs.
Provide evidenced cash operating taxes per month and opening operating working
capital, and explain the operating/debt-like classification. No automatic tax
refund or use of levered tax expense. Select an existing contiguous plan horizon.
The annual bridge accepts complete calendar years after a December 31 valuation
date. The monthly bridge accepts selected whole months, including a partial year,
and requires valuation at the preceding month end, explicit opening working
capital for that date and a dated FCFF DCF with those exact monthly cash flows.
Keep a separate annual terminal-flow assumption. Never relabel a monthly amount
as annual income, prorate a month at an intramonth valuation date, pad periods or
invent forecasts. The bridge preserves upstream calculation IDs; the report and
`Piano FCFF` workbook sheet expose taxes, opening/closing stocks and reconciliation.
Without a plan, use Vera's existing business-planning workflow when forecast
preparation is required. Do not create a parallel forecast engine.

## Calculation and review

Import all sources and the finished case, prepare `business-valuation` from exact
input IDs/upstream artifact IDs, and start the run. Case source paths are relative
to that run's `inputs`, using the actual hydrated paths returned by Studio Archive.

```sh
python scripts/run_valuation.py --case <bound-case.json> --client-engagement <portable-context.json>
```

Open `valuation_report.html` and show results, limitations, source/assumption
questions and sensitivities. Use chat to obtain focused corrections and review;
the professional need not edit technical files. Cases with missing or invalid
inputs keep the affected method blocked, while other methods remain visible.
`ready_for_professional_review` means mechanical completeness only.

To record professional acceptance, read back the exact method and dependency hash,
then record the person's explicit decision, reviewer name and timezone-aware time.
Never invent acceptance because tests pass. Retain prior review records when
preparing a new case: stale dependency hashes automatically lose effect, while
unaffected method attestations survive. Every changed case is imported as a new
immutable input and run. Read back the conclusion separately before its acceptance.
The conclusion is authored and reviewed; code does not judge its economic meaning
or authenticate the reviewer. Check every narrative figure against calculation IDs.

Use the explicit `claims` register for material narrative findings. Link each to
selected sources, inputs, calculations or methods, explain the evidence basis and
limitations, and distinguish fact, assumption, hypothesis and opinion. Supply exact
numeric bindings for every material numerical statement; do not rely on matching
a number found in prose. Check the text's meaning against the sources yourself.
Read back claims separately before recording professional acceptance. Link the
conclusion through `claim_ids`, then obtain its independent review. Missing or
stale links must remain visible, including when the arithmetic still agrees.

## Delivery and privacy

Deliver the HTML, DOCX/PDF, formula XLSX, JSON and calculation CSV from the same
immutable revision. Explain the observed state and unresolved professional items.
The helper also exports the mandate, evidence, adjustments, plan binding, method
decisions, benchmark observations, calculations, sensitivity, claims, conclusion
and review as separate JSON workpapers bound to the same canonical report.
Workbook formulas recalculate when opened; exact Decimal values remain alongside
them as audit evidence. External sharing, signing, filing and sending are separate
actions requiring explicit authority. Calculation and report compilation call no
remote service. The separately selected benchmark-acquisition helper makes public
HTTPS reads to its supported NYU or ECB hosts, without sending the private case.

Business Valuation is outside Vera's comparison-report scope. Preserve source,
assumption, modeling and review evidence, including public URLs and captured
benchmark/terms documents when acquisition was used. Do not describe an incomplete acquisition as an approved parameter.
Client documents, personal/company facts, projections, benchmarks and reviewer
decisions may enter the selected Claude/Cowork model context. Local calculation
does not mean local-only model processing or automatic anonymization. The helper
creates no provider-delivery proof. Declare every physical artifact in the exact
run output and complete Studio Archive only
after review. A blocked or incomplete run is retained with its actual status.

---
name: mparanza-lipe
description: Use LIPE to reconcile Italian VAT registers and periodic settlements, prepare evidence-linked VP drafts, review tax-code mappings and payments, preserve decisions, and export an unsigned XML after external approval. Professional and importer qualification remain pending.
---

## Cowork execution contract

Select the exact files needed for this request. Folder access does not select
all its contents: if the task needs two files in a folder containing four, use
only those two. Resolve genuinely ambiguous choices with the user; reuse clear
choices without another confirmation.

Before parsing documents or creating a client, engagement or run, call
`check_studio_import_sources` with all selected paths on the actual importer
host. It needs no configured Archive and creates no records. If the MCP tool is
unavailable, use the packaged `check-import-sources --source-path <path>` CLI
through the maintained managed launcher on that same host (repeat the flag per
file). A cloud-shell `ls` is not proof of access by a computer-side importer.
Readable attachments, including `/mnt/user-data/uploads/` paths when the importer
can read them, continue directly without requiring a connected computer folder.

If files are unavailable, explain the cause immediately before creating anything:
"The file is in the chat, but the import tool looks for it on your computer."
Do not keep trying that same inaccessible path. Use this recovery sequence:

1. Inspect the host's actual callable file-transfer capabilities and the already
   connected folders. Reuse an authorized ordinary working folder outside the
   managed `Vera/engagements/.../inputs` tree. Offer **Add folder** from the **+**
   menu only when the current host offers it; otherwise explain the available
   connection method. Ask for a folder only if an accessible destination is needed.
2. With a supported bridge, copy only the selected original attachments to that
   folder as files. Compute each original SHA-256 through the host file tools.
   Do not recreate CSV text, convert encodings or line endings, relay document
   contents through model-authored tool arguments, guess a mount translation,
   overwrite a different file with the same name, or scan unrelated folders.
   A verified byte-for-byte copy may reuse its destination on retry.
3. Check the actual destination paths with `check_studio_import_sources`, passing
   `expected_sha256` as the original hashes in the same order as `source_paths`.
   The CLI takes one `--expected-sha256` per source. Archive hashes the destination
   locally and returns `ready=true` only when all supplied original hashes match.
   If no byte-preserving host transfer is available, say so and ask the user to
   save the original selected files to the accessible working folder; then verify
   them. Do not promise a bridge operation that is not callable.
4. Only after all selected sources are ready, select/create the client and
   engagement and import each through `import_studio_client_document` (CLI
   `import-document`). Pass that file's `expected_sha256` / `--expected-sha256`
   when a transfer was required. The importer checks it again during copying and
   creates the input ID and SHA receipt itself. Never manually populate `inputs`.

The path importer does not itself fetch chat attachments. Direct attachment use
requires actual importer access or a demonstrated host transfer. If neither an
importer-side check nor transfer is callable, explain the missing capability
before creating records; do not create a cloud-only replacement for a local Archive.

On any later import failure, disclose the existing `client_id` and `engagement_id`
and resume those same records. A folder-name collision calls for inspecting the
returned existing scope and reusing it when its identity matches; never clear old
folders or change the client's name just to get past the error. A deliberately
separate synthetic test may have a distinct name; retries retain their identities.
Documentless client work needs no file check. Standalone workflows check access
on their own execution host and do not require Archive or a computer folder when
that engine can read the inputs.

Public workflow names select skills; component IDs select module paths.
`financial-report-builder` uses component `report-builder`, `vouching` (historically
called Check Entries) uses `check-entries`, and `purchase-invoice-review` uses
`passive-invoice-audit`. These component IDs are not additional workflows.

For journal-sampling, open-item-reconciliation, journal-bank-reconciliation,
concordato-plan-review, financial-report-builder and vouching only, optional cache
cleanup uses the corresponding component ID from the installed Vera root:

```bash
python3 modules/<module>/scripts/implementation_bootstrap.py --repair
```

For a standalone module, use `python3 scripts/implementation_bootstrap.py --repair`
from its root. This validates the implementation first, then removes only regular,
single-link `__pycache__/*.pyc` files under that module's own `vendor` tree. It
leaves directories, other files, symlinks and shared vendor trees untouched.
This supported maintenance command is the only cache-cleanup exception to the
prohibition on editing the installed tree by hand. It is optional: ordinary
validation and execution tolerate incidental bytecode without removing it.
On a read-only installation, skip cleanup. If the command reports a permission
error, retain that error and continue the ordinary validated workflow when its
checks pass; do not chmod, delete files manually, copy or patch the installation,
or bypass the host's permissions to make cleanup succeed.
If `validate_implementation_tree` ever fails with a file/directory-contract
mismatch, do not delete or modify files inside the installed plugin tree by hand
and do not bypass a sandbox/permission rejection to do so. Stop and report the
exact error instead.

Work from the connected folder and supplied files first. Before a module's Python
helpers, locate the installed plugin root. When it contains `components.json` and
`scripts/managed_python_runtime.py` (as Vera does), run from that root:

```bash
python3 scripts/check_dependencies.py --module <module>
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

If the enclosing plugin does not ship this managed launcher, use the module's
dependency checker and only already-installed dependencies; do not assume that a
standalone module script provisions them.

The managed launcher provisions and reuses one user-scoped CPython 3.12
environment per OS host with the published, hash-checked dependency locks, outside client
folders. Modules and products share this dependency environment; it does not
isolate client matters. This declared dependency setup is authorized as
part of running the workflow; never install arbitrary packages or use ambient
Python for subsequent module helpers. Repeat any declared `--requirements` options
on both commands. Missing ambient imports are a reason to run this setup, not to
abandon the calculation. If setup fails, report its exact error and do not replace
the required calculation with an invented result. Optional OCR setup still needs
separate approval. If setup reports `Host not in allowlist` for PyPI, explain that
Claude Settings > Capabilities > Allow network egress is disabled or restricted.
Ask the user or organization administrator to authorize package-registry access;
never change network permissions silently or work around the restriction. Retry
the same managed setup after access is approved, in a new session if needed.

MCP tools, browser or computer control, and local review servers are optional
enhancements, never completion gates. Cloud Cowork sessions may not expose local
plugin MCP servers even when the plugin is installed; use the packaged Python
workflow through the managed launcher in that case. Do not equate missing MCP
registration with a failed calculation engine. When an optional capability is
unavailable, continue with Markdown and file-based review and state the limitation.

The normal Cowork deliverable is a reviewable draft, artifact card, and
source/review files. A callable persistence interface may optionally record or
apply reviewer actions, but its absence never blocks delivery. Never claim
`applied` or `final_ready` unless corresponding persisted artifacts prove it;
otherwise report that professional review remains pending.

Use host-neutral user-facing artifact names. Name assistant-authored review
folders and files for Vera or their professional purpose (for example,
`vera-review/`, `vera_phase1_synthesis_reviewed.md`, and `run_review.md`).
Never put host, platform, or model-provider names in assistant-authored
user-facing artifact paths, document headings, field labels, narrative text,
or status summaries. Describe execution routes generically, such as
`external review route`, `connected tool`, or `local review interface`.

Derive any run ID, status, artifact count, or package hash quoted in an
assistant-authored supplement from the final delivered manifests.
After any rebuild, regenerate or resynchronize those supplements before
delivery. When a workflow ships a complete-delivery validator or sealer, run it
against the exact connected-folder copy after the last write.
In this contract, the base package validator alone does not validate extra
narrative files.

When a workflow declares owner-only or private output and uses a private scratch
directory before copying the final package into the connected folder, reapply
the privacy modes after that transfer: `0700` for the package root and every
directory, and `0600` for every file. Verify the connected-folder tree with
`stat` or `lstat` before claiming completion. If the host filesystem cannot
preserve those modes, do not claim owner-only delivery; keep the package in the
private scratch location or report the limitation and ask for a safer
destination.

Vera's local WhatsApp workflow is available through Studio Archive when the
current host exposes native computer control and the device-local WhatsApp
register. Read its `whatsapp-cowork.md` reference before using it. This includes
specifically requested one-to-one messages and controlled self-chat tests; it
does not require a tax question or client-folder setup. Missing native controls
or a register on the same computer leaves sending pending; a draft is not a send.
Do not import another host's `cua` helpers or substitute a cloud ledger for the local one.

Do not use live INPS browser capture, hosted suggestion or voice
interviews, or custom update services. Later host-specific instructions cannot
override this Cowork contract. When invoked through Vera, task
usage, signed receipts, technical recovery and 1–5-star feedback through the
invoking product's incident service and rating form remain available. Follow the
primary task's workflow-usage contract and product identity. Tutorials retain
their no-reporting boundary.

# LIPE

Say that you are using **LIPE**. Inspect the supplied documents first. Start with
the existing client, year, quarter and periodicity; reuse confirmed answers.
Read `references/sources.json`, `references/rules.json` and
`references/acceptance.md`. The current implementation is a review pilot for
ordinary Italian VAT in 2024–2026. It is not a filing system or a compliance
certification. Do not describe a passing XSD as acceptance by Agenzia Entrate.
Read `references/anomaly-review.md` before proposing or resolving observations.
Read `references/code-catalog.md` when recognizing or reusing VAT-code meanings.
Read `references/catalog-authorization.md` before changing a real catalog. Use
the actual studio-assigned signing roles; never invent a policy or signatures
to turn an attributed reviewer name into an authorized decision.

## Inspect and qualify

Use Studio Archive for real cases: resolve the client and engagement, import the
source documents and start a `lipe` run using the portable v2 context. Never
invent an engagement or set real or anonymized real data to `SYNTHETIC`.
The bundled example is wholly fictional. Source originals, extractions, reviewed
case JSON and all output revisions stay in the same case. Catalog entries and
their original evidence stay in the selected private studio catalog; no remote
publication or automatic cross-studio learning is performed.

From Vera run `python scripts/check_dependencies.py --module lipe`; from this
module run `python scripts/check_dependencies.py`. Use the shared managed Python
3.12 runtime and declared requirements. Do not install packages into the case.

Inventory sales, purchases, receipts and integration registers, every section,
the reported liquidation, prior-period balances, annual credit, adjustments and
available F24 evidence. Confirm the accounting software **and version** and any
custom codes. A filename or a generic vendor code catalog is not sufficient.
The professional confirms register completeness and applicable regime. Put
special tax regimes, group/mixed accounting, extraordinary transactions,
subcontracting, foreign or cross-year timing, unresolved rate/deduction issues
and other unsupported features in `unsupported_features`; these block a VP draft.
`QUARTERLY_SPECIAL` denotes periodicity without the 1% option interest; it does
not authorize a special VAT determination method.

## Extract with evidence

```bash
python scripts/lipe.py extract --source /absolute/run/inputs/register.pdf --output /absolute/run/inputs/extractions
```

The helper preserves source bytes, SHA-256 and page text. It does **not** recognize
VAT tables, certify reading order or run OCR. Read the original pages visually
alongside the text. Blank or unreadable pages need a readable source or the
existing explicitly approved OCR route; never treat them as zero. Preserve any
OCR derivative and original separately, including the extraction provenance.

Use the current host model to propose `schemas/case.schema.json`. For each row,
record its source, page, exact quotation, printed base and VAT, deduction amount,
and distinct registration, chargeability and deduction periods. Review line
signs, credit notes, grouped totals, repeated page headings and cumulative
totals. Do not combine detail rows and their subtotal as additional operations.
Whole documents may be necessary; do not assert that only totals reach the model.

The base of a purchase stays in its registration period (VP3); exercising its
deduction in another period changes VP5 only. A vendor's “data IVA” label does
not establish legal entitlement or the relevant period. Qualify those facts
against the current official instructions and actual receipt/registration dates.
Keep all periods within the selected year and periodicity; cross-year cases are
outside this pilot. Include boundary-period registers where needed and explain
the allocation in the row review.

## Confirm mappings and decisions

Propose each `(side, code)` meaning with a reason. The case's software, version,
client and engagement bound its mappings. Use `PROPOSED` until the professional
actually confirms; never manufacture `CONFIRMED` to enable a calculation.
Before that confirmation, record the first-pass population following
`references/code-measurements.md`. Preserve unsuccessful recognition and unknown
codes as well as proposals; do not retrospectively label a reviewed case as a
first pass. The measurement ledger never supplies approval or changes a mapping.
Consult the selected catalog in client, studio, then central-reference order.
Preserve exact revisions and case applicability following the catalog guide;
pass `--catalog` when calculating a bound case. Do not remove a binding or switch
to a manual mapping just to evade a revocation, confidence block or dispute.
`SALE_NO_OUTPUT_VAT` needs an explicit reason (for example reviewed exempt,
non-taxable or split-payment treatment). `PURCHASE` always uses the explicitly
reviewed `deductible_tax`; it never assumes full deductibility. Reverse charge
adds tax to VP4 and only the reviewed deductible amount to VP5. Sales integration
mirrors contribute nothing a second time and must link to matching purchase rows.

Do not infer exclusion from “other”, “outside scope” or a person’s name. Unknown
codes block calculation. Tax interpretation and anomalies such as incorrect
vendor coding, duplicate import/reverse-charge treatment or closing entries are
model proposals for professional review; matching numbers do not prove a cause.

Prior-period credit and deferred small debt require reviewed evidence, including
a verified zero. Missing balances remain null. For each period explicitly review
VP9–11/13, any credit withheld from carry, payment principal and whether an
eligible small debit was paid or deferred. Payment comparison excludes penalties
and interest on late payment and does not diagnose omission or compute remedies.
Quarterly-by-option small-debt carry is blocked pending qualification of the
principal/interest carry basis. November/December and Q3/Q4 never automatically
carry a small debit into a forbidden next-period VP7.

## Calculate and review

Import the completed case JSON into the engagement and include its input ID,
along with the evidence input IDs, when preparing the LIPE run. Start the run
and find the case JSON entry in `context.input_bindings` by matching its
`binding_id` to the imported case input ID. Pass that entry's exact `path` as
`--case` and the started run's `context_path` as `--client-engagement`:

```bash
python scripts/lipe.py calculate --case "$case_binding_path" --client-engagement "$run_context_path"
```

If calculation exits with code `2`, check the run's output for a saved
`result.json` and report its `status` and `blockers` when present.

For the bundled synthetic example only:

```bash
python scripts/lipe.py calculate --case examples/synthetic-case.json --source-root examples --output /absolute/synthetic/output
```

The engine reconciles source totals and performs exact Decimal arithmetic. It
requires three monthly modules or one quarterly module, in order. Quarterly by
option uses 1% in Q1–3; Q4 uses XML period 5 and leaves VP11, VP12 and VP14 blank.
It preserves blocked results and each content-bound revision in a new folder.
Never overwrite earlier evidence or approvals. Rerun from new evidence when
something changes; the case, rules and engine hashes identify the revision.

Open `workpaper.md`, show the VP table, findings and unresolved requirements,
and make the row composition in `result.json` available. Explain each difference
against the customer's liquidation; it does not replace the register source.
Supply `liquidations` for every period using case contract 1.3. Each sales or
purchase section explicitly declares its taxable-base basis (registration,
chargeability or deduction) and VAT basis (recorded, output or deductible).
Confirm that meaning against the actual print; do not choose a basis merely to
make a difference disappear. Missing lines remain absent, not assumed zero.
The comparison never changes the VP3 registration basis or a reviewed deduction.

Open `workpaper.xlsx`: its three tabs are Riconciliazione, VP and F24. Inspect
per-code discrepancies and source references, the visible VP formulas and their
comparison to the saved engine result, and payment differences. Draft a supported
explanation for each discrepancy from the source evidence; do not infer closing
entries, lateness, omissions or remedies from a numeric difference alone. The
workbook uses standard numeric cells; separators follow the spreadsheet viewer's
locale. It is an inspectable draft, not an approval or a replacement case file.
Change evidence/decisions in the case and rerun to produce a new revision. Never
treat a manually edited workbook as the approved result.
Record supported semantic proposals in `observations`, with invoice/protocol
references, source quotations, proposed VP6 effects (null when unknown), actions
and links to the exact comparison/finding identifiers. Follow the review guide
for `anomaly_review`, professional decisions and their current content bindings.
Open or stale decisions block VP output. A proposed effect never changes the
arithmetic automatically: amend the reviewed inputs and recalculate.

Inspect the generated `anomalies.md`/JSON dossier, `summary.pdf` and per-client
`review-request.md`. The draft preserves unknown recipients, facts and deadlines;
provide `correspondence` with source-backed dates only. Review the rendered PDF,
figures and letter before delivery. Do not send correspondence without an explicit
user request. The named reviewer is an attributed local record, not an
authenticated identity or a tax approval issued by Vera.

## Confirm the exact proposal

Follow `references/approval.md`: show the current figures, front page, sources,
anomalies and choices, then ask whether the user agrees to export this version.
Record only that actual response, actor, confirmation reference and time. Reuse
an existing response only for unchanged reviewed content. No professional role,
certificate, signature, mandate or authority policy is required for this decision.
The real case remains in its existing Archive run and preserves its evidence.

## XML export and qualification

`xml-test` recalculates a **synthetic** case, uses fictional identifiers and
requires the bundled official XSD with the complete W3C signature schema:

```bash
python scripts/lipe.py xml-test --case examples/synthetic-case.json --source-root examples --output /absolute/synthetic/xml
```

For an approved case, follow `references/xml-export.md`. Use the studio's one configured filename registry (`VERA_LIPE_EXPORT_REGISTRY`). Obtain the intermediary's
confirmed unused progressive; do not guess the history of filenames generated
outside this registry or create a fresh registry to bypass a collision. Export
re-verifies the actual user confirmation, current sources, any retained disclosure,
catalog and artifacts, then reads the generated XML back against the approved VP.

The delivered XML is unsigned and is not transmitted. No real studio, importer
or Agenzia control-software acceptance is established by development tests.
Keep the actual outstanding acceptance register visible; do not invent identity,
test real filing by transmission, or substitute real identifiers in `xml-test`.
If a transmitted XML is supplied, use the comparison command and retain all
metadata, period and amount differences. Equal VP values do not approve changed
front-page data or flags and do not authenticate the supplied file.

## Inspect a supplied receipt

Follow `references/receipts.md` when the professional supplies a receipt. Preserve
the original, read its official XML structure and declared outcome, and optionally
compare its filename to a supplied transmitted file. The helper does not verify
XAdES authenticity, connect receipt bytes to transmitted bytes, compare VP figures
or query a tax portal. An ES01, a successful command or an XSD pass must never be
reported as verified filing acceptance. Keep ES02 warnings and ES03 rejection
visible; interpretation and follow-up require professional review.

## Delivery and privacy

LIPE is outside Vera's selective comparison-report scope. Preserve extraction,
mapping, review and narrative evidence without requiring a privacy report for
review, export or Archive completion. `local_processing_receipt.json` cannot
measure host model exposure and explicitly leaves it unknown. Declare every
output revision as a Studio Archive artifact. An existing report, when supplied,
remains bound to its exact run and must still validate.

Current user restrictions govern any optional external attestation or publishing.

## Cowork-native Run UX

Default output policy: the Markdown and Excel workpapers, PDF summary, anomaly dossier,
unsent colleague draft, VP table, findings and readable model-data
report are normal outputs. Prepare `run_review.md` beside them with actual
checks, unresolved questions and output paths.
Never write run outputs inside this Git workspace or a published directory.
The local deterministic scripts
verify evidence integrity and arithmetic; the model proposes interpretations and
the professional reviews them. Continue ordinary authorized work without extra
approval. Reserve explicit approval for external, destructive, approval-sensitive
or material steps outside the authorized scope and unresolved material choices.

## Quali dati arrivano al modello

The selected Claude or Cowork model may read complete register pages, customer and
counterparty identifiers, invoice and registration dates, tax codes, bases, VAT,
liquidations, F24 excerpts, proposals, professional decisions and workpapers.
Catalog classes, confidence, scope identifiers, quotations and attributed review
history may also enter context. An explicitly requested catalog history can
include other authorized studio entries; do not load it indiscriminately for a
single client. The selected catalog retains original evidence bytes locally.
Local helpers hash and read the selected sources, check quotations and arithmetic,
and write case artifacts; they make no model or network call. Public source
research uses non-identifying queries. No automatic anonymization, local-only
model processing, remote central code sharing or legal compliance certification is
provided. Keep the actual session disclosure distinct from these design limits.
Supplied receipts and transmitted files can expose filenames, identifiers,
timestamps, notes, errors, front-page fields and VP amounts. Record their actual
inspection in the same session disclosure. A local receipt parser makes no
network or model requests and cannot measure what the host has read.

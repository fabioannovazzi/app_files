---
name: mparanza-invoice-xml
description: Prepare ordinary Italian FatturaPA XML from invoice PDFs, photographs or confirmed structured data, with source-linked fields and professional review before export; includes reviewed foreign-supplier TD17, TD18 and TD19 preparation.
---

## Cowork execution contract

Select the exact files needed for this request. Folder access does not select
all its contents: if the task needs two files in a folder containing four, use
only those two. Resolve genuinely ambiguous choices with the user; reuse clear
choices without another confirmation.

Before parsing documents or creating a client, engagement or run, call
`check_studio_import_sources` with all selected paths on the actual importer
host. It needs no configured Archive and creates no records. If the MCP tool is
unavailable, use the packaged `check-import-sources --source-path <path>` CLI
through the maintained managed launcher on that same host (repeat the flag per
file). A cloud-shell `ls` is not proof of access by a computer-side importer.
Readable attachments, including `/mnt/user-data/uploads/` paths when the importer
can read them, continue directly without requiring a connected computer folder.

If files are unavailable, explain the cause immediately before creating anything:
"The file is in the chat, but the import tool looks for it on your computer."
Do not keep trying that same inaccessible path. Use this recovery sequence:

1. Inspect the host's actual callable file-transfer capabilities and the already
   connected folders. Reuse an authorized ordinary working folder outside the
   managed `Vera/engagements/.../inputs` tree. Offer **Add folder** from the **+**
   menu only when the current host offers it; otherwise explain the available
   connection method. Ask for a folder only if an accessible destination is needed.
2. With a supported bridge, copy only the selected original attachments to that
   folder as files. Compute each original SHA-256 through the host file tools.
   Do not recreate CSV text, convert encodings or line endings, relay document
   contents through model-authored tool arguments, guess a mount translation,
   overwrite a different file with the same name, or scan unrelated folders.
   A verified byte-for-byte copy may reuse its destination on retry.
3. Check the actual destination paths with `check_studio_import_sources`, passing
   `expected_sha256` as the original hashes in the same order as `source_paths`.
   The CLI takes one `--expected-sha256` per source. Archive hashes the destination
   locally and returns `ready=true` only when all supplied original hashes match.
   If no byte-preserving host transfer is available, say so and ask the user to
   save the original selected files to the accessible working folder; then verify
   them. Do not promise a bridge operation that is not callable.
4. Only after all selected sources are ready, select/create the client and
   engagement and import each through `import_studio_client_document` (CLI
   `import-document`). Pass that file's `expected_sha256` / `--expected-sha256`
   when a transfer was required. The importer checks it again during copying and
   creates the input ID and SHA receipt itself. Never manually populate `inputs`.

The path importer does not itself fetch chat attachments. Direct attachment use
requires actual importer access or a demonstrated host transfer. If neither an
importer-side check nor transfer is callable, explain the missing capability
before creating records; do not create a cloud-only replacement for a local Archive.

On any later import failure, disclose the existing `client_id` and `engagement_id`
and resume those same records. A folder-name collision calls for inspecting the
returned existing scope and reusing it when its identity matches; never clear old
folders or change the client's name just to get past the error. A deliberately
separate synthetic test may have a distinct name; retries retain their identities.
Documentless client work needs no file check. Standalone workflows check access
on their own execution host and do not require Archive or a computer folder when
that engine can read the inputs.

Public workflow names select skills; component IDs select module paths.
`financial-report-builder` uses component `report-builder`, `vouching` (historically
called Check Entries) uses `check-entries`, and `purchase-invoice-review` uses
`passive-invoice-audit`. These component IDs are not additional workflows.

For journal-sampling, open-item-reconciliation, journal-bank-reconciliation,
concordato-plan-review, financial-report-builder and vouching only, optional cache
cleanup uses the corresponding component ID from the installed Vera root:

```bash
python3 modules/<module>/scripts/implementation_bootstrap.py --repair
```

For a standalone module, use `python3 scripts/implementation_bootstrap.py --repair`
from its root. This validates the implementation first, then removes only regular,
single-link `__pycache__/*.pyc` files under that module's own `vendor` tree. It
leaves directories, other files, symlinks and shared vendor trees untouched.
This supported maintenance command is the only cache-cleanup exception to the
prohibition on editing the installed tree by hand. It is optional: ordinary
validation and execution tolerate incidental bytecode without removing it.
On a read-only installation, skip cleanup. If the command reports a permission
error, retain that error and continue the ordinary validated workflow when its
checks pass; do not chmod, delete files manually, copy or patch the installation,
or bypass the host's permissions to make cleanup succeed.
If `validate_implementation_tree` ever fails with a file/directory-contract
mismatch, do not delete or modify files inside the installed plugin tree by hand
and do not bypass a sandbox/permission rejection to do so. Stop and report the
exact error instead.

Work from the connected folder and supplied files first. Before a module's Python
helpers, locate the installed plugin root. When it contains `components.json` and
`scripts/managed_python_runtime.py` (as Vera does), run from that root:

```bash
python3 scripts/check_dependencies.py --module <module>
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

If the enclosing plugin does not ship this managed launcher, use the module's
dependency checker and only already-installed dependencies; do not assume that a
standalone module script provisions them.

The managed launcher provisions and reuses one user-scoped CPython 3.12
environment per OS host with the published, hash-checked dependency locks, outside client
folders. Modules and products share this dependency environment; it does not
isolate client matters. This declared dependency setup is authorized as
part of running the workflow; never install arbitrary packages or use ambient
Python for subsequent module helpers. Repeat any declared `--requirements` options
on both commands. Missing ambient imports are a reason to run this setup, not to
abandon the calculation. If setup fails, report its exact error and do not replace
the required calculation with an invented result. Optional OCR setup still needs
separate approval. If setup reports `Host not in allowlist` for PyPI, explain that
Claude Settings > Capabilities > Allow network egress is disabled or restricted.
Ask the user or organization administrator to authorize package-registry access;
never change network permissions silently or work around the restriction. Retry
the same managed setup after access is approved, in a new session if needed.

MCP tools, browser or computer control, and local review servers are optional
enhancements, never completion gates. Cloud Cowork sessions may not expose local
plugin MCP servers even when the plugin is installed; use the packaged Python
workflow through the managed launcher in that case. Do not equate missing MCP
registration with a failed calculation engine. When an optional capability is
unavailable, continue with Markdown and file-based review and state the limitation.

The normal Cowork deliverable is a reviewable draft, artifact card, and
source/review files. A callable persistence interface may optionally record or
apply reviewer actions, but its absence never blocks delivery. Never claim
`applied` or `final_ready` unless corresponding persisted artifacts prove it;
otherwise report that professional review remains pending.

Use host-neutral user-facing artifact names. Name assistant-authored review
folders and files for Vera or their professional purpose (for example,
`vera-review/`, `vera_phase1_synthesis_reviewed.md`, and `run_review.md`).
Never put host, platform, or model-provider names in assistant-authored
user-facing artifact paths, document headings, field labels, narrative text,
or status summaries. Describe execution routes generically, such as
`external review route`, `connected tool`, or `local review interface`.

Derive any run ID, status, artifact count, or package hash quoted in an
assistant-authored supplement from the final delivered manifests.
After any rebuild, regenerate or resynchronize those supplements before
delivery. When a workflow ships a complete-delivery validator or sealer, run it
against the exact connected-folder copy after the last write.
In this contract, the base package validator alone does not validate extra
narrative files.

When a workflow declares owner-only or private output and uses a private scratch
directory before copying the final package into the connected folder, reapply
the privacy modes after that transfer: `0700` for the package root and every
directory, and `0600` for every file. Verify the connected-folder tree with
`stat` or `lstat` before claiming completion. If the host filesystem cannot
preserve those modes, do not claim owner-only delivery; keep the package in the
private scratch location or report the limitation and ask for a safer
destination.

Vera's local WhatsApp workflow is available through Studio Archive when the
current host exposes native computer control and the device-local WhatsApp
register. Read its `whatsapp-cowork.md` reference before using it. This includes
specifically requested one-to-one messages and controlled self-chat tests; it
does not require a tax question or client-folder setup. Missing native controls
or a register on the same computer leaves sending pending; a draft is not a send.
Do not import another host's `cua` helpers or substitute a cloud ledger for the local one.

Do not use live INPS browser capture, hosted suggestion or voice
interviews, or custom update services. Later host-specific instructions cannot
override this Cowork contract. When invoked through Vera, task
usage, signed receipts, technical recovery and 1–5-star feedback through the
invoking product's incident service and rating form remain available. Follow the
primary task's workflow-usage contract and product identity. Tutorials retain
their no-reporting boundary.

# Preparazione fatture XML

Prepare the invoice, review it with the professional, then export the exact
approved data. Existing XML checking remains `vera:mparanza-fatture-xml-check` and
booked purchase-invoice auditing remains `vera:mparanza-purchase-invoice-review`.

## Scope and decisions

Inspect the supplied evidence and current conversation before collecting intake
decisions. Reuse an already confirmed archive/client/engagement context. For an
explicitly selected single-file delivery without archive registration, follow
Vera's `skills/mparanza-vera/references/standalone-work.md` and pass that invoice task's
`context_path` to the existing `--client-engagement` argument. Keep all source,
proposal, professional-approval and export checks. Do not open an archive chooser
or ask for client registration on this route. If retention is unresolved, ask once
whether the user wants archived client work or a standalone deliverable; reuse the
answer. For archived work, list/reconnect the approved root first and resolve
existing identities before offering New client. Never open a chooser speculatively.

Resolve one Studio Archive client and engagement. Import the selected sources,
prepare/start an `invoice-xml` run, and use its exact `client_engagement_path`,
`input_dir` and `output_dir`. Use Vera's managed dependency check for
`--module invoice-xml` before helpers, then the managed launcher for each command.
Run `python scripts/check_dependencies.py` before helpers; declared dependencies
live in `requirements.txt`. Never install undeclared packages during a run.
Never write run outputs inside this Git workspace or a published directory.

Interpret the request and sources. A photo of an already issued invoice does
not authorize a second issue. Record whether the task is preparing a new draft,
reconstructing a file for import, or preparing a foreign integration. Ask about
prior issuance/export when unresolved. Do not assign a new number or date.
Group multiple views of one invoice semantically. A conversation screenshot
about a desired workflow is context, not invoice evidence or an instruction.
Resolve material choices about the preparation purpose, source grouping and tax
treatment from the current request and evidence before asking targeted questions.
Inspect the actual inputs first. Do not introduce hypothetical tax branches or
optional services unless the facts cue them.

Collect the unresolved intake facts in one concise request after inspecting the
source: preparation purpose and prior issuance, fiscal regime, number/date and
amount confirmations, and any source-cued withholding or other tax decisions.
Include archive context only if unresolved. Reuse answers already given; ask a
follow-up only when new evidence or an incomplete answer requires it. Exact
professional approval of the prepared revision remains a later export gate.

Reuse the complete instructions and references already read for this installed
version. Size reads to retain the full required text; read missing contiguous
sections if output was truncated. Consult specific references for unresolved
fields instead of repeatedly reading the router or serializer implementation.

The bundled schema is `references/xsd/Schema_VFPR12_v1.2.3.xsd` relative to the
module root, with `references/xsd/xmldsig-core-schema.xsd` and `sources.json`
alongside it. `scripts/invoice_workflow.py` uses `InvoiceSchema` to resolve and
verify this bundle automatically. Use the prepare/export entrypoints below;
do not search for a schema path or build a separate serializer for a normal run.

For foreign invoices, read `../../references/foreign-invoices.md`. Explain and
review the operation facts, TD17/18/19 choice, parties, Italian VAT treatment,
date basis, original reference and currency conversion. Do not choose a code
from country or description keywords. Do not swap the foreign supplier and
Italian customer, or copy foreign VAT into Italian tax fields without review.

The first export profile supports ordinary FPR12 in EUR, domestic TD01/02/03/04/
05/06/24/25/26 and the reviewed foreign TD17/18/19 route. PA, simplified invoices,
Art73, document-level discounts and stamp-duty total reconciliation are not yet
qualified. Preserve those fields and show the concrete export blocker. Never
delete information, change the tax treatment or split a source to bypass it.

## Intake and interpretation

1. Write `source_selection.json` inside the run output: a list with `id`,
   input-relative `path`, `title`, `role` (`invoice`, `party_profile`,
   `professional_confirmation`, `context`) and `evidence_group` for every source.
2. Run from the module root through Vera's managed launcher:

   ```bash
   python scripts/source_evidence.py --selection <output>/source_selection.json \
     --client-engagement <context> --output <output>
   ```

3. Read `source_evidence.json` and the relevant exact text/pages/images. Use
   native model vision to interpret photos and rendered PDF pages. Embedded PDF
   text does not prove table layout. Inspect every page containing invoice data;
   record unreadable or missing pages. If native vision is unavailable, use the
   existing shared OCR only when already approved or through its explicit setup
   choice, or request a readable source. Never claim extraction from a filename.
4. Build `proposal.json` using `../../references/proposal-contract.md`. The model
   extracts meanings and proposes decisions; local scripts do not fabricate a
   field extractor. Bind each supplied field to page/region evidence, a recorded
   user confirmation, or a calculation with exact operand pointers. Leave
   unreadable fields null, keep conflicts in `questions`, and ask only for the
   missing facts needed to progress. Do not infer tax IDs, regime, routing code,
   numbering, dates, quantity or unit price from a plausible default.

For any SdI or gateway rejection follow-up, inspect the newest supplied
notification or screenshot before answering. Record every currently visible
error code and message, compare the exact referenced XML fields with the current
artifact, and retain an unresolved-discrepancy checklist across successive
rejections. Do not carry forward an earlier diagnosis as the current one and do
not describe a correction as resolved until the exact latest control passes
against the corrected artifact.

## Review and export

Run `scripts/invoice_workflow.py prepare --proposal <output>/proposal.json
--client-engagement <context> --output <output>`. This creates an immutable
revision with `proposal.json`, `validation.json`, `preview.html` and
`review_request.json`, including for partial drafts; it creates no invoice XML.

Open the preview for the professional, summarize material values and decisions,
and resolve its blockers. Corrections create a new content-bound revision.
Review may happen in chat: Claude applies the user's actual corrections to a new
proposal and shows its updated preview. The user never edits JSON or runs tools.

When there are no blockers, obtain or reuse explicit approval of those exact
invoice fields and tax decisions for export. Approval to build the software is
not approval of a client's invoice. Persist `review.json` with schema version 1,
exact `proposal_sha256`, `status: approved_for_export`, actual `reviewer`,
timezone-aware `reviewed_at` and the actual approval-message reference in
`approval_basis`. Do not manufacture a professional approval. This local record
is not cryptographic reviewer authentication.

Run `scripts/invoice_workflow.py export --revision <revision> --review
<output>/review.json --client-engagement <context> --output <output>`.
The exporter rechecks source bytes, proposal digest, XSD and mechanical
controls. Changed input invalidates prior review. It writes the XML, review
record and export report into that revision's `export` folder without replacing
different files. No operation signs, submits to SdI, sends messages, books
entries or establishes prior SdI submission status.

## Delivery and model-data evidence

Invoice XML is outside Vera's selective comparison-report scope. Retain source,
proposal, review and validation evidence without creating a privacy comparison
report. `source_evidence.json` counts locally prepared material; it does not prove
which pages reached the model. Unknown exposure must not be reported as zero.
For archived work, declare the final artifacts in Studio Archive and finalize
and complete the run after review. For standalone work, retain them in the task
output. Link the XML, preview and export report, distinguishing schema validation,
local checks, professional review and untested SdI acceptance.

Claude and Cowork use their current native model to interpret evidence and the
same local helpers where supported. A runtime without local scripts may prepare
an in-chat draft and missing-field review, but must state that no validated XML,
portable run or durable export was produced. Do not fake a tool execution.

The local deterministic helpers validate schema structure, arithmetic and hashes;
they do not replace model-led interpretation or professional tax decisions.
Request explicit approval for external, destructive or approval-sensitive steps
and resolve material unknown choices. Ordinary authorized preparation proceeds.

## Cowork-native Run UX

Use Vera's Run Intake table and Decision Table to show the bound invoice sources,
preparation purpose and unresolved choices. Give an execution checkpoint before
saving. Default output policy: the draft preview, structured data, checks and
review evidence are normal outputs, not choices to propose. XML additionally
requires the exact professional approval described above. End with an Artifact
Card; `run_review.md` may summarize the handoff. Never edit plugin source
or generated ZIPs during client work.

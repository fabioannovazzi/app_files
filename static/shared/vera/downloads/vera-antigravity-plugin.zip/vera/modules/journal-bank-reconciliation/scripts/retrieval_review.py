"""Bounded evidence-request orchestration inside the existing isolated worker contract."""

from __future__ import annotations

import copy
import hashlib
import json
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Mapping

import bank_first as bf
from evidence_retrieval import (
    DEFAULT_BUDGET,
    EvidenceIndex,
    RetrievalLimit,
    query_schema,
)

__all__ = ["run_review", "replay_result", "extend_schema"]
PROTOCOL = "vera.retrieval.v1"
# Owned 0.1.625 implementation, supported for evidence replay only. Never launch it.
LEGACY_IMPLEMENTATION = (
    "fc9378ac0488ab133bf470d32f0b5242b55c6f7187e0170c97a4e6bec9255f1b"
)
# Owned 0.1.627 checkpoint implementation; UTF-8 persistence preserves its protocol.
UTF8_PREDECESSOR = "6f5e92fba434fe34a5cdb7d241c26d8f3de73ff29b3acdc1d70d496820948f3a"
# Keep shipped checkpoints and both local recovery builds replayable.
FULL_HISTORY_PREDECESSOR = (
    "b7d1e9cd267729ab661bfe19c12aa3fd4ebd658d607fff4c40633cfbb78e240f"
)
# Pre-residual-pass source digest: replay only; new runs use evidence version 3.
RESIDUAL_PREDECESSOR = (
    "a7a58410adad9e6d1008b14bf398511bc3c63ba06e0bdfa3167ef5c2250eda95"
)
REPLAY_IMPLEMENTATIONS = (
    RESIDUAL_PREDECESSOR,
    "af2bf55103a93775ee563948f177f3777087c8ee71d02b8d47de656ed54fffe1",
    LEGACY_IMPLEMENTATION,
    UTF8_PREDECESSOR,
    FULL_HISTORY_PREDECESSOR,
    "94fb8ac0be8d6908415dd599a49bea49e364e7119767ad617e6d59bc8c9886b0",
    "543a42bfd1a09fd406c1a6dec6bc226e6395c541aac152bece0b6658925ae72c",
    "4d7a71e0ca88b8e81d544d9481991134941898c1f4df16b4148ec1d3ea715d3a",
)
PACKET_PROJECTION = bf.LOCAL_FIRST_PROJECTION
RETRY_FOCUS_GROUPS = 5


def extend_schema(schema: dict) -> dict:
    schema = copy.deepcopy(schema)
    p = schema["properties"]
    p["groups"]["minItems"] = 0
    p["evidence_requests"] = {"type": "array", "maxItems": 4, "items": query_schema()}
    p["retain"] = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            s: {"type": "array", "maxItems": 64, "items": {"type": "string"}}
            for s in ("bank", "journal")
        },
        "required": ["bank", "journal"],
    }
    p["working_note"] = {"type": "string", "maxLength": 2400}
    schema["required"] += ["evidence_requests", "retain", "working_note"]
    return schema


def _search_notes(pages):
    """Keep query/coverage metadata, never duplicate retrieved source rows."""
    return [
        {
            k: page[k]
            for k in (
                "query",
                "total_candidates",
                "returned",
                "remaining_unread",
                "next_cursor",
            )
        }
        for page in pages
    ]


def _initial(index, focus, groups):
    bank_ids = {i for f in focus for i in f["bank_ids"]}
    prior = [g for g in groups if bank_ids.intersection(g["bank_ids"])]
    anchors = {
        "bank": sorted(bank_ids),
        "journal": sorted({i for g in prior for i in g["journal_ids"]}),
    }
    queries = []
    # Exact identifiers and amounts are starting leads, never semantic decisions.
    for row in index.get("bank", anchors["bank"])[:4]:
        if row.get("reference"):
            queries.append(
                {"side": "journal", "field": "reference", "value": row["reference"]}
            )
        else:
            queries.append(
                {
                    "side": "journal",
                    "amount_min": row["amount_signed"],
                    "amount_max": row["amount_signed"],
                }
            )
    unique = {bf.digest(q): q for q in queries}
    pages = [index.search(q) for q in unique.values()]
    return {
        "anchors": anchors,
        "pages": pages,
        "retain": {"bank": [], "journal": []},
        "working_note": "",
        "recent_searches": _search_notes(pages),
        "search_count": len(pages),
        "round": 0,
        "parent": None,
    }


def _packet(
    index,
    session,
    focus,
    groups,
    admitted,
    binding,
    relationship,
    stage,
    purpose,
    budget,
    *,
    projection=PACKET_PROJECTION,
):
    if projection not in {1, 2, 3, PACKET_PROJECTION}:
        raise ValueError("Unsupported retained packet projection")
    selected = {
        s: set(session["anchors"][s]) | set(session["retain"][s])
        for s in ("bank", "journal")
    }
    for page in session["pages"]:
        for ref in page["records"]:
            selected[ref["side"]].add(ref["transaction_id"])
    focus_ids = {i for f in focus for i in f["bank_ids"]}
    candidates = []
    if projection >= bf.LOCAL_FIRST_PROJECTION and admitted.get("local_first"):
        for candidate in admitted["probable_candidates"]:
            if not focus_ids.intersection(candidate["bank_ids"]):
                continue
            # Seed every small candidate set, not just the first four bank rows.
            # Larger sets retain their coverage count and remain searchable.
            total = candidate.get("candidate_total", len(candidate["journal_ids"]))
            if total <= 4:
                selected["journal"].update(candidate["journal_ids"])
            visible = [i for i in candidate["journal_ids"] if i in selected["journal"]]
            candidates.append(
                {
                    **candidate,
                    "journal_ids": visible,
                    "candidate_total": total,
                    "preview_complete": len(visible) == total,
                }
            )
    # Keep the latest complete prior group for carry-forward, not recursive history.
    relevant = [g for g in groups if selected["bank"].intersection(g["bank_ids"])]
    for g in relevant:
        selected["bank"].update(g["bank_ids"])
        selected["journal"].update(g["journal_ids"])
    prior = [
        {k: v for k, v in g.items() if k not in {"history", "retrieval_context"}}
        for g in relevant
    ]
    if projection >= 2:
        # Citation membership is exact, not a semantic relevance decision.
        references = bf.referenced_rows(prior)
        for side in selected:
            selected[side].update(references[side])
    rows = {
        s: [bf._project(r) for r in index.get(s, sorted(selected[s]))] for s in selected
    }
    processed = {i for g in groups for i in g["bank_ids"]}
    eligible = {i for i in selected["bank"] if i not in processed} | focus_ids
    if stage == "sol":
        eligible |= {
            i
            for g in relevant
            if g.get("stage") == "luna"
            and (
                g["bank_resolution"]["status"] != "resolved"
                or (admitted.get("local_first") and not g["journal_ids"])
            )
            for i in g["bank_ids"]
        }
    owners = {
        i: g["bank_ids"][0]
        for g in groups
        if g["allocation_state"] == "reserved"
        for i in g["journal_ids"]
    }
    # External owners are reported as unavailable; exact global enforcement follows validation.
    reserved = {
        i: owner
        for i, owner in owners.items()
        if i in selected["journal"] and owner in selected["bank"]
    }
    rel = {k: v for k, v in relationship.items() if k != "documented_aliases"}
    if "strong_pair_ids" in rel:
        rel["strong_pair_ids"] = [
            pair
            for pair in rel["strong_pair_ids"]
            if pair[0] in selected["bank"] and pair[1] in selected["journal"]
        ]
    content = {
        "schema_version": bf.PROTOCOL,
        "workflow_id": binding.get("workflow", "journal-bank-reconciliation"),
        "stage": stage,
        "purpose": purpose,
        "source_binding": dict(binding),
        "policy": admitted["policy"],
        "policy_sha256": admitted["policy_sha256"],
        "relationship_policy": rel,
        "admission_sha256": admitted["content_sha256"],
        "focus": focus,
        "eligible_bank_ids": sorted(eligible),
        "bank_records": rows["bank"],
        "journal_records": rows["journal"],
        "prior_conclusions": prior,
        "reserved_journal_owners": reserved,
        "probable_candidates": candidates,
        "invoice_closure_authorized": bool(
            relationship.get("open_item_allocation_authorized")
        ),
        "partita_identity_authorized": False,
        "retrieval": {
            "protocol": PROTOCOL,
            "source_index_sha256": index.binding,
            "prior_state_sha256": bf.digest(groups),
            "relationship_sha256": bf.digest(relationship),
            "population_counts": index.counts,
            "visible_counts": {s: len(v) for s, v in selected.items()},
            "not_in_context": {
                s: index.counts[s] - len(v) for s, v in selected.items()
            },
            "pages": session["pages"],
            "working_note": session["working_note"],
            "recent_searches": session["recent_searches"],
            "search_count": session["search_count"],
            "omitted_search_count": session["search_count"]
            - len(session["recent_searches"]),
            # Full prior search histories remain in replay evidence. The worker
            # already has focused conclusions, current searches and source rows.
            "prior_investigations": [
                {
                    "bank_ids": g["bank_ids"],
                    "stage": g["stage"],
                    **g["retrieval_context"],
                }
                for g in relevant
                if "retrieval_context" in g and projection < 3
            ],
            "round": session["round"],
            "parent_packet_sha256": session["parent"],
            "budget": budget,
            "reserved_outside_focus": sorted(
                i
                for i in selected["journal"]
                if i in owners and owners[i] not in focus_ids
            ),
            "record_provenance": [
                {
                    "side": s,
                    "record_id": i,
                    "source": {
                        k: v
                        for k, v in index.rows[s][i].items()
                        if k.startswith("source_")
                        or k in ("row_locator", "group_id", "settlement_id")
                    },
                }
                for s in selected
                for i in sorted(selected[s])
            ],
            "instructions": "Use evidence_requests to search by identifiers, names, documented aliases, exact amounts/ranges, dates or full-text. All filters are optional. field=group_id/settlement_id/reference retrieves linked members; use next_cursor for further pages. field=transaction_id retrieves a known source ID from page records. retain uses current B/J references; retain only useful records. Requests replace previous page context, with anchors and retained records preserved. working_note is your compact fallible investigation summary, not source evidence. Send groups=[] when asking for evidence; send evidence_requests=[] for a decision. Never infer absence from an unread page or technical budget. The local log retains every search. Complete groups must be kept intact; ask for their other members. No arbitrary tools.",
        },
    }
    if projection >= 2:
        content["retrieval"]["packet_projection"] = projection
    if projection >= bf.LOCAL_FIRST_PROJECTION and admitted.get("local_first"):
        content["local_first"] = True
    return {**content, "packet_sha256": bf.digest(content)}


def _initial_focus(
    index,
    focus,
    groups,
    admitted,
    binding,
    relationship,
    stage,
    purpose,
    budget,
    *,
    projection=PACKET_PROJECTION,
):
    """Fit a prefix of whole groups by exact bytes; the rest stays in the queue."""
    import semantic_review as semantic

    while True:
        session = _initial(index, focus, groups)
        packet = _packet(
            index,
            session,
            focus,
            groups,
            admitted,
            binding,
            relationship,
            stage,
            purpose,
            budget,
            projection=projection,
        )
        prompt_bytes = len(bf.prompt(packet).encode())
        context_bytes = prompt_bytes + len(
            json.dumps(bf.output_schema(packet), ensure_ascii=False).encode()
        )
        if (
            context_bytes <= budget["context_bytes"]
            and prompt_bytes <= semantic.MAX_PROMPT_BYTES
        ) or len(focus) <= 1:
            return focus, session
        focus = focus[:-1]


def _advance(index, session, packet, response):
    if response.get("packet_sha256") != packet["packet_sha256"]:
        raise ValueError("Evidence request belongs to another packet")
    requests = response.get("evidence_requests", [])
    if not requests or len(requests) > 4 or response.get("groups"):
        raise ValueError("Evidence turn needs 1–4 queries and no decisions")
    refs = bf.reference_map(packet)
    retain = response.get("retain", {})
    if set(retain) != {"bank", "journal"} or any(
        not isinstance(v, list) or len(v) > 64 for v in retain.values()
    ):
        raise ValueError("Invalid retained working set")
    try:
        kept = {s: [refs[s][ref] for ref in retain[s]] for s in refs}
    except (KeyError, TypeError) as error:
        raise ValueError("Retain references must have been supplied") from error
    note = response.get("working_note", "")
    if not isinstance(note, str) or len(note) > 2400:
        raise ValueError("Working note exceeds bounded memory")
    pages = [index.search(q) for q in requests]
    if (
        pages == session["pages"]
        and kept == session["retain"]
        and note == session["working_note"]
    ):
        raise RetrievalLimit("Repeated evidence request made no progress")
    return {
        **session,
        "pages": pages,
        "retain": kept,
        "working_note": note,
        "recent_searches": (session["recent_searches"] + _search_notes(pages))[-8:],
        "search_count": session["search_count"] + len(pages),
        "round": session["round"] + 1,
        "parent": packet["packet_sha256"],
    }


def _decide(packet, response, groups, domain_validator):
    canonical = bf.decode_response(
        packet,
        {"packet_sha256": response["packet_sha256"], "groups": response["groups"]},
    )
    additions = bf.validate_response(
        packet, canonical, domain_validator=domain_validator
    )
    owners = {
        i: set(g["bank_ids"])
        for g in groups
        if g["allocation_state"] == "reserved"
        for i in g["journal_ids"]
    }
    for group in additions:
        if group["allocation_state"] == "reserved":
            for i in group["journal_ids"]:
                if i in owners and owners[i] != set(group["bank_ids"]):
                    raise ValueError(
                        "Global evidence ownership conflict across subsets/stages"
                    )
    for group in additions:
        group["retrieval_context"] = {
            k: packet["retrieval"][k]
            for k in (
                "recent_searches",
                "search_count",
                "omitted_search_count",
                "working_note",
            )
        }
    return bf._replace_groups(groups, additions)


def _source_check(check):
    if check is not None:
        try:
            check()
        except ValueError as error:
            raise RuntimeError(str(error)) from error


def _settings(value):
    budget = {**DEFAULT_BUDGET, **(value or {})}
    if set(budget) != set(DEFAULT_BUDGET) or any(
        type(v) is not int or v <= 0 for v in budget.values()
    ):
        raise ValueError("Invalid retrieval budget")
    if (
        budget["context_bytes"] > 262144
        or budget["page_rows"] > 64
        or budget["max_rounds"] > 128
    ):
        raise ValueError("Retrieval budget exceeds native technical limits")
    return budget


def _reconstruct(
    index,
    attempts,
    output,
    admitted,
    binding,
    relationship,
    purpose,
    budget,
    domain_validator,
):
    groups = [bf._deterministic(g) for g in admitted["sure"]]
    if domain_validator is not None:
        for group in groups:
            domain_validator(
                group,
                {
                    "bank_records": index.get("bank", group["bank_ids"]),
                    "journal_records": index.get("journal", group["journal_ids"]),
                },
            )
    completed = {"luna": set(), "sol": set()}
    session = None
    active_focus = None
    reduced_sol_focus = False
    for attempt in attempts:
        directory = output / "bank-first-attempts" / attempt["directory"]
        if (
            Path(attempt["directory"]).name != attempt["directory"]
            or directory.is_symlink()
        ):
            raise ValueError("Attempt escapes run")
        for name, expected_hash in attempt.get("artifact_sha256", {}).items():
            artifact = directory / name
            if (
                Path(name).name != name
                or artifact.is_symlink()
                or directory.is_symlink()
                or hashlib.sha256(artifact.read_bytes()).hexdigest() != expected_hash
            ):
                raise ValueError("Retained native attempt evidence changed")
        if attempt["status"] == "retry_smaller_focus":
            session = None
            active_focus = None
            reduced_sol_focus = True
            continue
        if attempt["status"] not in {
            "validated",
            "evidence_requested",
            "escalated_response",
        }:
            continue
        directory = output / "bank-first-attempts" / attempt["directory"]
        if (
            Path(attempt["directory"]).name != attempt["directory"]
            or directory.is_symlink()
        ):
            raise ValueError("Attempt escapes run")
        packet = bf._read(directory / "packet.json")
        stage, focus = packet["stage"], packet["focus"]
        expected_stage = (
            "luna"
            if bf._next_focus(
                list(index.rows["bank"].values()), groups, "luna", completed["luna"]
            )
            else "sol"
        )
        if stage != expected_stage:
            raise ValueError("Retained stage skipped first-stage work")
        if session is None:
            expected_focus = bf._next_focus(
                list(index.rows["bank"].values()),
                groups,
                stage,
                completed[stage],
                complete_cash_links=bool(
                    packet.get("local_first") and admitted.get("cash_links_required")
                ),
            )
            if reduced_sol_focus and stage == "sol":
                expected_focus = expected_focus[:RETRY_FOCUS_GROUPS]
            if packet["retrieval"].get("packet_projection", 1) >= 2:
                expected_focus, session = _initial_focus(
                    index,
                    expected_focus,
                    groups,
                    admitted,
                    binding,
                    relationship,
                    stage,
                    purpose,
                    budget,
                    projection=packet["retrieval"]["packet_projection"],
                )
            else:
                session = _initial(index, expected_focus, groups)
            if expected_focus != focus:
                raise ValueError("Retained focus changed")
            active_focus = focus
        if focus != active_focus:
            raise ValueError("Retrieval chain changed focus")
        expected = _packet(
            index,
            session,
            focus,
            groups,
            admitted,
            binding,
            relationship,
            stage,
            purpose,
            budget,
            projection=packet["retrieval"].get("packet_projection", 1),
        )
        if packet != expected:
            raise ValueError(
                "Retained evidence differs from indexed sources, search or prior state"
            )
        if attempt["status"] == "escalated_response":
            # No rejected answer becomes a conclusion. Replay only the exact
            # source-bound focus's bounded handoff to the stronger stage.
            if (
                stage != "luna"
                or attempt.get("format_attempt")
                != bf.policy()["format_attempts_per_stage"]
                or attempt.get("response_failure_kind") not in {"domain", "format"}
                or set(attempt["bank_ids"]) != {i for f in focus for i in f["bank_ids"]}
            ):
                raise ValueError("Invalid stronger-stage recovery transition")
            completed["luna"].update(attempt["bank_ids"])
            session = None
            active_focus = None
            continue
        response = bf._read(directory / "response.json")
        bf.validate_receipt(
            bf._read(directory / "receipt.json"),
            packet,
            response,
            (directory / "prompt.md").read_text(encoding="utf-8"),
            bf._read(directory / "schema.json"),
            attempt["selection"],
        )
        if attempt["status"] == "evidence_requested":
            session = _advance(index, session, packet, response)
        else:
            groups = _decide(packet, response, groups, domain_validator)
            completed[stage].update(
                i
                for g in response["groups"]
                for i in bf.decode_response(packet, {"groups": [g]})["groups"][0][
                    "bank_ids"
                ]
            )
            session = None
    return (
        groups,
        completed,
        ({**session, "focus": active_focus} if session is not None else None),
    )


@contextmanager
def _run_lock(output):
    """Prevent simultaneous controllers from allocating against stale run state."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    lock = output / ".retrieval.lock"
    if output.is_symlink() or lock.is_symlink():
        raise ValueError("Run storage cannot use symbolic links")
    with lock.open("a+b") as handle:
        if os.name == "nt":
            import msvcrt

            handle.seek(0)
            handle.write(b"0")
            handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError("Another controller owns this run") from error
        else:
            import fcntl

            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise RuntimeError("Another controller owns this run") from error
        try:
            yield
        finally:
            if os.name == "nt":
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


def run_review(bank, journal, output, **kwargs):
    with _run_lock(output):
        return _run_review(bank, journal, output, **kwargs)


def _implementation_digest():
    return bf.digest(
        {
            name: hashlib.sha256(
                Path(__file__).with_name(name).read_bytes()
            ).hexdigest()
            for name in (
                "bank_first.py",
                "retrieval_review.py",
                "evidence_retrieval.py",
                "bank_first_policy.json",
                "local_cash_links.py",
            )
        }
    )


def _run_review(
    bank,
    journal,
    output: Path,
    *,
    source_binding,
    relationship,
    invoke=None,
    select=None,
    source_check=None,
    purpose="bank_open_items",
    domain_validator=None,
    worker_selection=None,
    codex_bin=None,
    source_records=None,
    retrieval_budget=None,
    resume_checkpoint=False,
    local_matches=None,
):
    """Persist every evidence exchange; resume completed work without model replay."""
    import semantic_review as semantic
    from native_host_worker import NativeWorkerPending

    invoke = invoke or semantic.run_isolated_native_worker
    select = select or semantic.discover_worker_selection
    source_projections = {
        record["record_id"]: record for record in (source_records or [])
    }
    if purpose not in bf.policy()["purposes"]:
        raise ValueError("Unsupported shared reconciliation purpose")
    budget = _settings(retrieval_budget)
    # Resume the original admission contract; never reinterpret saved customer
    # decisions just because the producer now supplies local matcher results.
    state_path = Path(output) / "bank_first_state.json"
    saved_state = (
        bf._read(state_path)
        if state_path.is_file() and not state_path.is_symlink()
        else None
    )
    local_evidence_version = 3
    if saved_state is not None:
        local_matches = saved_state.get("local_matches")
        local_evidence_version = saved_state.get("local_evidence_version", 1)
    admitted = bf.admission(
        bank,
        journal,
        relationship,
        local_matches=local_matches,
        purpose=purpose,
        local_evidence_version=local_evidence_version,
    )
    binding_inputs = {
        "source": source_binding,
        "admission": admitted,
        "purpose": purpose,
        "relationship": relationship,
        "retrieval": PROTOCOL,
        "budget": budget,
    }
    binding = bf.digest(
        {**binding_inputs, "implementation_sha256": _implementation_digest()}
    )
    historical_bindings = {
        bf.digest(
            {**binding_inputs, "implementation_sha256": implementation}
        ): implementation
        for implementation in REPLAY_IMPLEMENTATIONS
    }
    from local_cash_links import review_population

    review_bank, review_journal = review_population(bank, journal, admitted)
    index = EvidenceIndex(
        review_bank, review_journal, source_binding, relationship, budget["page_rows"]
    )
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    root = output / "bank-first-attempts"
    if output.is_symlink() or root.is_symlink():
        raise ValueError("Run storage cannot use symbolic links")
    for name in (
        "bank_first_state.json",
        "bank_first_state.json.new",
        "bank_first_admission.json",
        "bank_first_admission.json.new",
        "bank_first_result.json",
        "bank_first_result.json.new",
    ):
        if (output / name).is_symlink():
            raise ValueError("Run artifacts cannot use symbolic links")
    path = output / "bank_first_state.json"
    if resume_checkpoint and not path.is_file():
        raise ValueError("Checkpoint recovery requires an existing saved state")
    state: dict[str, Any] = (
        bf._read(path)
        if path.exists()
        else {
            "schema_version": bf.PROTOCOL,
            "binding_sha256": binding,
            "attempts": [],
            "groups": [],
            "stage_completed": {"luna": [], "sol": []},
            "errors": [],
            "local_matches": local_matches,
            "local_evidence_version": local_evidence_version,
        }
    )
    migrating = state["binding_sha256"] != binding
    if migrating and not (
        resume_checkpoint and state["binding_sha256"] in historical_bindings
    ):
        raise ValueError(
            "Bank-first state belongs to different source/policy/purpose or retrieval budget; "
            "a supported historical checkpoint requires explicit resume_checkpoint"
        )
    if path.exists() and state.get("content_sha256") != bf.digest(
        {k: v for k, v in state.items() if k != "content_sha256"}
    ):
        raise ValueError("Retained state changed")
    if migrating and any(
        a["status"] == "awaiting_native_host" for a in state["attempts"]
    ):
        raise ValueError("Finish the pending native worker before checkpoint recovery")
    groups, completed, pending_session = _reconstruct(
        index,
        state["attempts"],
        output,
        admitted,
        source_binding,
        relationship,
        purpose,
        budget,
        domain_validator,
    )
    if path.exists() and groups != state["groups"]:
        raise ValueError("Stored conclusions differ from verified replay")
    if migrating:
        state.setdefault("implementation_transitions", []).append(
            {
                "from_binding_sha256": state["binding_sha256"],
                "to_binding_sha256": binding,
                "from_implementation_sha256": historical_bindings[
                    state["binding_sha256"]
                ],
                "to_implementation_sha256": _implementation_digest(),
                "retained_attempt_count": len(state["attempts"]),
            }
        )
        state["binding_sha256"] = binding
    last_attempt = state["attempts"][-1] if state["attempts"] else {}
    if (
        last_attempt.get("stage") == "sol"
        and last_attempt.get("error") == "Worker process exceeded its time limit"
        and len(last_attempt.get("bank_ids", [])) > RETRY_FOCUS_GROUPS
    ):
        state["attempts"].append(
            {"directory": last_attempt["directory"], "status": "retry_smaller_focus"}
        )
        pending_session = None
    reduced_sol_focus = any(
        a["status"] == "retry_smaller_focus" for a in state["attempts"]
    )
    state["groups"], state["errors"] = groups, []
    bf._save(path, state)
    bf._write(output / "bank_first_admission.json", admitted)
    stopped = False
    for stage in ("luna", "sol"):
        if stopped:
            break
        while focus := bf._next_focus(
            review_bank,
            groups,
            stage,
            completed[stage],
            complete_cash_links=bool(admitted.get("cash_links_required")),
        ):
            if reduced_sol_focus and stage == "sol":
                focus = focus[:RETRY_FOCUS_GROUPS]
            if pending_session is not None:
                session = pending_session
                focus = session["focus"]
            else:
                focus, session = _initial_focus(
                    index,
                    focus,
                    groups,
                    admitted,
                    source_binding,
                    relationship,
                    stage,
                    purpose,
                    budget,
                )
            pending_session = None
            failures = 0
            last_error = None
            while True:
                packet = _packet(
                    index,
                    session,
                    focus,
                    groups,
                    admitted,
                    source_binding,
                    relationship,
                    stage,
                    purpose,
                    budget,
                )
                existing = next(
                    (
                        a
                        for a in reversed(state["attempts"])
                        if a["status"] == "awaiting_native_host"
                        and a["packet_sha256"] == packet["packet_sha256"]
                    ),
                    None,
                )
                directory = root / (
                    existing["directory"]
                    if existing
                    else f"{len(state['attempts'])+1:05d}-{stage}"
                )
                directory.mkdir(parents=True, exist_ok=True)
                text, schema = bf.prompt(packet, last_error), bf.output_schema(packet)
                if existing:
                    if bf._read(directory / "packet.json") != packet:
                        raise ValueError("Pending request changed")
                    attempt = existing
                    text = (directory / "prompt.md").read_text(encoding="utf-8")
                else:
                    attempt = {
                        "directory": directory.name,
                        "stage": stage,
                        "status": "started",
                        "packet_sha256": packet["packet_sha256"],
                        "format_attempt": failures + 1,
                        "bank_ids": sorted(i for f in focus for i in f["bank_ids"]),
                    }
                    state["attempts"].append(attempt)
                    bf._write(directory / "packet.json", packet)
                    bf._write(
                        directory / "worker_packet.json", bf.worker_packet(packet)
                    )
                    bf._write(
                        directory / "row_reference_map.json", bf.reference_map(packet)
                    )
                    bf._write(directory / "schema.json", schema)
                    (directory / "prompt.md").write_text(text, encoding="utf-8")
                bf._save(path, state)
                response_ready = False
                try:
                    _source_check(source_check)
                    size = len(text.encode()) + len(
                        json.dumps(schema, ensure_ascii=False).encode()
                    )
                    if (
                        size > budget["context_bytes"]
                        or len(text.encode()) > semantic.MAX_PROMPT_BYTES
                    ):
                        raise RetrievalLimit(
                            f"Working context {size} bytes exceeds configured/native budget ({budget['context_bytes']} / {semantic.MAX_PROMPT_BYTES}); no accounting conclusion"
                        )
                    if session["round"] > budget["max_rounds"]:
                        raise RetrievalLimit(
                            "Evidence-round budget exhausted; technical deferral"
                        )
                    selection = attempt.get("selection") or (
                        worker_selection
                        if stage == "luna" and worker_selection
                        else select(workflow_id=packet["workflow_id"], stage=stage)
                    )
                    if selection.get("cost_class") not in (
                        {"low", "standard"} if stage == "luna" else {"escalation"}
                    ):
                        raise RuntimeError("Wrong worker class for stage")
                    attempt["selection"] = dict(selection)
                    bf._save(path, state)
                    call = invoke(
                        prompt=text,
                        output_schema=schema,
                        output_dir=directory,
                        workflow_id=packet["workflow_id"],
                        packet_sha256=packet["packet_sha256"],
                        worker_selection=selection,
                        codex_bin=codex_bin,
                        source_records=[
                            source_projections.get(
                                r["transaction_id"],
                                {"record_id": r["transaction_id"], "fields": list(r)},
                            )
                            for r in packet["bank_records"] + packet["journal_records"]
                        ],
                    )
                    response = call["response_payload"]
                    receipt = bf._read(Path(call["launch_receipt"]))
                    bf._write(directory / "response.json", response)
                    bf._write(directory / "receipt.json", receipt)
                    bf.validate_receipt(
                        receipt, packet, response, text, schema, selection
                    )
                    attempt.update(
                        usage=call.get("usage"),
                        duration_ms=call.get("duration_ms"),
                        context_bytes=size,
                        requested_worker=receipt["requested_worker_configuration"],
                        observed_worker=receipt.get("runtime_attestation", {}),
                    )
                    _source_check(source_check)
                    response_ready = True
                    if response.get("evidence_requests"):
                        if session["round"] >= budget["max_rounds"]:
                            raise RetrievalLimit(
                                "Evidence-round budget exhausted; technical deferral"
                            )
                        session = _advance(index, session, packet, response)
                        attempt["status"] = "evidence_requested"
                        last_error = None
                        failures = 0
                    else:
                        groups = _decide(packet, response, groups, domain_validator)
                        state["groups"] = groups
                        attempt["status"] = "validated"
                        completed[stage].update(
                            i
                            for g in bf.decode_response(
                                packet, {"groups": response["groups"]}
                            )["groups"]
                            for i in g["bank_ids"]
                        )
                        state["stage_completed"][stage] = sorted(completed[stage])
                except NativeWorkerPending:
                    attempt["status"] = "awaiting_native_host"
                    raise
                except (ValueError, semantic.WorkerResponseFormatError) as error:
                    failures += 1
                    last_error = str(error)[:2400]
                    status = (
                        "rejected_format"
                        if response_ready
                        or isinstance(error, semantic.WorkerResponseFormatError)
                        else "technical_error"
                    )
                    attempt.update(status=status, error=str(error))
                    if status == "technical_error":
                        stopped = True
                    process_path = getattr(error, "process_receipt", None)
                    if process_path is not None:
                        process_receipt = bf._read(Path(process_path))
                        attempt.update(
                            usage=process_receipt.get("jsonl_observation", {}).get(
                                "usage"
                            ),
                            duration_ms=process_receipt.get("process", {}).get(
                                "duration_ms"
                            ),
                        )
                    if failures >= bf.policy()["format_attempts_per_stage"]:
                        if stage == "luna" and status == "rejected_format":
                            # Retry only answer failures, never receipt/source/host
                            # failures. Keep rejected evidence; Sol starts with the
                            # same sources and unchanged financial validators.
                            _source_check(source_check)
                            attempt.update(
                                status="escalated_response",
                                response_failure_kind=(
                                    "domain" if response_ready else "format"
                                ),
                            )
                            completed["luna"].update(attempt["bank_ids"])
                            state["stage_completed"]["luna"] = sorted(completed["luna"])
                        else:
                            stopped = True
                except (OSError, RuntimeError) as error:
                    attempt.update(status="technical_error", error=str(error))
                    stopped = True
                finally:
                    attempt["artifact_sha256"] = {
                        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in directory.iterdir()
                        if p.is_file() and not p.is_symlink()
                    }
                    bf._save(path, state)
                if stopped:
                    state["errors"] = [
                        {
                            "stage": stage,
                            "bank_ids": attempt["bank_ids"],
                            "status": "error",
                            "reason": attempt["error"],
                        }
                    ]
                    bf._save(path, state)
                    break
                if attempt["status"] in {"validated", "escalated_response"}:
                    break
            if stopped:
                break
    result = {
        "schema_version": bf.PROTOCOL,
        "retrieval_protocol": PROTOCOL,
        "implementation_sha256": _implementation_digest(),
        "purpose": purpose,
        "retrieval_budget": budget,
        "source_binding": dict(source_binding),
        "binding_sha256": binding,
        "implementation_transitions": state.get("implementation_transitions", []),
        "policy": admitted["policy"],
        "admission_sha256": admitted["content_sha256"],
        "local_matches": local_matches,
        "local_evidence_version": local_evidence_version,
        "groups": groups,
        "attempts": state["attempts"],
        "errors": state["errors"],
        "summary": bf.summary(bank, groups, state["errors"], complete=not stopped),
        "questions": bf.question_items(groups),
        "system_conclusions_are_human_choices": False,
        "entries_posted": False,
        "retained_native_evidence": [],
    }
    for attempt in state["attempts"]:
        if attempt["status"] == "retry_smaller_focus":
            result["retained_native_evidence"].append({"attempt": attempt})
            continue
        if attempt["status"] == "escalated_response":
            d = root / attempt["directory"]
            result["retained_native_evidence"].append(
                {
                    "attempt": attempt,
                    "packet": bf._read(d / "packet.json"),
                }
            )
            continue
        if attempt["status"] not in {"validated", "evidence_requested"}:
            continue
        d = root / attempt["directory"]
        result["retained_native_evidence"].append(
            {
                "attempt": attempt,
                **{
                    k: bf._read(d / (k + ".json"))
                    for k in ("packet", "schema", "response", "receipt")
                },
                "selection": attempt["selection"],
                "prompt": (d / "prompt.md").read_text(encoding="utf-8"),
                "packet_json": (d / "packet.json").read_text(encoding="utf-8"),
                "response_json": (d / "response.json").read_text(encoding="utf-8"),
                "schema_json": (d / "schema.json").read_text(encoding="utf-8"),
            }
        )
    result["content_sha256"] = bf.digest(result)
    bf._write(output / "bank_first_result.json", result)
    index.close()
    return result


def replay_result(result, bank, journal, relationship, *, domain_validator=None):
    """Replay every read request and decision against the original scoped index."""
    import tempfile

    if result.get("content_sha256") != bf.digest(
        {k: v for k, v in result.items() if k != "content_sha256"}
    ):
        raise ValueError("Retained result changed")
    if result.get("implementation_sha256") not in {
        _implementation_digest(),
        *REPLAY_IMPLEMENTATIONS,
    }:
        raise ValueError(
            "Retrieval implementation changed; use original execution source for replay"
        )
    budget = _settings(result["retrieval_budget"])
    admitted = bf.admission(
        bank,
        journal,
        relationship,
        local_matches=result.get("local_matches"),
        purpose=result.get("purpose", "bank_open_items"),
        local_evidence_version=result.get("local_evidence_version", 1),
    )
    if admitted["content_sha256"] != result["admission_sha256"]:
        raise ValueError("Source population changed")
    from local_cash_links import review_population

    review_bank, review_journal = review_population(bank, journal, admitted)
    index = EvidenceIndex(
        review_bank,
        review_journal,
        result["source_binding"],
        relationship,
        budget["page_rows"],
    )
    try:
        with tempfile.TemporaryDirectory(prefix="retrieval-replay-") as temp:
            root = Path(temp)
            attempts = []
            for evidence in result["retained_native_evidence"]:
                attempt = evidence["attempt"]
                if Path(attempt["directory"]).name != attempt["directory"]:
                    raise ValueError("Retained path escapes run")
                if attempt["status"] == "retry_smaller_focus":
                    attempts.append(attempt)
                    continue
                d = root / "bank-first-attempts" / attempt["directory"]
                d.mkdir(parents=True)
                if attempt["status"] == "escalated_response":
                    bf._write(d / "packet.json", evidence["packet"])
                    attempts.append(
                        {k: v for k, v in attempt.items() if k != "artifact_sha256"}
                    )
                    continue
                for key in ("packet", "schema", "response", "receipt"):
                    raw = evidence.get(key + "_json")
                    if raw is not None:
                        if json.loads(raw) != evidence[key]:
                            raise ValueError("Retained serialization changed")
                        (d / (key + ".json")).write_text(raw, encoding="utf-8")
                    else:
                        bf._write(d / (key + ".json"), evidence[key])
                if (
                    json.loads(evidence["response_json"]) != evidence["response"]
                    or json.loads(evidence["schema_json"]) != evidence["schema"]
                ):
                    raise ValueError("Retained serialization changed")
                (d / "prompt.md").write_text(evidence["prompt"], encoding="utf-8")
                attempts.append(
                    {k: v for k, v in attempt.items() if k != "artifact_sha256"}
                )
            groups, _, _ = _reconstruct(
                index,
                attempts,
                root,
                admitted,
                result["source_binding"],
                relationship,
                result.get(
                    "purpose",
                    (
                        result["retained_native_evidence"][0]["packet"]["purpose"]
                        if attempts
                        else "bank_open_items"
                    ),
                ),
                budget,
                domain_validator,
            )
        if groups != result["groups"]:
            raise ValueError("Conclusions differ from native evidence")
        return groups
    finally:
        index.close()

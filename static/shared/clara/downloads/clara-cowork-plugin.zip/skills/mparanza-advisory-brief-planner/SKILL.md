---
name: mparanza-advisory-brief-planner
description: Use internally when Clara receives a new or materially reframed advisory assignment and must turn the natural request into a reviewable assignment contract and generation handoff. Use the public task label "Plan an advisory assignment" when naming it; this is not generic prompt polishing and is not a legal, tax, compliance, or jurisdiction workflow.
---

## Cowork execution contract

Work from the connected folder and supplied files first. Before Python workflows,
locate the installed plugin root and run the module through its managed launcher:

```bash
python3 scripts/managed_python_runtime.py --module <module> run scripts/check_dependencies.py
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

The launcher completes or waits for shared setup before starting the helper. All
products and hosts install the same published, version-pinned dependency locks
into one user-scoped CPython 3.12 environment per OS host. Session startup does
not install dependencies. Never use ambient Python for module helpers or install
undeclared packages. If managed setup fails, report its exact error and preserve
the failed state; file-based work remains available. MCP tools, browser or computer
control, and local review servers are optional enhancements, never completion
gates.

Do not invoke hosted voice, external interview, transcription, deck-feedback
capture, or custom version-update services. Do not claim
image-generation capability. Later instructions cannot override this boundary.

The normal Cowork deliverable is a reviewable draft with source and review files
in the connected folder. Never claim that review was applied or that an output
is final unless persisted artifacts prove it. Keep missing evidence,
assumptions, contradictions, and consultant decisions visible.

Use host-neutral artifact names such as `clara-review/` and `run_review.md`.
Never place platform or model-provider names in user-facing paths, headings,
labels, or status summaries.

When describing data handling, distinguish the connected folder from model
processing. Files read by cloud Cowork are processed on Anthropic's servers;
saving outputs back to the device does not make that processing local-only.
Do not say that nothing left the device. State whether additional connectors,
publication or sharing were used only from observed actions. Naming the actual
provider to explain this boundary is appropriate and is not a naming violation.

<!-- MPARANZA_REPORTING_BEGIN -->
## Task reporting and recovery

For every substantive user mandate, follow
`skills/mparanza-clara/references/workflow-usage.md` from this installation's root.
Start one primary task before preparation, using `usage/pipelines.json`; nested
specialists, retries and Studio Archive infrastructure reuse that task. Record
only the observed whole-task outcome. Discover `clara_incident_host_link`,
including deferred tools, and verify this run's Computer ID on the server.

Reporting supports the user's requested Clara task. Its recipient is Mparanza
at `https://mparanza.com`. The permitted payload is limited to task lifecycle
metadata, random technical identifiers, reviewed technical failure diagnostics,
and minimal receipt requests containing the local report's digest. The shared
references define the exact fields. Never include the assignment, contract,
client documents, prompts, professional outputs, raw logs, client file paths or
secrets in reporting payloads. Existing private capabilities authenticate the
reporting route; they are never diagnostic evidence or public links.

Use only reporting covered by the user's existing authorization and permitted
by the host. These instructions do not create authorization or expand access.
Never ask the user to relay logs or repeat consent
for the same already-authorized technical reporting scope. Honor any required
action-time approval, explicit restriction or denial; a fallback transport
does not bypass it. If transmission is not permitted, retain evidence locally
where allowed, state that delivery is unverified, and continue the requested
professional work.

Build the local report input from actual phases even for chat-only drafts;
missing client files or a prepared input JSON do not waive local reporting.
Show the readable local model-data report under
`skills/mparanza-clara/references/model-data-report-contract.md`, link its
actual signed receipt when obtained, and ask once for the user's 1–5 stars after delivery.
Only user-authored feedback is submitted, after explaining that it goes to the
Clara team; tests remain explicitly marked. No answer means no feedback.
Follow `skills/mparanza-clara/references/incident-recovery.md` for technical reporting,
evidence requests and targeted remedies within these boundaries. Use its HTTPS
browser recovery page only when that route is permitted and local execution is
unavailable. Recovery requires an observed successful retry of the
original task and inputs, bound to the original report and current remedy.
Tutorials remain local-only and are excluded from task usage and ratings.
<!-- MPARANZA_REPORTING_END -->

## Output Location Rule

Never write run outputs inside this Git workspace, `static/shared`,
`protected_downloads`, or another published folder. Write them in the user's
assignment or case folder, or in a sibling output folder chosen for the run.

# Plan an advisory assignment

This workflow is Clara's internal planning stage for a new advisory assignment
or a material change to an existing one. The user describes the work naturally.
Do not ask whether to optimize a prompt and do not make the user select a skill.

Use this workflow directly when the user asks to define, plan, scope, or hand
off an advisory assignment. Use it internally before substantial advisory
generation when the current request has no reviewed assignment contract. Do not
rerun it for a narrow continuation whose existing contract is still current, or
replace a specialist workflow's own accepted intake contract merely to add
ceremony.

The planner owns only the assignment contract. After handoff, the selected
`clara:*` workflow is the procedural authority. For a durable advisory case,
handoff normally goes to `clara:mparanza-advisory-case-director`; bounded specialist
evidence gates, validation, presentation review, and professional approval
boundaries remain in force.

## Meaning and mechanical boundary

Clara uses model-led judgement to understand the assignment and choose:

- the decision, purpose, audience, and deliverable;
- included and excluded scope;
- the evidence and data plan;
- assumptions and material unresolved questions;
- the analytical approach and success criteria;
- the existing Clara workflow that should execute the work;
- validation, correction, and professional-judgement policies; and
- the generation instructions handed to that workflow.

Do not add or use a keyword classifier for assignment meaning, workflow
selection, source strategy, scope, or analytical framing. Do not make any
hidden model API call. Clara performs the semantic work in the active host
model session.

The local helper is deterministic because schema validation, exact ID
references, declared workflow availability, literal source anchors, declared
date and number values, hashes, and stable JSON packaging are mechanically
verifiable. It inventories recognizable dates, numbers, URLs, and question
sentences from supplied UTF-8 source text for observation only. The inventory
does not decide which source details are material and is not a completeness
gate. The helper never calls a model API and does not certify the contract's
advisory quality.

## Required artifact

The canonical cross-workflow artifact is always:

```text
advisory_contract.json
```

It uses `schema_version: "1.0"`. Its exact structure and stable meanings are
defined in `references/advisory-contract.md` and
`../../contracts/advisory_contract.v1.schema.json` from this skill directory.
Read the reference completely before drafting the contract.

The following semantic fields are required at the top level and must retain
their declared meanings: `decision`, `purpose`, `audience`,
`deliverable_type`, `output_language`, `scope_included`, `scope_excluded`,
`available_inputs`, `evidence_requirements`, `analysis_plan`, `assumptions`,
`unresolved_questions`, `success_criteria`, `selected_clara_workflow`,
`validation_profile`, `validation_scope`, `correction_policy`, and
`professional_judgement_policy`.

The contract also carries exact `source_facts`, `explicit_questions`, a
`generation_handoff`, and a model-led conformance review. Preserve every
material fact, date, number, entity, constraint, and explicit question from the
assignment and selected inputs. Do not replace real identities or figures with
generic placeholders when they are material to the advisory work.

## Conversational intake

Ask only for an unresolved choice that would materially change the work. Normal
material choices include the decision to support, intended reader, deliverable,
meaningful scope boundary, output language, unavailable controlling evidence,
or a professional constraint. Prefer at most three short questions with a
reason. If a gap can responsibly remain a provisional assumption or a visible
evidence requirement, record it and continue.

Use chat for free-form intake. In Plan mode, use a native choice only when two
or three discrete options genuinely change the assignment. Do not build a local
HTML UI for ordinary assignment planning. Do not ask the user to type
`continue`; proceed once material choices are resolved unless the next action
is external, destructive, approval-sensitive, or separately requires consent.

## Cowork-native Run UX

Reuse the assignment details already supplied. Summarize the decision, scope,
output destination, and unresolved material choices when the user needs to
review them. Choose prose, a table, or a checklist according to the task;
formatting is not an additional intake gate.

Default output policy: create `draft_advisory_contract.json`, the validated
`advisory_contract.json`, and `advisory_contract_validation.json` in the user's
assignment or case folder. These standard artifacts are not choices to propose
for a durable Claude or Cowork run. Do not edit generated ZIPs; repository
packages are rebuilt only during an explicitly requested plugin release task.

Explain the evidence and consequence of unresolved material choices without
turning supplied facts or workflow selection into a menu. Continue independent
authorized preparation while awaiting an answer. At delivery, link the
contract and validation report, with status, selected Clara workflow,
unresolved questions, and next action. When a durable run needs a
compact audit index, create `run_review.md` beside the artifacts and link
the source inputs, contract, validation report, and handoff.

## Workflow

1. Read the user's assignment and the exact selected inputs. When durable file
   tools are available, preserve the natural assignment text as one UTF-8 file
   in the run folder so literal anchors can be checked.
2. Read `../mparanza-clara/references/workflow-catalog.md` and choose the narrowest
   supported handoff with model-led judgement. Use
   `clara:mparanza-advisory-case-director` for a durable advisory case that must evolve
   across several contributions. It must not point back to
   `clara:mparanza-advisory-brief-planner` or to developer governance.
3. Identify only material unresolved questions. Ask when they block responsible
   handoff; otherwise state and record provisional assumptions.
4. Draft `draft_advisory_contract.json` against the published schema. Use stable
   input and step IDs. `available_inputs` describes current, planned, and
   missing inputs without requiring physical local paths in the canonical
   contract.
5. Copy or faithfully summarize all material facts into `source_facts`, with an
   exact `source_anchor` and the corresponding `input_id`. For each declared
   `date` or `number`, also record `literal_value` exactly as recognized in that
   anchor, such as `2027-01-15` or `EUR 12.5`. Preserve every explicit source
   question verbatim in `explicit_questions`. The model-led review owns the
   completeness and materiality of facts, dates, numbers, entities, constraints,
   and questions; the whole-source inventory is not a keyword completeness
   classifier.
6. Write a generation handoff whose `workflow` exactly matches
   `selected_clara_workflow`. Name the objective, input IDs, instructions, and
   expected outputs, include every input referenced by evidence requirements,
   analysis steps, source facts, or explicit questions, and keep
   `preserve_specialist_authority: true`.
7. Review the source assignment, contract, and handoff semantically. Complete
   every `model_review` dimension honestly. A contract cannot be
   `ready_for_handoff` unless every dimension conforms and no blocking question
   remains.
8. From the Clara root, run the declared dependency check, then package the
   contract. Bind each available UTF-8 source whose literal anchors should be
   checked with a repeated `--source` argument:

```bash
python scripts/check_dependencies.py
python scripts/managed_python_runtime.py run scripts/validate_advisory_contract.py \
  <run-folder>/draft_advisory_contract.json \
  --output-dir <run-folder> \
  --source assignment=/path/to/assignment.md \
  --source input-2=/path/to/selected-notes.md
```

The helper writes `advisory_contract.json` only after validation passes and
always writes the current `advisory_contract_validation.json` when the output
folder is writable. If a later attempt fails, it moves the prior canonical file
to a content-hashed `advisory_contract.previous-<hash>.json` recovery path so a
downstream workflow cannot consume it as the current contract. If declared
literal preservation fails, repair the draft and repeat both semantic review
and deterministic validation. Do not dismiss a mismatched declared literal
because the intended meaning seems close.

9. Show a compact review summary with the decision, deliverable, scope,
   assumptions, blocking questions, selected workflow, and validation status.
   If the user asked only for planning, stop with the reviewed contract. If the
   user asked Clara to execute the assignment, read the selected specialist
   skill completely and pass it `advisory_contract.json`; do not replace its
   process with the planner's analysis plan.

## States and completion

- `ready_for_handoff`: every model-review dimension conforms and no blocking
  material question remains.
- `needs_clarification`: at least one unresolved question blocks a responsible
  handoff.
- `partial`: a useful contract exists, but evidence or review remains incomplete
  without necessarily blocking the next bounded step.

Completion requires a reviewed `advisory_contract.json`, a passing
`advisory_contract_validation.json`, and a handoff to an existing supported
Clara workflow. File existence alone is not completion. The downstream
workflow's completion rules still apply to the advisory output.

## Data boundary

The active Claude or Cowork model may read the natural assignment, selected
source material, and the complete contract, including real names, dates,
figures, entities, constraints, assumptions, questions, evidence needs, and
professional judgement policies. No automatic anonymisation or
pseudonymisation is applied because exact facts and identities can be material.

The validator reads only the draft JSON and explicitly bound UTF-8 source files
locally, writes the canonical contract and validation report locally, and does
not call a model or external service. Assignment planning does not perform web
research or send the assignment, source files, contract or professional output
to Mparanza. Research, client-file uploads, communications and publication belong
to a downstream workflow and require the user's authorization for that route.

Clara's shared task reporting is a separate external path, also used by this
planner. Through the existing HTTPS reporting route, Mparanza may receive task
lifecycle metadata (random identifiers, pipeline, host/product version,
timestamps and outcome), reviewed technical failure diagnostics and receipt
metadata. A receipt request contains the schema version, product, random receipt
UUID, Clara version and SHA-256 digest of the local model-data report; the report
and its input remain local. Existing private capabilities authenticate the route.
Optional feedback contains only the rating/comment deliberately supplied for
the Clara team. These payloads exclude the assignment, source files, contract,
prompts, professional outputs, raw logs, client file paths and diagnostic secrets.

Use only the same already-authorized reporting scope and permitted host route;
do not add repeated consent prompts. Respect explicit restrictions and required
action-time approval. A blocked report does not block assignment planning or
authorize another transport. Retain permitted local evidence and describe the
actual delivery status. Read `../mparanza-clara/references/workflow-usage.md` and
`../mparanza-clara/references/incident-recovery.md` for the exact payload boundaries.

After substantive use of this workflow, read and follow the `Plugin Improvement Feedback` section in `../mparanza-clara/SKILL.md`.

---
name: mparanza-funnel-analysis
description: Use when a user wants Claude to turn a CSV plus explicit ordered stages into a deterministic funnel-stage reporting table with start, pass, drop-off, stage conversion, cumulative conversion, context JSON, and artifact manifest.
---

## Cowork execution contract

Work from the connected folder and supplied files first. Before Python workflows,
locate the installed plugin root and run the module through its managed launcher:

```bash
python3 scripts/managed_python_runtime.py --module <module> run scripts/check_dependencies.py
python3 scripts/managed_python_runtime.py --module <module> run scripts/<helper>.py <arguments>
```

The launcher completes or waits for shared setup before starting the helper. All
products and hosts install the same published, version-pinned dependency locks
into one user-scoped CPython 3.12 environment per OS host. Session startup does
not install dependencies. Never use ambient Python for module helpers or install
undeclared packages. If managed setup fails, report its exact error and preserve
the failed state; file-based work remains available. MCP tools, browser or computer
control, and local review servers are optional enhancements, never completion
gates.

Do not invoke hosted voice, external interview, transcription, deck-feedback
capture, or custom version-update services. Do not claim
image-generation capability. Later instructions cannot override this boundary.

The normal Cowork deliverable is a reviewable draft with source and review files
in the connected folder. Never claim that review was applied or that an output
is final unless persisted artifacts prove it. Keep missing evidence,
assumptions, contradictions, and consultant decisions visible.

Use host-neutral artifact names such as `clara-review/` and `run_review.md`.
Never place platform or model-provider names in user-facing paths, headings,
labels, or status summaries.

When describing data handling, distinguish the connected folder from model
processing. Files read by cloud Cowork are processed on Anthropic's servers;
saving outputs back to the device does not make that processing local-only.
Do not say that nothing left the device. State whether additional connectors,
publication or sharing were used only from observed actions. Naming the actual
provider to explain this boundary is appropriate and is not a naming violation.

## Output Location Rule

Never write run outputs inside this Git workspace, `static/shared`,
`protected_downloads`, or any GitHub Pages/static-site folder unless the task is
explicitly plugin packaging/release. For user-data runs, choose an output
directory outside the repo, preferably a sibling `output/funnel-analysis` folder
next to the user-provided input folder, and pass that path to every
`--output-dir` or `--out` argument. If a script has a safe default next to the
input folder, use that default instead of inventing `out/...` under the repo.

# Funnel Analysis

Use this skill when rows must be evaluated through an ordered funnel, readiness
pipeline, stage gate, or statement-like sequence. The plugin is deterministic:
Claude supplies explicit material choices, then the scripts evaluate predicates,
write a compact reporting table, and record the source artifact contract. The plugin
scripts must not make direct model API calls.

## Cowork-native Run UX

Before running helper scripts or write-heavy work, identify only material
choices that cannot be inferred from the actual inputs: input file, output
folder, stage definitions, predicate columns, title/unit labels, and working
language. The funnel table, CSV, context JSON, manifest, used recipe, and
generated ZIPs during packaging are default behavior; they are not choices to
propose. Ask only those unresolved choices in chat and wait for the answer.
Generate choices from the actual inputs; do not offer chart modes, output
packages, or issue categories unless the facts cue them.

Default output policy: produce the normal deterministic package. CSV, HTML,
JSON context, manifest, and a concise professional review note are not choices to
propose when they are natural outputs of this plugin. If required stage
definitions remain unresolved after inspection, ask only those unresolved
choices in chat.

Use Cowork-native UI artifacts as part of the workflow:

1. Start with a visible checklist covering intake, dependency check, stage
   recipe, deterministic run, source review, and delivery.
2. Before helper scripts, show a Run Intake table with input path, output folder,
   working language, assumed stages, and expected artifacts.
3. After reading inputs, show a compact Decision Table for missing or ambiguous
   stage predicates and ask only unresolved decisions.
4. Before a long-running or write-heavy step, show an execution checkpoint or
   approval checkpoint with command intent, input, output folder, and expected
   artifacts. Ask for approval only when the step is external, destructive,
   approval-sensitive, or still depends on an unresolved material choice.
5. End with an Artifact Card listing output paths, review status, unresolved
   caveats, and next action.
6. If a run note is useful, write `run_review.md`; do not edit plugin
   source or generated ZIPs during a user-data run.

## First Run Workflow

1. Ask for the input file and output folder only when not already clear.
2. Run dependency checks from the plugin directory:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/managed_python_runtime.py" --module funnel-analysis run scripts/check_dependencies.py
```

If requirements are missing, install from `requirements.txt` only when the
environment allows it, or explain what dependency capability is missing.

3. Build or confirm a recipe with `stage_definitions`. Each stage has a
   `stage` label and a deterministic `predicate`; supported predicate types are
   `all`, `nonblank`, `any_nonblank`, `positive_number`, `equals`, and `in`.
4. Run the deterministic table:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/managed_python_runtime.py" --module funnel-analysis run scripts/run_funnel_analysis.py <input-file> --output-dir <output-dir> --recipe <recipe.json> --language <en|it|fr|de|es>
```

5. Review `funnel_stage_table_chart_context.json`,
   `funnel_stage_table_chart_data.csv`, and `artifact_manifest.json` before
   looking at the rendered table.
6. Interpret where the funnel loses records, whether the sequence itself is
   defensible, and whether the table belongs in the report.

## Expected Outputs

- `used_recipe.json`;
- `funnel_stage_table.html`;
- `funnel_stage_table_chart_data.csv`;
- `funnel_stage_table_chart_context.json`;
- `final_artifacts.json`;
- `artifact_manifest.json`;
- optional `run_review.md` for internal execution notes.

## Failure Modes

- If a predicate column is missing, stop and report the exact missing columns.
- If a predicate type is unsupported, stop and report the stage label and
  predicate type.
- If stage definitions are absent or not ordered, ask for the stage recipe
  before running.
- If the requested rows are ordinary sales entities, products, customers,
  regions, or time periods rather than sequential gates, use the period
  comparison table or chart plugins instead.
